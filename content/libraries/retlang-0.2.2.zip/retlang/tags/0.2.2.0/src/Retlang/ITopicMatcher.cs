namespace Retlang
{
    public interface ITopicMatcher
    {
        bool Matches(object topic);
    }
}