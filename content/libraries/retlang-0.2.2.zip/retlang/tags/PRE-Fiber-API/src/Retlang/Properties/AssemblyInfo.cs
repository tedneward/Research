﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly : AssemblyTitle("Retlang")]
[assembly : AssemblyDescription("")]
[assembly : AssemblyConfiguration("")]
[assembly : AssemblyCompany("")]
[assembly : AssemblyProduct("Retlang")]
[assembly : AssemblyCopyright("Michael Rettig Copyright ©  2007")]
[assembly : AssemblyTrademark("")]
[assembly : AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.

[assembly : ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly : Guid("13a9e572-0292-43c6-b0fa-7377c06d4669")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly : AssemblyVersion("0.3.0.3")]
[assembly : AssemblyFileVersion("0.3.0.3")]
[assembly :
    InternalsVisibleTo(
        "RetlangTests, PublicKey=00240000048000009400000006020000002400005253413100040000010001001ffdca16214e1bf7e3787e0c61e98c65c649a4d36cc9b6e77cfa526ba71787a4d8ff66227948a712197c6b3a595c512ed8f4db09669ac5fa0424dd3d311b6c1b0806c90d17a58f21758b8329cfe59f503c410aeea5a1cf0d618d6a8cf4d5fae50e43d3c241626e8cbcdcb81076631894d5a38175d37e615af7942460b20abceb"
        )]