﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Tycho.Language;

namespace Tycho.Profile {
    class Program {
        static void Main (string [] args) {
//            var test = new UnitTests.Evaluation.IntegerTest ();
//            test.TestPlus ();

            Parse ();
        }

        static void Parse () {
            var compiledGrammar = new ParserLoader ().LoadParser (File.ReadAllText ("expression.grammar"));
            compiledGrammar.ParseTerm (File.ReadAllText ("source.tycho"), "source.tycho");
        }
    }
}
