﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using Tycho.Lexer;
using Tycho.Modules;
using Tycho.Runtime;
using Tycho.Compiler;
using Tycho.Parser.Tokens;
using System.IO;
using Tycho.Language;
using System.Reflection;
using Tycho.Native;

namespace CommandLine {
    class Program {
        static void Main (string [] args) {
            Evaluate (args);
//            PrintSourceLocations ("test-tokens.txt");
        }

        private static void PrintSourceLocations (string filename) {
            List<Token> tokens = NativeLexer.Lex (File.ReadAllText (filename), filename);

            PrintSourceLocations (tokens);
            Console.ReadKey ();
        }

        private static void PrintSourceLocations (List<Token> tokens) {
            foreach (Token token in tokens) {
                PrintSourceLocation (token.SourceLocation);

                if (token is BracketToken) {
                    PrintSourceLocations (((BracketToken) token).Tokens);
                }
            }
        }

        private static void Evaluate (string[] args) {
            TopLevel toplevel = new TopLevel (Namespaces.User);

            ConfigureRuntimeModule (toplevel);
            LoadModules (toplevel);

            using (new ThreadContext ()) {
                ThreadContext.Current.SetProperty (Symbols.RuntimePrintStream, new NativeObject<TextWriter> (Console.Out));

                if (args.Length == 0) {
                    while (true) {
                        bool dontExit = TryEvaluationAction (() => {
                            Console.Write ("> ");
                            string line = Console.ReadLine ();
                            Console.WriteLine (toplevel.Evaluate (line).ToString ());
                        });

                        if (!dontExit) {
                            break;
                        }
                    }
                } else {
                    foreach (string fileName in args) {
                        if (File.Exists (fileName)) {
                            string source = File.ReadAllText (fileName);

                            TryEvaluationAction (() => {
                                                     AnyObject result = toplevel.Evaluate (source, fileName);
                                                     Console.WriteLine ("> " + result);
                                                 });
                        } else {
                            Console.Error.WriteLine ("no such file `{0}'", fileName);
                        }
                    }
                }
            }
        }

        private static bool TryEvaluationAction (Action action) {
            try {
                action ();
            } catch (CompilationException cex) {
                PrintCompilationException (cex);
            } catch (ExitException) {
                return false;
            } catch (TychoException tex) {
                Console.WriteLine ("error: " + tex.Message);
            }

            return true;
        }

        private static void LoadModules (TopLevel toplevel) {
            toplevel.AddModule (Namespaces.Tycho.GetNamespace ("native"), new AssemblyModuleLoader (Namespaces.Tycho.GetNamespace ("native"), Assembly.Load ("Tycho.Native")));
            List<string> assemblies = GetSystemAssemblies ();
            PreloadedNativeModuleLoader nativeLoader = new PreloadedNativeModuleLoader (assemblies);
            toplevel.AddModule (Namespace.Parse ("system"), nativeLoader);
            toplevel.AddModule (Namespace.Parse ("microsoft"), nativeLoader);

            ExpressionModuleCompiler expressionModuleCompiler = new ExpressionModuleCompiler (toplevel.ModuleFrame);
            toplevel.AddModule (Namespaces.Root.GetNamespace ("world"), new HttpModuleLoader (ConfigurationManager.AppSettings ["WorldModuleUrl"], expressionModuleCompiler));
            toplevel.AddModule (Namespaces.Root.GetNamespace ("home"), new FileSystemModuleLoader (GetHomeModulePath (), expressionModuleCompiler));
            toplevel.AddModule (Namespaces.Root, new FileSystemModuleLoader (Directory.GetCurrentDirectory (), expressionModuleCompiler));
        }

        private static string GetHomeModulePath () {
            var configPath = ConfigurationManager.AppSettings ["HomeModulePath"];

            if (configPath != null) {
                return configPath;
            } else {
                return Path.Combine (Path.GetDirectoryName (typeof (Program).Assembly.Location), "Modules");
            }
        }

        private static void ConfigureRuntimeModule (TopLevel toplevel) {
            RuntimeModule.Compile = (source, stackFrame) => toplevel.Compile (source, null, stackFrame);
            RuntimeModule.ConvertToRuntime = NativeObjectConversion.ConvertToRuntime;
        }

        private static List<string> GetSystemAssemblies () {
            return new List<string> {
                                        "System",
                                        "mscorlib",
                                        "System.Xml",
                                        "System.Data",
                                        "System.Web",
                                        "System.Drawing",
                                        "System.Windows.Forms",
                                        "System.Core",
                                        "System.ServiceModel",
                                        "System.Workflow.ComponentModel",
                                        "System.Workflow.Runtime",
                                        "System.Workflow.Activities",
                                        "WindowsBase",
                                        "PresentationCore",
                                        "PresentationFramework"
                                    };
        }

        static string PadLeftSpaces (int number, int padToLength) {
            string numberString = number.ToString ();

            return new String (' ', padToLength - numberString.Length) + numberString;
        }

        static void PrintCompilationException (CompilationException ex) {
            SourceLocation sloc = ex.SourceLocation;

            PrintSourceLocation (sloc);

            Console.WriteLine ("error: " + ex.Message);
        }

        private static void PrintSourceLocation (SourceLocation sloc) {
            if (sloc.FileName != null) {
                Console.WriteLine ("file: " + sloc.FileName);
            }

            if (sloc.LineStart != sloc.LineEnd) {
                StringReader source = new StringReader (sloc.Source);

                for (int n = 0; n < sloc.LineStart - 1; n++) {
                    source.ReadLine ();
                }

                int lineNumberLength = sloc.LineEnd.ToString ().Length;

                for (int n = sloc.LineStart; n <= sloc.LineEnd; n++) {
                    Console.WriteLine (PadLeftSpaces (n, lineNumberLength) + ": > " + source.ReadLine ());
                }
            } else {
                StringReader source = new StringReader (sloc.Source);

                for (int n = 0; n < sloc.LineStart - 1; n++) {
                    source.ReadLine ();
                }

                string lineNumber = sloc.LineEnd + ": ";
                string line = source.ReadLine ();
                string indicatorLine = new String (' ', lineNumber.Length) + GetPaddingFromIndent (line, sloc.ColumnStart) + new String ('^', sloc.ColumnEnd - sloc.ColumnStart);

                Console.WriteLine (lineNumber + line);
                Console.WriteLine (indicatorLine);
            }
        }

        static string GetPaddingFromIndent (string errorLine, int errorStart) {
            StringBuilder sb = new StringBuilder (errorStart);
            char c = errorLine [0];
            int n = 0;

            while (n < errorLine.Length && n < errorStart && char.IsWhiteSpace (c = errorLine [n])) {
                sb.Append (c);
                n++;
            }

            while (n < errorStart) {
                sb.Append (' ');
                n++;
            }

            return sb.ToString ();
        }
    }
}
