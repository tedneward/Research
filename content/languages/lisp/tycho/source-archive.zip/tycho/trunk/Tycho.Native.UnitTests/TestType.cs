namespace Tycho.Native.UnitTests {
    class TestType {
        public string InstanceField;
        public string InstanceProperty { get; set; }

        public static string ClassVariable;
        public static string ClassProperty { get; set; }

        static TestType () {
            ClassVariable = "class-variable";
            ClassProperty = "class-property";
        }

        public static int ClassMethod (int a, int b) {
            return a + b;
        }

        public TestType (string name) {
            InstanceField = name;
            InstanceProperty = name;
        }

        public int InstanceMethod (int a, int b) {
            return a + b;
        }

        public override bool Equals (object obj) {
            return obj is TestType && ((TestType) obj).InstanceField == InstanceField;
        }

        public override int GetHashCode () {
            return InstanceField.GetHashCode () + 1;
        }
    }
}