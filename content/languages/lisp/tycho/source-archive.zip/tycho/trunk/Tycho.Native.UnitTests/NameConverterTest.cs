﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Runtime;

namespace Tycho.Native.UnitTests {
    [TestFixture]
    public class NameConverterTest {
        [Test]
        public void ShouldConvertSingleWordToLowerCaseWord () {
            Assert.AreEqual ("word", NameConverter.Convert ("Word"));
        }

        [Test]
        public void ShouldConvertSingleLowerCaseWordToLowerCaseWord () {
            Assert.AreEqual ("word", NameConverter.Convert ("word"));
        }

        [Test]
        public void ShouldConvertSingleCamelCaseToWordHyphenWord () {
            Assert.AreEqual ("two-words", NameConverter.Convert ("twoWords"));
        }

        [Test]
        public void ShouldConvertWordUnderscoreWordToWordHyphenWord () {
            Assert.AreEqual ("one-two", NameConverter.Convert ("one_two"));
        }

        [Test]
        public void ShouldConvertWordUnderscoreUpperWordToWordHyphenWord () {
            Assert.AreEqual ("one-two", NameConverter.Convert ("one_Two"));
        }

        [Test]
        public void ShouldConvertWordTwoUnderscoreUpperWordToWordHyphenWord () {
            Assert.AreEqual ("one-two", NameConverter.Convert ("one__Two"));
        }

        [Test]
        public void ShouldConvertUnderscoreWordTwoUnderscoreUpperWordToWordHyphenWord () {
            Assert.AreEqual ("one-two", NameConverter.Convert ("_oneTwo_"));
        }

        [Test]
        public void ShouldConvertAcronymUnderscoreUpperWordToWordHyphenWord () {
            Assert.AreEqual ("io-two", NameConverter.Convert ("IO_Two"));
        }

        [Test]
        public void ShouldConvertTwoWordsToHyphenSeparatedWords () {
            Assert.AreEqual ("two-words", NameConverter.Convert ("TwoWords"));
        }

        [Test]
        public void ShouldConvertAcronymWordToAcronymHyphenWord () {
            Assert.AreEqual ("t-words", NameConverter.Convert ("TWords"));
        }

        [Test]
        public void ShouldConvertWordAcronymWordToAcronymHyphenWord () {
            Assert.AreEqual ("lots-t-words", NameConverter.Convert ("LotsTWords"));
        }

        [Test]
        public void ShouldConvertLongAcronymWordToAcronymHyphenWord () {
            Assert.AreEqual ("io-socket", NameConverter.Convert ("IOSocket"));
        }

        [Test]
        public void ShouldConvertWordLongAcronymToWordHyphenAcronym () {
            Assert.AreEqual ("socket-io", NameConverter.Convert ("SocketIO"));
        }

        [Test]
        public void ShouldConvertWordLongAcronymWordToWordHyphenAcronymHyphenWord () {
            Assert.AreEqual ("big-io-socket", NameConverter.Convert ("BigIOSocket"));
        }

        [Test]
        public void ShouldConvertLongAcronymToLowerCaseAcronym () {
            Assert.AreEqual ("io", NameConverter.Convert ("IO"));
        }

        [Test]
        public void ShouldConvertNamespace () {
            Assert.AreEqual ("system:collections", NameConverter.ConvertNamespace ("System.Collections"));
        }
    }
}
