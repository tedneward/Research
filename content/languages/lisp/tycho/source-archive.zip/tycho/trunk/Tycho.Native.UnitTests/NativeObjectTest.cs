﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Runtime;
using Tycho.UnitTests.Evaluation;

namespace Tycho.Native.UnitTests {
    [TestFixture]
    public class NativeObjectTest {
        [Test]
        public void ShouldInvokeInstanceMethod () {
            AnyObject testType = CreateTestType ("nothing");
            Assert.IsTrue (((AnyObject) 12).Equals (testType.InvokeMethod (testType, Symbol.Parse ("instance-method"), 4, 8)));
        }

        private AnyObject CreateTestType (string value) {
            NativeTypeObject nativeType = new NativeTypeObject (typeof (TestType));

            return nativeType.CreateNew (nativeType, value);
        }

        [Test]
        public void ShouldGetInstanceField () {
            AnyObject testType = CreateTestType ("something");
            
            Assert.IsTrue (((AnyObject) "something").Equals (testType.GetProperty (Symbol.Parse ("instance-field"))));
        }

        [Test]
        public void ShouldSetInstanceField () {
            AnyObject testType = CreateTestType ("something");
            TestType nativeTestType = (TestType) testType.Expect<NativeObject> ().Object;

            testType.SetProperty (Symbol.Parse ("instance-field"), "something-else");
            Assert.IsTrue (((AnyObject) "something-else").Equals (testType.GetProperty (Symbol.Parse ("instance-field"))));
            Assert.AreEqual ("something-else", nativeTestType.InstanceField);
        }

        [Test]
        public void ShouldGetInstanceProperty () {
            AnyObject testType = CreateTestType ("something");

            Assert.IsTrue (((AnyObject) "something").Equals (testType.GetProperty (Symbol.Parse ("instance-property"))));
        }

        [Test]
        public void ShouldSetInstanceProperty () {
            AnyObject testType = CreateTestType ("something");
            TestType nativeTestType = (TestType) testType.Expect<NativeObject> ().Object;

            testType.SetProperty (Symbol.Parse ("instance-property"), "something-else");
            Assert.IsTrue (((AnyObject) "something-else").Equals (testType.GetProperty (Symbol.Parse ("instance-property"))));
            Assert.AreEqual ("something-else", nativeTestType.InstanceProperty);
        }

        [Test]
        public void SettingUndefinedPropertyShouldNotSetForAllTypes () {
            NativeTypeObject nativeType = new NativeTypeObject (typeof (TestType));

            AnyObject one = nativeType.CreateNew (nativeType, "one");
            AnyObject two = nativeType.CreateNew (nativeType, "two");

            one.SetProperty (Symbol.Parse ("x:y"), 45);

            Assert.Throws<NoSuchPropertyException> (() => two.GetProperty (Symbol.Parse ("x:y")));
        }
    }
}
