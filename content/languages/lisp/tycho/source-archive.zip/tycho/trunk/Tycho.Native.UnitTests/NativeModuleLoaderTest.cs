﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using Tycho.Runtime;
using System.Text.RegularExpressions;

namespace Tycho.Native.UnitTests {
    [TestFixture]
    public class NativeModuleLoaderTest {
        [Test]
        public void LoadSystemShouldWork () {
            NativeModuleLoader loader = new NativeModuleLoader (new Dictionary<Namespace, List<string>> ());

            loader.LoadAssembly (typeof (string).Assembly);

            AnyObject system = loader.LoadModule (Namespace.Parse ("system"), new string[0], null);

            Assert.AreEqual (typeof (String), system [Symbol.Parse ("system:string")].Expect<NativeTypeObject> ().Type);
            Assert.AreEqual (typeof (Exception), system [Symbol.Parse ("system:exception")].Expect<NativeTypeObject> ().Type);
        }

        [Test]
        public void LoadSystemFromNamespaceShouldWork () {
            Namespace systemNamespace = Namespace.Parse ("system");

            var assemblyMap = new Dictionary<Namespace, List<string>> ();
            assemblyMap[systemNamespace] = new List<string> {
                "System, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
                "mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"
            };

            var loader = new NativeModuleLoader (assemblyMap);

            AnyObject system = loader.LoadModule (systemNamespace, new string[0], null);

            Assert.AreEqual (typeof (String), system [Symbol.Parse ("system:string")].Expect<NativeTypeObject> ().Type);
            Assert.AreEqual (typeof (Exception), system [Symbol.Parse ("system:exception")].Expect<NativeTypeObject> ().Type);
        }

        public IEnumerable<string> GetNamespaces (string name) {
            var namespaces = new HashSet<string> ();
            var asm = Assembly.Load (name);
            foreach (Type type in asm.GetTypes ()) {
                if (type.Namespace != null) {
                    namespaces.Add (type.Namespace);
                }
            }

            return namespaces;
        }
    }
}
