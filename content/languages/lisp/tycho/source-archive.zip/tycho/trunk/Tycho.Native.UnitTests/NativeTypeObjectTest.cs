﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Runtime;

namespace Tycho.Native.UnitTests {
    [TestFixture]
    public class NativeTypeObjectTest {
        [Test]
        public void ShouldReturnNewNativeObject () {
            NativeTypeObject type = new NativeTypeObject (typeof (TestType));

            AnyObject instance = type.InvokeMethod (type, Symbols.RuntimeNew, "value");

            Assert.AreEqual (new TestType ("value"), instance.Expect<NativeObject> ().Object);
        }

        [Test]
        public void CannotCreateNewInterface () {
            NativeTypeObject type = new NativeTypeObject (typeof (ITestInterface));

            try {
                AnyObject instance = type.InvokeMethod (type, Symbols.RuntimeNew);
                Assert.Fail("expected TychoException");
            } catch (TychoException) {
            }
        }

        [Test]
        public void ShouldGetStaticVariableAndProperty () {
            NativeTypeObject type = new NativeTypeObject (typeof (TestType));

            Assert.IsTrue (((AnyObject) "class-variable").Equals (type.GetProperty (Symbol.Parse ("class-variable"))));
            Assert.IsTrue (((AnyObject) "class-property").Equals (type.GetProperty (Symbol.Parse ("class-property"))));
        }

        [Test]
        public void ShouldThrowExceptionForPropertyNotFound () {
            var type = new NativeTypeObject (typeof (TestType));

            Assert.Throws<NoSuchPropertyException> (() => type.GetProperty (Symbol.Parse ("no-property")));
        }

        [Test]
        public void ShouldInvokeStaticMethod () {
            var type = new NativeTypeObject (typeof (TestType));

            Assert.IsTrue (((AnyObject) 10).Equals (type.InvokeMethod (type, Symbol.Parse ("class-method"), 6, 4)));
        }

        [Test]
        public void ShouldThrowExceptionWhenWrongArgumentsArePassedToStaticMethod () {
            var type = new NativeTypeObject (typeof (TestType));

            Assert.Throws<NoMatchingMethodException> (() => type.InvokeMethod (type, Symbol.Parse ("class-method"), 6, "some string"));
        }
    }

    internal interface ITestInterface {
    }
}
