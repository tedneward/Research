﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Moq;
using NUnit.Framework;
using Tycho.Runtime;
using Tycho.Transactions;

namespace Tycho.Peyote.UnitTests {
    [TestFixture]
    public class EvaluationDependencyEngineTest {
        [Test]
        public void ShouldNotifyRegisteredDependency () {
            var dependentGlyph = new Mock<IDependencyNotificationListener> ();
            var sourceGlyph = new Mock<IDependencyNotificationListener> ();
            var obj = new Mock<ITransactionalObject> ();

            dependentGlyph.Expect (g => g.NotifyModifiedDependency (It.IsAny<CircularReferenceVigil> ()));

            EvaluationDependencyEngine engine = new EvaluationDependencyEngine ();
            var objects = new [] { obj.Object };
            engine.RegisterDependency (dependentGlyph.Object, objects);

            engine.NotifyModification (sourceGlyph.Object, objects, null);

            dependentGlyph.VerifyAll ();
        }

        [Test]
        public void ShouldNotNotifyRegisteredDependencyIfSource () {
            var sourceGlyph = new Mock<IDependencyNotificationListener> ();
            var obj = new Mock<ITransactionalObject> ();

            sourceGlyph.Expect (g => g.NotifyModifiedDependency (It.IsAny<CircularReferenceVigil> ())).Callback (() => Assert.Fail ("source glyph is not to be notified"));

            EvaluationDependencyEngine engine = new EvaluationDependencyEngine ();

            var objects = new [] { obj.Object };
            engine.RegisterDependency (sourceGlyph.Object, objects);
            engine.NotifyModification (sourceGlyph.Object, objects, null);
        }

        [Test]
        public void ShouldCreateNewCircularDependencyVigilIfNoneSpecified () {
            var sourceGlyph = new Mock<IDependencyNotificationListener> ();
            var obj = new Mock<ITransactionalObject> ();

            sourceGlyph.Expect (g => g.NotifyModifiedDependency (It.Is<CircularReferenceVigil> (c => c != null)));

            EvaluationDependencyEngine engine = new EvaluationDependencyEngine ();

            var objects = new [] { obj.Object };
            engine.RegisterDependency (sourceGlyph.Object, objects);
            engine.NotifyModification (sourceGlyph.Object, objects, null);
        }

        /// <summary>
        /// In this test, glyphA is dependent on objects from glyphB and
        /// visa versa. The engine should spot the circular dependency and
        /// not recurse forever.
        /// </summary>
        [Test]
        public void ShouldNotRecurseIntoCircularDependency () {
            var glyphA = new Mock<IDependencyNotificationListener> ();
            var glyphB = new Mock<IDependencyNotificationListener> ();
            var obj = new Mock<ITransactionalObject> ();
            var circularReferenceVigil = new CircularReferenceVigil ();

            var objects = new[] { obj.Object };

            EvaluationDependencyEngine engine = new EvaluationDependencyEngine ();
            glyphA.Expect (g => g.NotifyModifiedDependency (circularReferenceVigil)).Callback (() => engine.NotifyModification (glyphA.Object, objects, circularReferenceVigil));
            glyphB.Expect (g => g.NotifyModifiedDependency (circularReferenceVigil)).Callback (() => engine.NotifyModification (glyphB.Object, objects, circularReferenceVigil));

            engine.RegisterDependency (glyphA.Object, objects);
            engine.RegisterDependency (glyphB.Object, objects);

            engine.NotifyModification (glyphA.Object, objects, circularReferenceVigil);

            Assert.AreEqual (1, circularReferenceVigil.CircularReferences.Count);
            Assert.AreEqual (glyphB.Object, circularReferenceVigil.CircularReferences [0].DepA);
            Assert.AreEqual (glyphA.Object, circularReferenceVigil.CircularReferences [0].DepB);
        }

        [Test]
        public void OldDependenciesShouldBeReplacedByNewOnes() {
            var objA = new Mock<ITransactionalObject> ();
            var objB = new Mock<ITransactionalObject> ();
            var objC = new Mock<ITransactionalObject> ();

            var glyph = new Mock<IDependencyNotificationListener> ();
            var sourceGlyph = new Mock<IDependencyNotificationListener> ();

            bool wasNotified = false;

            glyph.Expect (g => g.NotifyModifiedDependency (It.IsAny<CircularReferenceVigil> ())).Callback (delegate () {
                wasNotified = true;
            });

            EvaluationDependencyEngine engine = new EvaluationDependencyEngine ();

            engine.RegisterDependency (glyph.Object, new [] { objA.Object, objC.Object });

            // this call should replace the dependency on objA so glyph should only
            // be dependent on objB.
            engine.RegisterDependency (glyph.Object, new [] { objB.Object, objC.Object });

            engine.NotifyModification (sourceGlyph.Object, new [] { objA.Object }, null);
            Assert.IsFalse (wasNotified);

            wasNotified = false;
            engine.NotifyModification (sourceGlyph.Object, new [] { objB.Object }, null);
            Assert.IsTrue (wasNotified);

            wasNotified = false;
            engine.NotifyModification (sourceGlyph.Object, new [] { objC.Object }, null);
            Assert.IsTrue (wasNotified);

            glyph.VerifyAll ();
        }
    }
}
