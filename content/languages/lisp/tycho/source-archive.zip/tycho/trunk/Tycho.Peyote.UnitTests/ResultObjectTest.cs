﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Runtime;

namespace Tycho.Peyote.UnitTests {
    [TestFixture]
    public class ResultObjectTest {
    }
}
