﻿using Tycho.Transactions;
using Tycho.Runtime;
using System.Collections.Generic;
using Tycho.Language;
using NUnit.Framework;

namespace TychoTest.Transactions
{
    [TestFixture]
    public class TransactionalObjectTest : TransactionalDataTests<TransactionalObject> {
        static TransactionalObjectTest () {
            AssemblyModuleLoader.LoadAssembly (Namespaces.Runtime, typeof (AnyObject).Assembly);
        }

        [SetUp]
        public void Setup () {
            Data = new TransactionalObject (new DictionaryObject (RuntimeModule.Dictionary), new AnyObject [] { Symbols.RuntimeIndexGet, Symbols.RuntimeGetProperty });
            Data.Transactionalise ();
        }

        protected override void AddValues1 (TransactionalObject l) {
            l ["one"] = "1";
            l ["two"] = "2";
            l ["three"] = "3";
        }

        protected override void AddValues2 (TransactionalObject l) {
            l ["eks"] = "x";
            l ["why"] = "y";
            l ["zed"] = "z";
        }

        protected override void ReadValues1 (TransactionalObject l) {
            AnyObject s = l ["one"];
            s = l ["three"];
            int c = l.Count;
        }

        protected override void VerifyValues1Exist (TransactionalObject d) {
            Assert.AreEqual ("1", d ["one"]);
            Assert.AreEqual ("2", d ["two"]);
            Assert.AreEqual ("3", d ["three"]);
            Assert.AreEqual (3, d.Count);
        }

        protected override void VerifyValues2Exist (TransactionalObject d) {
            Assert.AreEqual ("x", d ["eks"]);
            Assert.AreEqual ("y", d ["why"]);
            Assert.AreEqual ("z", d ["zed"]);
            Assert.AreEqual (3, d.Count);
        }

        protected override void VerifyValues1And2Exist (TransactionalObject d) {
            Assert.AreEqual ("1", d ["one"]);
            Assert.AreEqual ("2", d ["two"]);
            Assert.AreEqual ("3", d ["three"]);
            Assert.AreEqual ("x", d ["eks"]);
            Assert.AreEqual ("y", d ["why"]);
            Assert.AreEqual ("z", d ["zed"]);
            Assert.AreEqual (6, d.Count);
        }

        protected override void VerifyValues1DontExist (TransactionalObject d) {
            Assert.AreEqual (0, d.Count);
        }

        [Test]
        public new void TestRollBack () {
            base.TestRollBack ();
        }

        [Test]
        public new void TestCommit () {
            base.TestCommit ();
        }

        [Test]
        public new void TestLockConflict () {
            base.TestLockConflict ();
        }

        [Test]
        public new void TestWriteConflict () {
            base.TestWriteConflict ();
        }

        [Test]
        public new void TestOneReaderOneWriterNoConflict () {
            base.TestOneReaderOneWriterNoConflict ();
        }
    }
}
