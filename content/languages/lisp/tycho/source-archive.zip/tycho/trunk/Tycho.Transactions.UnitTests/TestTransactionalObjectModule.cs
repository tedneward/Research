﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using Tycho.Runtime;
using Tycho.Language;
using Tycho.Parser;
using Tycho.Transactions;
using NUnit.Framework;

namespace TychoTest.Transactions {
    [TestFixture]
    public class TransactionalObjectModuleTest {
        TransactionalTopLevel TopLevel;

        [SetUp]
        public void Initialize () {
            TopLevel = new TransactionalTopLevel (Namespaces.User);
        }

        [Test]
        public void TestNewStructure () {
            using (new TransactionScope ()) {
                AnyObject structure = TopLevel.Evaluate ("{a = 1, b = 2}");

                Assert.IsTrue (structure is TransactionalObject);
                Assert.AreEqual ((AnyObject) 1, structure.GetProperty (Namespaces.User.Get ("a")));
                Assert.AreEqual ((AnyObject) 2, structure.GetProperty (Namespaces.User.Get ("b")));
            }
        }
    }
}
