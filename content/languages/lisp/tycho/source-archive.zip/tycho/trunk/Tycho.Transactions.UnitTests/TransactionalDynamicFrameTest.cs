﻿using Tycho.Runtime;
using System.Transactions;
using System.Threading;
using NUnit.Framework;

namespace Tycho.Transactions.UnitTests {
    [TestFixture]
    public class TransactionalDynamicFrameTest {
        TransactionalDynamicFrameObject Frame;

        [SetUp]
        public void Initialize () {
            Frame = new TransactionalDynamicFrameObject (RuntimeModule.Null);
            Frame.Transactionalise ();
        }

        [Test]
        public void TestRollBack () {
            using (TransactionScope tx = new TransactionScope ()) {
                Frame ["something"] = "idiot";
            }

            using (TransactionScope tx = new TransactionScope ()) {
                Assert.IsFalse (Frame.HasVariable ("something"));
            }
        }

        [Test]
        public void TestNonTransactionalRollBack () {
            Frame = new TransactionalDynamicFrameObject (RuntimeModule.Null);

            using (TransactionScope tx = new TransactionScope ()) {
                Frame ["something"] = "idiot";
            }

            using (TransactionScope tx = new TransactionScope ()) {
                Assert.IsTrue (Frame.HasVariable ("something"));
            }
        }

        [Test]
        public void TestCommit () {
            using (TransactionScope tx = new TransactionScope ()) {
                Frame ["something"] = "idiot";
                tx.Complete ();
            }

            using (TransactionScope tx = new TransactionScope ()) {
                Assert.AreEqual ((AnyObject) "idiot", Frame ["something"]);
            }
        }

        [Test]
        public void TestConflictNewVariable () {
            Thread alsoAddVariable = new Thread (() => {
                using (TransactionScope tx = new TransactionScope ()) {
                    Frame ["x"] = "one";
                    tx.Complete ();
                }
            });

            try {
                using (TransactionScope tx = new TransactionScope ()) {
                    Frame ["x"] = "two";

                    alsoAddVariable.Start ();
                    alsoAddVariable.Join ();

                    tx.Complete ();
                }

                Assert.Fail ("expected thread to abort");
            } catch (TransactionAbortedException) {
            }
        }

        [Test]
        public void TestNoConflictNewDifferentVariables () {
            Thread alsoAddVariable = new Thread (() => {
                using (TransactionScope tx = new TransactionScope ()) {
                    Frame ["x"] = "one";
                    tx.Complete ();
                }
            });

            using (TransactionScope tx = new TransactionScope ()) {
                Frame ["y"] = "two";

                alsoAddVariable.Start ();
                alsoAddVariable.Join ();

                tx.Complete ();
            }
        }

        [Test]
        public void TestConflictSameVariable () {
            using (TransactionScope tx = new TransactionScope ()) {
                Frame ["x"] = "zero";
                tx.Complete ();
            }

            TestConflictNewVariable ();
        }

        [Test]
        public void TestOneReaderOneWriterNoConflict () {
            using (TransactionScope tx = new TransactionScope ()) {
                Frame ["x"] = "zero";
                tx.Complete ();
            }

            using (TransactionScope tx = new TransactionScope ()) {
                Assert.AreEqual ((AnyObject) "zero", Frame ["x"]);
                tx.Complete ();
            }

            Thread alsoAddVariable = new Thread (() => {
                using (TransactionScope tx = new TransactionScope ()) {
                    string x = (string) Frame ["x"];
                    tx.Complete ();
                }
            });

            using (TransactionScope tx = new TransactionScope ()) {
                Frame ["x"] = "two";

                alsoAddVariable.Start ();
                alsoAddVariable.Join ();

                tx.Complete ();
            }

            using (TransactionScope tx = new TransactionScope ()) {
                Assert.AreEqual ((AnyObject) "two", Frame ["x"]);
                tx.Complete ();
            }
        }
    }
}