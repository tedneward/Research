using NUnit.Framework;
using Tycho.Runtime;

namespace Tycho.Transactions.UnitTests {
    [TestFixture]
    public class TransactionalFrameTest {
        [Test]
        public void CreatingNewVariableShouldMakeFrameModified () {
            TransactionalFrame frame = new TransactionalFrame ();
            frame.Transactionalise ();

            long originalVersion = frame.Version;

            var tx = TransactionalObjectManager.RunTransaction (() => {
                frame ["x"] = "y";
            });

            Assert.IsTrue (tx.TouchedObjects.Contains (frame));
            Assert.IsTrue (tx.ModifiedObjects.Contains (frame));
            Assert.AreEqual (originalVersion + 1, frame.Version);
        }

        [Test]
        public void ModifyingExistingVariableShouldMakeFrameModified () {
            TransactionalFrame frame = new TransactionalFrame ();
            frame.Transactionalise ();

            // just set the variable first
            var tx = TransactionalObjectManager.RunTransaction (() => {
                frame ["x"] = "x";
            });

            long originalVersion = frame.Version;

            // then modify it
            tx = TransactionalObjectManager.RunTransaction (() => {
                frame ["x"] = "y";
            });

            Assert.IsTrue (tx.TouchedObjects.Contains (frame));
            Assert.IsTrue (tx.ModifiedObjects.Contains (frame));
            Assert.AreEqual (originalVersion + 1, frame.Version);
        }

        [Test]
        public void JustReadingVariableShouldNotMakeFrameModified () {
            TransactionalFrame frame = new TransactionalFrame ();
            frame.Transactionalise ();

            // just set the variable first
            var tx = TransactionalObjectManager.RunTransaction (() => {
                frame ["x"] = "x";
            });

            long originalVersion = frame.Version;

            AnyObject x = null;

            // then just read it
            tx = TransactionalObjectManager.RunTransaction (() => {
                x = frame ["x"];
            });

            Assert.AreEqual ((AnyObject) "x", x);
            Assert.IsTrue (tx.TouchedObjects.Contains (frame));
            Assert.IsFalse (tx.ModifiedObjects.Contains (frame));
            Assert.AreEqual (originalVersion, frame.Version);
        }
    }
}