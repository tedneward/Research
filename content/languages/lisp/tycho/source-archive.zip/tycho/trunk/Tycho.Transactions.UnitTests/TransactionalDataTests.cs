﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Transactions;
using System.Threading;
using NUnit.Framework;

namespace TychoTest.Transactions {
    public abstract class TransactionalDataTests<T> {
        protected abstract void AddValues1 (T d);
        protected abstract void AddValues2 (T d);
        protected abstract void ReadValues1 (T d);
        protected abstract void VerifyValues1Exist (T d);
        protected abstract void VerifyValues2Exist (T d);
        protected abstract void VerifyValues1And2Exist (T d);
        protected abstract void VerifyValues1DontExist (T d);

        protected T Data;

        [Test]
        public void TestRollBack () {
            using (TransactionScope tx = new TransactionScope ()) {
                AddValues1 (Data);
            }

            using (TransactionScope tx = new TransactionScope ()) {
                VerifyValues1DontExist (Data);
            }
        }

        [Test]
        public void TestCommit () {
            using (TransactionScope tx = new TransactionScope ()) {
                AddValues1 (Data);
                tx.Complete ();
            }

            using (TransactionScope tx = new TransactionScope ()) {
                VerifyValues1Exist (Data);
            }
        }

        [Test]
        public void TestLockConflict () {
            bool aborted = false;
            EventWaitHandle finishLock = new EventWaitHandle (false, EventResetMode.ManualReset);
            EventWaitHandle madeLock = new EventWaitHandle (false, EventResetMode.ManualReset);
            Thread lockDict = new Thread (() => {
                Monitor.Enter (Data);
                try {
                    madeLock.Set ();
                    finishLock.WaitOne ();
                } finally {
                    Monitor.Exit (Data);
                }
            });

            try {
                using (TransactionScope tx = new TransactionScope ()) {
                    AddValues1 (Data);

                    lockDict.Start ();
                    madeLock.WaitOne ();
                    Assert.IsFalse (Monitor.TryEnter (Data));

                    tx.Complete ();
                }

                Assert.Fail ("expected transaction aborted exception");
            } catch (TransactionAbortedException) {
                aborted = true;
            } finally {
                finishLock.Set ();
                lockDict.Join ();
            }

            Assert.IsTrue (aborted);
        }

        [Test]
        public void TestWriteConflict () {
            bool aborted = false;
            Thread conflictingTransaction = new Thread (() => {
                using (TransactionScope tx = new TransactionScope ()) {
                    AddValues2 (Data);
                    tx.Complete ();
                }
            });

            try {
                using (TransactionScope tx = new TransactionScope ()) {
                    AddValues1 (Data);

                    conflictingTransaction.Start ();
                    conflictingTransaction.Join ();

                    tx.Complete ();
                }

                Assert.Fail ("expected transaction aborted exception");
            } catch (TransactionAbortedException) {
                aborted = true;
            }

            Assert.IsTrue (aborted);
        }

        [Test]
        public void TestOneReaderOneWriterNoConflict () {
            using (TransactionScope tx = new TransactionScope ()) {
                AddValues1 (Data);
                tx.Complete ();
            }

            Thread alsoAddVariable = new Thread (() => {
                using (TransactionScope tx = new TransactionScope ()) {
                    ReadValues1 (Data);
                    tx.Complete ();
                }
            });

            using (TransactionScope tx = new TransactionScope ()) {
                AddValues2 (Data);

                alsoAddVariable.Start ();
                alsoAddVariable.Join ();

                tx.Complete ();
            }

            using (TransactionScope tx = new TransactionScope ()) {
                VerifyValues1And2Exist (Data);
            }
        }
    }
}
