﻿using System.Collections.Generic;
using NUnit.Framework;
using Tycho.Runtime;
using Assert=NUnit.Framework.Assert;

namespace Tycho.Transactions.UnitTests {
    [TestFixture]
    public class TransactionalObjectManagerTest {
        [SetUp]
        public void Setup() {
            RuntimeModule.Current = new TransactionalRuntimeModule ();
        }

        [Test]
        public void TouchedObjectsShouldReturnObjectsTouchedDuringTransaction () {
            Symbol property = Namespaces.User.Get ("property");
            AnyObject expectedPropertyValue = 4;
            AnyObject objA = RuntimeModule.CreateStructure (property, expectedPropertyValue);

            ((TransactionalObject) objA).Transactionalise ();

            AnyObject actualPropertyValue = null;
            var tx = TransactionalObjectManager.RunTransaction (() => {
                actualPropertyValue = objA.GetProperty (property);
            });

            Assert.AreEqual (4, actualPropertyValue.ExpectValue<int> ());
            HashSet<ITransactionalObject> touchedObjects = new HashSet<ITransactionalObject> (tx.TouchedObjects, new ReferenceEqualityComparer<ITransactionalObject> ());
            Assert.AreEqual (1, touchedObjects.Count);
            Assert.IsTrue (touchedObjects.Contains ((ITransactionalObject) objA));
            Assert.AreEqual (0, tx.ModifiedObjects.Count);
        }

        [Test]
        public void ModifiedObjectsShouldReturnObjectsModifiedDuringTransaction () {
            Symbol property = Namespaces.User.Get ("property");
            AnyObject expectedPropertyValue = 4;
            AnyObject objA = RuntimeModule.CreateStructure ();

            ((TransactionalObject) objA).Transactionalise ();

            var tx = TransactionalObjectManager.RunTransaction (() => objA.SetProperty (property, expectedPropertyValue));

            HashSet<ITransactionalObject> touchedObjects = new HashSet<ITransactionalObject> (tx.TouchedObjects, new ReferenceEqualityComparer<ITransactionalObject> ());
            HashSet<ITransactionalObject> modifiedObjects = new HashSet<ITransactionalObject> (tx.ModifiedObjects, new ReferenceEqualityComparer<ITransactionalObject> ());

            Assert.AreEqual (1, touchedObjects.Count);
            Assert.IsTrue (touchedObjects.Contains ((ITransactionalObject) objA));

            Assert.AreEqual (1, modifiedObjects.Count);
            Assert.IsTrue (modifiedObjects.Contains ((ITransactionalObject) objA));
        }
    }
}
