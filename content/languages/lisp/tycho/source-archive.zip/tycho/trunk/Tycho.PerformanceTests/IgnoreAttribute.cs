using System;

namespace Tycho.PerformanceTests {
    [AttributeUsage (AttributeTargets.Method)]
    class IgnoreAttribute : Attribute {
    }
}