﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tycho.PerformanceTests {
    public class MemoTable {
        private static int Iterations = 10000000;

        struct MemoTableKey {
            private Production Production;
            private int index;

            public MemoTableKey (Production production, int index) {
                Production = production;
                this.index = index;
            }
        }

        [BenchMark]
        public static void MemoTableAdd () {
            var memoTable = new Dictionary<MemoTableKey, ParseResult> ();

            for (int n = 0; n < Iterations; n++) {
                memoTable.Add (new MemoTableKey (new Production (), n), new ParseResult ());
            }
        }

        [BenchMark]
        public static void MemoTableAddIndex () {
            var memoTable = new Dictionary<int, ParseResult> ();

            for (int n = 0; n < Iterations; n++) {
                memoTable.Add (n, new ParseResult ());
            }
        }
    }

    public class ParseResult {}

    internal class Production { }
}
