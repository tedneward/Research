// Parser.h

#pragma once

#include "parser.h"

using namespace System;

namespace Tycho {
namespace Lexer {
	public ref class NativeLexer
	{
	public:
		static System::Collections::Generic::List<Tycho::Parser::Tokens::Token^> ^Lex (System::String ^code);
		static System::Collections::Generic::List<Tycho::Parser::Tokens::Token^> ^Lex (System::String ^code, System::String ^fileName);
		static System::Collections::Generic::List<Tycho::Parser::Tokens::Token^> ^InterpolateString (System::String ^string, Tycho::Parser::Tokens::SourceLocation ^sloc);

		static NativeLexer () {
			init_tokenizer ();
		}
	};
}
}