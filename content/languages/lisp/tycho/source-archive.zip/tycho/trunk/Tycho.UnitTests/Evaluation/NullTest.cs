using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class NullTest {
        [Test]
        public void NullShouldEqualNull () {
            Script.Test ("null == null", "> true");
        }

        [Test]
        public void NullShouldNotEqualNotNull () {
            Script.Test ("null == 8", "> false");
        }

        [Test]
        public void NotNullShouldNotEqualNull () {
            Script.Test ("8 == null", "> false");
        }
    }
}