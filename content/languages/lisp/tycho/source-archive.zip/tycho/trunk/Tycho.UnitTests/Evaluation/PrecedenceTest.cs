﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class PrecedenceTest {
        [Test]
        public void PropertyGetShouldBeHigherThanIndexGet () {
            Script.Test (
@"x = struct {a := list [1, 2, 3]}
x.a [1]",

"> 2");
        }

        [Test]
        public void AndShouldBeLowerPrecedenceThanEquals () {
            Script.Test (
@"8 == 8 and true",

@"> true");
        }

        [Test]
        public void AndShouldBeLowerPrecedenceThanEquals2 () {
            Script.Test (
@"true and 8 == 8",

@"> true");
        }

    }
}
