using Moq;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class NonTerminalBuilderSpecification {
        [Test]
        public void ShouldSetAllProperties () {
            var nt = new NonTerminal();

            var builder = new NonTerminalBuilder ();
            var rule = new Mock<IRule> ();
            rule.SetupGet (r => r.IsInfix).Returns (false);

            var multiples = new[] {"one"};
            var ruleCaptures = new RuleCaptures {
                                                    FirstCapture = "first",
                                                    LastCapture = "last",
                                                    MultipleCaptures = multiples,
                                                    Rule = rule.Object
                                                };

            var precedenceContext = new Mock<IProduction> ().Object;
            var choicePrecedence = new ChoicePrecedence (precedenceContext, 3);

            builder.Build ("name", nt, ruleCaptures);

            Assert.That (nt.Name, Is.EqualTo ("name"));
            Assert.That (nt.FirstCaptureName, Is.EqualTo ("first"));
            Assert.That (nt.LastCaptureName, Is.EqualTo ("last"));
            Assert.That (nt.Rule, Is.SameAs (rule.Object));
            Assert.That (nt.Multiples, Is.EquivalentTo (multiples));
        }
    }
}