using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;
using Tycho.Parser.Tests.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class DelimitedSpecification {
        [Test]
        public void ShouldParseDelimited () {
            IProduction production = GrammarLoader.CreateDelimited (IdentifierProduction.CreateTerminal ());

            ITerm t = production.ParseTerm ("a b ...");
            Assert.IsNotNull (t);
            var term = t as CompositeTerm;
            Assert.IsNotNull (term);
            Assert.AreEqual ("delimited", term.Name);
            Assert.AreEqual (2, term.SubTerms.Count);
            var rule = term.SubTerms["rule"] as IdentifierTerm;
            var delimiter = term.SubTerms["delimiter"] as IdentifierTerm;
            Assert.IsNotNull (rule);
            Assert.IsNotNull (delimiter);
            Assert.AreEqual ("a", rule.Name);
            Assert.AreEqual ("b", delimiter.Name);
        }

        [Test]
        public void ShouldNotParse () {
            IProduction production = GrammarLoader.CreateDelimited (IdentifierProduction.CreateTerminal ());

            production.AssertNotParsed ("a b c");
            production.AssertNotParsed ("a ...");
            production.AssertNotParsed ("a b");
        }
    }
}