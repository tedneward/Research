using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class ProductionSpecification {
        [Test]
        public void ShouldParseProductionGrammar () {
            IProduction production = GrammarLoader.CreateProduction ();

            AssertParsed (production, "identifier");
            AssertParsed (production, "integer");
            AssertParsed (production, "real");
            AssertParsed (production, "nt {'a' x:integer 'b'}");
            AssertParsed (production, "string");
            AssertParsed (production, "string identifier");
            AssertParsed (production, "#x");
            AssertParsed (production, "choice {identifier, integer}");
        }

        private static void AssertParsed (IProduction production, string source) {
            Assert.IsNotNull (production.ParseTerm (source));
        }
    }
}