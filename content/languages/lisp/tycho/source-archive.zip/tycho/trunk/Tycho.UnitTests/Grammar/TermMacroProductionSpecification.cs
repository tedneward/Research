using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class TermMacroProductionSpecification {
        [Test]
        public void ShouldParse () {
            IProduction prod = GrammarLoader.CreateTermMacro (IdentifierProduction.CreateTerminal ());

            ITerm t = prod.ParseTerm (@"macro {left: id '+' right: id} => term plus {left: #left, right: #right}");

            t.ShouldBe (@"term-macro {rule: sequence {rules: [capture {name: left, production: id}, keyword {name: '+'}, capture {name: right, production: id}]}, term: composite-term {name: plus, sub-terms: [sub-term {name: left, term: expression {name: left}}, sub-term {name: right, term: expression {name: right}}]}}");
        }
    }
}