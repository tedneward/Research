﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class SubExpressionTest {
        [Test]
        public void ShouldReturnValueOfLastExpression () {
            Script.Test (@"{a = 1; a}", "> 1");
        }

        [Test]
        public void ShouldReturnNullIfEmpty () {
            Script.Test (@"{}", "> null");
        }

        [Test]
        public void ShouldNotReturnFromWholeExpression () {
            Script.Test (@"4 + {3 * 2}", "> 10");
        }

        [Test]
        public void ShouldNotReturnNullFromWholeExpression () {
            Script.Test (@"print {}", "null\r\n> null");
        }

        [Test]
        public void ShouldReturnInnerExpressionValue () {
            Script.Test (@"a = 1; (a)", "> 1");
        }

        [Test]
        public void ShouldOnlyPushLastValueOntoStack () {
            Script.Test (
@"f = (a, b) => a + b
f ({1; 2}, {3; 4})",

@"> 6");
        }

    }
}
