using System;
using Moq;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class DynamicParserSpecification {
        [Test]
        public void ShouldPassFilenameThroughToSourceInformation () {
            var production = new Mock<IProduction> ();

            var dynamicParser = new DynamicParser (new Mock<IDynamicGrammar> ().Object, production.Object);
            
            production.Setup(p => p.Parse (It.IsAny<char[]> (), It.IsAny<int> (), It.IsAny<ParseContext> (), It.IsAny<string> (), It.IsAny<ParseEnvironment> ()))
                .Returns (new ParseResult ("source".Length, new Mock<ITerm> ().Object, new ParseContext()));

            const string filename = "filename";

            dynamicParser.ParseTerm ("source", filename);

            production.Verify(p => p.Parse (It.IsAny<char[]> (), It.IsAny<int> (), It.IsAny<ParseContext> (), It.IsAny<string> (), It.Is<ParseEnvironment> (pe => pe.SourceFileInformation.FileName == filename)));
        }
    }
}