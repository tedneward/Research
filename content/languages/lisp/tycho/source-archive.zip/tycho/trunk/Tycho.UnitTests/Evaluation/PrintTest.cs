﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class PrintTest {
        
        [Test]
        public void ShouldPrintInEvaluatableForm () {
            Script.Test (
@"print ""string""",

@"""string""
> null");
        }

        [Test]
        public void ShouldAcceptMultipleArgumentsAndPrintDelimitedWithCommas () {
            Script.Test (
@"print 1, 2, 3",

@"1, 2, 3
> null");
        }

    }
}
