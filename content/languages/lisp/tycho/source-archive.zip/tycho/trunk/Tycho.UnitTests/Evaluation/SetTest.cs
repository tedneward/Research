﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class SetTest {
        [Test]
        public void LiteralShouldTakeUniqueValues () {
            Script.Test (
@"set {1, 2, 2}",

@"> set {1, 2}");
        }

        [Test]
        public void AddShouldOnlyAddUniqueValues () {
            Script.Test (
@"s = set {}
s.tycho:runtime:add (1)
s.tycho:runtime:add (1)
s.tycho:runtime:add (""one"")
s.tycho:runtime:add (""one"")
s",

@"> set {""one"", 1}");
        }
        
        [Test]
        public void ToStringShouldWriteOutValuesInAlphabeticalOrder () {
            Script.Test (
@"set {1, 2, 11, 12}",

@"> set {1, 11, 12, 2}");
        }

        [Test]
        public void IntersectionShouldReturnIntersectionOfSets () {
            Script.Test (
@"set {1, 2, 3}.tycho:runtime:intersection(set {2, 3, 4})",

@"> set {2, 3}");
        }

        [Test]
        public void UnionShouldReturnUnionOfSets () {
            Script.Test (
@"set {1, 2, 3}.tycho:runtime:union(set {2, 3, 4})",

@"> set {1, 2, 3, 4}");
        }

        [Test]
        public void MinusShouldReturnSetWithoutOtherSetValues () {
            Script.Test (
@"set {1, 2, 3}.tycho:runtime:minus(set {2, 3, 4})",

@"> set {1}");
        }

        [Test]
        public void MinusOperatorShouldReturnSetWithoutOtherSetValues () {
            Script.Test (
@"set {1, 2, 3} - set {2, 3, 4}",

@"> set {1}");
        }

        [Test]
        public void MultiplyShouldReturnCartesianProduct () {
            Script.Test (
@"set {1, 2} * set {""one"", ""two""}",

@"> set {list [1, ""one""], list [1, ""two""], list [2, ""one""], list [2, ""two""]}");
        }

        [Test]
        public void LessThanShouldReturnTrueIfSetIsSubsetAndSmallerThan () {
            Script.Test (
@"set {1, 2} < set {1, 2, 3}",

@"> true");
        }

        [Test]
        public void LessThanShouldReturnFalseIfSetIsSubsetAndNotSmallerThan () {
            Script.Test (
@"set {1, 2, 3} < set {1, 2, 3}",

@"> false");
        }

        [Test]
        public void LessThanShouldReturnFalseIfSetIsNotSubset () {
            Script.Test (
@"set {1, 4} < set {1, 2, 3}",

@"> false");
        }

        [Test]
        public void LessThanEqualToShouldReturnTrueIfSetsAreEqual () {
            Script.Test (
@"set {1, 4} <= set {1, 4}",

@"> true");
        }

        [Test]
        public void GreaterThanShouldReturnFalseIfSubset () {
            Script.Test (
@"set {1, 2} > set {1, 2, 3}",

@"> false");
        }

        [Test]
        public void GreaterThanShouldReturnFalseIfSetsAreEqual () {
            Script.Test (
@"set {1, 2, 3} > set {1, 2, 3}",

@"> false");
        }

        [Test]
        public void GreaterThanShouldReturnTrueIfProperSuperset () {
            Script.Test (
@"set {1, 2, 3} > set {1, 2}",

@"> true");
        }

        [Test]
        public void GreaterThanEqualToShouldReturnTrueIfSetsAreEqual () {
            Script.Test (
@"set {1, 2, 3} >= set {1, 2, 3}",

@"> true");
        }

        [Test]
        public void ContainsShouldReturnTrueIfItemIsInSet () {
            Script.Test (
@"set {1, 2, 3}.tycho:runtime:contains(2)",

@"> true");
        }

        [Test]
        public void ContainsShouldReturnFalseIfItemIsNotInSet () {
            Script.Test (
@"set {1, 2, 3}.tycho:runtime:contains(4)",

@"> false");
        }

        [Test]
        public void RemoveShouldRemoveItemFromSetAndReturnTrue () {
            Script.Test (
@"s = set {1, 2, 3}
s.tycho:runtime:remove(1)",

@"> true");
        }

        [Test]
        public void RemoveShouldReturnFalseIfItemCannotBeFoundToRemove () {
            Script.Test (
@"s = set {1, 2, 3}
s.tycho:runtime:remove(4)",

@"> false");
        }

    }
}
