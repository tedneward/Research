﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class SchemaTest {

        [Test]
        public void ShouldMatchStructure () {
            Script.Test (
@"str = struct {name := ""zack"", favourite-colour := ""red""}
sch = schema {name, favourite-colour}
str :: sch",

@"> true");
        }

        [Test]
        public void ShouldNotMatchStructure () {
            Script.Test (
@"str = struct {name := ""zack"", favourite-colour := ""red""}
sch = schema {name, favourite-shape}
str :: sch",

@"> false");
        }

        [Test]
        public void ShouldMatchList () {
            Script.Test (
@"l = list [1, 2, 3, 4]
s = schema [_, _, _, _]
l :: s",

@"> true");
        }

        [Test]
        public void ShouldNotMatchList () {
            Script.Test (
@"l = list [1, 2, 3, 4]
s = schema [_, _, _]
l :: s",

@"> false");
        }

        [Test]
        public void ShouldMatchObjectImplementingProtocol () {
            Script.Test (
@"p = protocol
obj = struct {tycho:runtime:protocols-implemented := set {p}}
obj :: p",

@"> true");
        }

        [Test]
        public void ShouldNotMatchObjectNotImpelementingProtocol () {
            Script.Test (
@"p = protocol
other-protocol = protocol
obj = struct {tycho:runtime:protocols-implemented := set {other-protocol}}
obj :: p",

@"> false");
        }

        [Test]
        public void ShouldNotMatchObjectNotImplementingAnything () {
            Script.Test (
@"p = protocol
obj = struct {name := ""something""}
obj :: p",

@"> false");
        }

    }
}
