﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class QuoteTest {
        [Test]
        public void ShouldReturnTermStructure () {
            Script.Test (
@"quote a * b",

@"> struct {tycho:parser:term-name := tycho:parser:method-call, tycho:parser:object := struct {tycho:parser:term-name := tycho:parser:identifier, tycho:parser:identifier := ""a"", tycho:parser:module := list [""user""]}, tycho:parser:name := struct {tycho:parser:term-name := tycho:parser:identifier, tycho:parser:identifier := ""multiply"", tycho:parser:module := list [""tycho"", ""runtime""]}, tycho:parser:arguments := list [struct {tycho:parser:term-name := tycho:parser:identifier, tycho:parser:identifier := ""b"", tycho:parser:module := list [""user""]}]}");
        }

        [Test]
        public void ShouldQuoteMacro () {
            Script.Test (
@"macro inc ""inc"" n {#n}
quote inc x",

@"> struct {tycho:parser:term-name := tycho:parser:sub-expression-block, tycho:parser:expression := list [struct {tycho:parser:term-name := tycho:parser:identifier, tycho:parser:identifier := ""x"", tycho:parser:module := list [""user""]}]}");
        }

        [Test]
        public void ShouldQuoteSyntax () {
            Script.Test (
@"syntax inc ""inc"" n
quote inc x",

@"> struct {tycho:parser:term-name := tycho:parser:inc, tycho:parser:n := struct {tycho:parser:term-name := tycho:parser:identifier, tycho:parser:identifier := ""x"", tycho:parser:module := list [""user""]}}");
        }

        [Test]
        public void ShouldQuoteSyntaxInMacro () {
            Script.Test (
@"syntax inc ""inc"" n
macro my-quote ""my-quote"" s
    quote #s
my-quote inc x",

@"> struct {tycho:parser:term-name := tycho:parser:inc, tycho:parser:n := struct {tycho:parser:term-name := tycho:parser:identifier, tycho:parser:identifier := ""x"", tycho:parser:module := list [""user""]}}");
        }

        [Test]
        public void MacroShouldPassMultipleExpressionsIntoFunctionCall () {
            Script.Test (
@"f = (i, ...) => {print i; i}
macro call-f ""call-f"" args "","" ... {user:f (#args, #...)}
call-f 1, 2, 3, 4, 5",

@"list [1, 2, 3, 4, 5]
> list [1, 2, 3, 4, 5]");
        }

        [Test]
        public void MacroShouldPassMultipleExpressionsIntoFunctionCallWithFirstArgument () {
            Script.Test (
@"f = (i, ...) => {print i; i}
macro call-f ""call-f"" args "","" ... {user:f (0, #args, #...)}
call-f 1, 2, 3, 4, 5",

@"list [0, 1, 2, 3, 4, 5]
> list [0, 1, 2, 3, 4, 5]");
        }

        [Test]
        public void MacroShouldPassMultipleExpressionsIntoFunctionCallWithFirstArgumentAndLastArgument () {
            Script.Test (
@"f = (i, ...) => {print i; i}
macro call-f ""call-f"" args "","" ... {user:f (0, #args, #..., 6)}
call-f 1, 2, 3, 4, 5",

@"list [0, 1, 2, 3, 4, 5, 6]
> list [0, 1, 2, 3, 4, 5, 6]");
        }

    }
}
