using NUnit.Framework;
using Tycho.Runtime;

namespace TychoTest.Runtime {
    [TestFixture]
    public class SymbolTest {
        [Test]
        public void ParseShouldReturnSameSymbolInstanceAsGet () {
            Assert.IsTrue (Symbol.Parse ("user:x") == Namespaces.User.Get ("x"));
            Assert.IsTrue (Symbol.Parse ("my-namespace:x") == Namespaces.Root.GetNamespace ("my-namespace").Get ("x"));
        }

        [Test]
        public void ParseShouldUseDefaultNamespaceIfSymbolIsWithoutNamespace () {
            Assert.IsTrue (Symbol.Parse ("x") == Namespaces.Root.Get ("x"));
            Assert.IsTrue (Symbol.Parse ("x") == Symbol.Parse ("x"));
            Assert.IsTrue (Symbol.Parse ("x", Namespaces.Root.GetNamespace ("my-namespace")) == Namespaces.Root.GetNamespace ("my-namespace").Get ("x"));
        }

        [Test]
        public void ParseShouldNotUseDefaultNamespaceIfSymbolIsWithNamespace () {
            Assert.IsTrue (Symbol.Parse ("user:x") == Namespaces.User.Get ("x"));
            Assert.IsTrue (Symbol.Parse ("my-namespace:x", Namespaces.Runtime) == Namespaces.Root.GetNamespace ("my-namespace").Get ("x"));
        }
    }
}