﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class ClosureTest {
        [Test]
        public void TestEmptyClosure () {
            Script.Test (
@"c = () => {}
c ()",

@"> null");
        }

        [Test]
        public void TestUnaryInBlock () {
            Script.Test (
@"f = (n) => {n + 1}
f (4)",

@"> 5");
        }

        [Test]
        public void TestUnaryNoBlock () {
            Script.Test (
@"f = (n) => n + 1
f (4)",

@"> 5");
        }

        [Test]
        public void TestUnaryInBrackets () {
            Script.Test (
@"f = (n) => (n + 1)
f (4)",

@"> 5");
        }

        [Test]
        public void TestStructureParameter () {
            Script.Test (
@"f = ({j}) => j + 1
f (struct {j := 5})",

@"> 6");
        }

        [Test]
        public void TestSchema () {
            Script.Test (
@"s = schema [_, _]
f = (j :: s) => j [0]
f (list [1, 2])",

@"> 1");
        }

        [Test]
        public void TestStructureSchema () {
            Script.Test (
@"s = schema {a, b}
f = (j :: s) => j.a
f (struct {a := 1, b := 2})",

@"> 1");
        }

        [Test]
        public void ShouldTakeMultipleArgumentsAsList () {
            Script.Test (
@"f = (args, ...) => print args
f (1, 2, 3)",

@"list [1, 2, 3]
> null");
        }

        [Test]
        public void ShouldCallWithListAsMultipleArguments () {
            Script.Test (
@"f = (a, b, c) => print list [a + 1, b + 2, c + 3]
f (list [1, 2, 3], ...)",

@"list [2, 4, 6]
> null");
        }

        [Test]
        public void ShouldTakeMultipleArgumentsAsListAsLastArgument () {
            Script.Test (
@"f = (i, args, ...) => print list [i, args]
f (0, 1, 2, 3)",

@"list [0, list [1, 2, 3]]
> null");
        }

        [Test]
        public void ShouldCallWithListAsMultipleArgumentsAsLastArgument () {
            Script.Test (
@"f = (a, b, c) => print list [a + 1, b + 2, c + 3]
f (1, list [2, 3], ...)",

@"list [2, 4, 6]
> null");
        }

        [Test]
        public void ShouldAcceptArgumentsSpecifiedInBlock () {
            Script.Test (
@"f = (a, ...) => print a
f {10; 20; 30}",

@"list [10, 20, 30]
> null");
        }

        [Test]
        public void ShouldBeLeftAssociative () {
            Script.Test (
@"curry-add = (a) => (b) => a + b
curry-add (1) (2)",

@"> 3");
        }

        [Test]
        public void DispatchMethodShouldReturnMethodWhenArgumentsMatchParameters () {
            Script.Test (
@"f = (a :: tycho:runtime:string, b :: 8) => a + b
method = f.tycho:runtime:dispatch-method (symbol tycho:runtime:invoke, ""some string"", 8)
method ()",

@"> ""some string8""");
        }

        [Test]
        public void DispatchMethodShouldReturnNullWhenArgumentsMatchParameters () {
            Script.Test (
@"f = (a :: tycho:runtime:string, b :: 8) => a + b
method = f.tycho:runtime:dispatch-method (symbol tycho:runtime:invoke, ""some string"", 9)
method == null",

@"> true");
        }
        
        [Test]
        public void ShouldTakeExpressionParensAsSchema () {
            Script.Test (
@"f = ((8 + 4)) => 7
f (12)",

@"> 7");
        }

    }
}
