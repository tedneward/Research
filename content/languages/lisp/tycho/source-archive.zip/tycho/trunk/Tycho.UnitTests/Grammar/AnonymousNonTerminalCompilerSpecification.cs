using Moq;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class AnonymousNonTerminalCompilerSpecification {
        [Test]
        public void NameOfTest () {
            var ruleCompiler = new Mock<IRuleCompiler> ();
            ITerm ruleTerm = new Mock<ITerm> ().Object;
            ICaptureCounter captureCounter = new Mock<ICaptureCounter> ().Object;

            var context = new ProductionCompilerContext (null, null, null, null);

            IRule rule = new Mock<IRule> ().Object;
            ruleCompiler.Setup (r => r.Compile (ruleTerm, context, captureCounter)).Returns (rule);

            var compiler = new AnonymousNonTerminalCompiler (ruleCompiler.Object, () => captureCounter);

            var term = new CompositeTerm ("anonymous-non-terminal", null);
            term.Add ("rule", ruleTerm, false);

            GrammarTree grammarTree = compiler.Compile (term, null, context);

            Assert.That (grammarTree.Production, Is.InstanceOf (typeof (RuleProduction)));
            var ruleProduction = (RuleProduction) grammarTree.Production;
            Assert.That (ruleProduction.Rule, Is.SameAs (rule));
        }
    }
}