using System.Collections.Generic;
using Moq;
using NUnit.Framework;
using Tycho.Lexer;
using Tycho.Parser;
using Tycho.Parser.Tokens;

namespace Tycho.UnitTests.Parser {
    [TestFixture]
    public class BracketPatternTest {
        [Test]
        public void CompiledNodesShouldMatchGivenPattern () {
            BracketPattern pattern = new BracketPattern (new KeywordPattern ("a"), BracketType.Brace);
            NodePair nodePair = pattern.CompileNodes ();

            var production = new Production (null, new ProductionItem [0]);
            nodePair.LastTransitionNode.Transitions.Add (new FinishTransition (new FinishNode (production, false)));
            List<Token> tokens = NativeLexer.Lex ("{a}");

            var match = nodePair.First.Match (tokens, 0, new HashSet<NodeIndex> ());
            Assert.IsNotNull (match);
        }
    }
}