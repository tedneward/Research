using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;
using Tycho.Parser.Tests.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class StringSpecification {
        [Test]
        public void ShouldParseIntegerKeyword () {
            IProduction production = GrammarLoader.CreateString (IntegerProduction.CreateTerminal ());

            ITerm term = production.ParseTerm ("string");
            Assert.IsNotNull (term);
            var compositeTerm = term as CompositeTerm;
            Assert.IsNotNull (compositeTerm);
            Assert.AreEqual ("string", compositeTerm.Name);
            Assert.AreEqual (0, compositeTerm.SubTerms.Count);
        }

        [Test]
        public void ShouldParseInterpolatedString () {
            IProduction production = GrammarLoader.CreateString (IntegerProduction.CreateTerminal ());

            ITerm term = production.ParseTerm ("string 8");
            Assert.IsNotNull (term);
            var compositeTerm = term as CompositeTerm;
            Assert.IsNotNull (compositeTerm);
            Assert.AreEqual ("string", compositeTerm.Name);
            Assert.AreEqual (1, compositeTerm.SubTerms.Count);
            Assert.AreEqual (8, ((IntegerTerm) compositeTerm.SubTerms["interpolation-production"]).Value);
        }

        [Test]
        public void ShouldNotParse () {
            IProduction production = GrammarLoader.CreateString (IntegerProduction.CreateTerminal ());

            production.AssertNotParsed ("str");
            production.AssertNotParsed ("string t");
            production.AssertNotParsed ("r");
            production.AssertNotParsed ("8");
        }
    }
}