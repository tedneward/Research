﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class StringTest {
        
        [Test]
        public void TestConcatInteger () {
            Script.Test (
@"""one == "" + 1",

@"> ""one == 1""");
        }
        
        [Test]
        public void TestCount () {
            Script.Test (
@"""three"".tycho:runtime:count",

@"> 5");
        }

        [Test]
        public void TestRepeat () {
            Script.Test (
@"""repeat"" * 3",

@"> ""repeatrepeatrepeat""");
        }

        [Test]
        public void ShouldEscape () {
            Assert.AreEqual ("\t\n\r\\\"", Script.Evaluate (@"""\t\n\r\\\""""").ExpectValue<string> ());
        }

        [Test]
        public void ShouldNotEscape () {
            Assert.AreEqual ("\\t\\n\\r\\\\\\'", Script.Evaluate (@"'\t\n\r\\\''").ExpectValue<string> ());
        }

        [Test]
        public void ShouldInterpolateInteger () {
            Script.Test (
@"a = 6
""a = #a""",

@"> ""a = 6""");
        }

        [Test]
        public void ShouldNotInterpolateInteger () {
            Script.Test (
@"a = 6
'a = #a'",

@"> ""a = #a""");
        }

        [Test]
        public void ShouldInterpolateExpression () {
            Script.Test (
@"a = 6
""a = #(a * 4)""",

@"> ""a = 24""");
        }

        [Test]
        public void ShouldInterpolateBraceExpression () {
            Script.Test (
@"a = 6
""a = #{a * 4}""",

@"> ""a = 24""");
        }

        [Test]
        public void ShouldEscapeInterpolatedExpression () {
            Script.Test (
@"a = 6
""a = \#(a * 4)""",

@"> ""a = #(a * 4)""");
        }

        [Test]
        public void ShouldEscapeDollarCharacter () {
            Script.Test (
@"""cost is \#4""",

@"> ""cost is #4""");
        }

        [Test]
        public void ShouldInterpolateTwoVariablesInARow () {
            Script.Test (
@"a = 4
b = 5
""#a#b""",

@"> ""45""");
        }

        [Test]
        public void ShouldInterpolateVariableAtStartOfString () {
            Script.Test (
@"a = 4
b = 5
c = 6
""#a #b #c""",

@"> ""4 5 6""");
        }

        [Test]
        public void MultilineLiteralShouldInterpolate () {
            Script.Test (
@"value = ""a string""
{:
one
two
#value
three
four
:}",

@"> ""\none\ntwo\na string\nthree\nfour\n");
        }

        
        [Test]
        public void ShouldInterpolateJustOneValue () {
            Script.Test (
@"value = 8
""#value""",

@"> ""8""");
        }

        [Test]
        public void ToStringShouldEscapeTabs () {
            Script.Test (
@"""\t""",

@"> ""\t""");
        }

        [Test]
        public void ToStringShouldEscapeCarriageReturns () {
            Script.Test (
@"""\r""",

@"> ""\r""");
        }

        [Test]
        public void ToStringShouldEscapeNewLines () {
            Script.Test (
@"""\n""",

@"> ""\n""");
        }

        [Test]
        public void ToStringShouldEscapeBackSlashes () {
            Script.Test (
@"""\\""",

@"> ""\\""");
        }

        [Test]
        public void ToStringShouldEscapeDoubleQuotes () {
            Script.Test (
@"""\""""",

@"> ""\""""");
        }

    }
}
