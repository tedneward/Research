using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;
using Tycho.Parser.Tests.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class IntegerSpecification {
        [Test]
        public void ShouldParseIntegerKeyword () {
            IProduction production = GrammarLoader.CreateInteger ();

            ITerm term = production.ParseTerm ("integer");
            Assert.IsNotNull (term);
            var compositeTerm = term as CompositeTerm;
            Assert.IsNotNull (compositeTerm);
            Assert.AreEqual ("integer", compositeTerm.Name);
            Assert.AreEqual (0, compositeTerm.SubTerms.Count);
        }

        [Test]
        public void ShouldNotParse () {
            IProduction production = GrammarLoader.CreateInteger ();

            production.AssertNotParsed ("id3");
            production.AssertNotParsed ("i");
            production.AssertNotParsed ("8");
        }
    }
}