using Moq;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class MultipleRuleCompilerSpecification {
        [Test]
        public void ShouldCompileRuleWithMultipleCaptureCounter () {
            var ruleCompiler = new Mock<IRuleCompiler> ();
            var multipleCompiler = new MultipleRuleCompiler (ruleCompiler.Object);

            var multipleTerm = new CompositeTerm ("m", null);
            var rule = new Mock<ITerm> ().Object;
            multipleTerm.Add ("rule", rule, false);

            var context = new ProductionCompilerContext (null, null, null, null);
            var captureCounter = new Mock<ICaptureCounter> ();

            ICaptureCounter multipleCaptureCounter = new Mock<ICaptureCounter> ().Object;
            captureCounter.Setup (c => c.CreateMultipleCaptureScope ()).Returns (multipleCaptureCounter);

            multipleCompiler.Compile (0, -1, multipleTerm, context, captureCounter.Object);

            ruleCompiler.Verify (r => r.Compile (rule, context, multipleCaptureCounter));
        }
    }
}