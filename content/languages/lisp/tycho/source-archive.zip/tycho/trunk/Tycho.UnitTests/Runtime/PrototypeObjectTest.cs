﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Runtime;

namespace Tycho.UnitTests.Runtime {
    [TestFixture]
    public class PrototypeObjectTest {
        [Test]
        public void ShouldBeConstructedWithMethod () {
            bool isCalled = false;

            Symbol methodName = Namespaces.User.Get ("do-stuff");
            var method = new NativeMethod (new AnySchemaObject (), (self, args) => isCalled = true);
            AnyObject methodMember = RuntimeModule.CreateStructure (Symbols.RuntimeName, methodName, Symbols.RuntimeMethod, method);
            AnyObject proto = PrototypeObject.New (RuntimeModule.Object, RuntimeModule.Null, methodMember);

            proto.InvokeMethod (proto, methodName);

            Assert.IsTrue (isCalled);
        }

        [Test]
        public void ShouldBeConstructedWithGetter () {
            Symbol getterName = Namespaces.User.Get ("favourite-colour");
            AnyObject expected = "green";
            var method = new NativeMethod (new AnySchemaObject (), (self, args) => expected);
            AnyObject getterMember = RuntimeModule.CreateStructure (Symbols.RuntimeName, getterName, Symbols.RuntimeGetter, method);
            AnyObject proto = PrototypeObject.New (RuntimeModule.Object, RuntimeModule.Null, getterMember);

            AnyObject actual = proto.GetProperty (proto, getterName);

            Assert.IsTrue (expected.Equals (actual));
        }

        [Test]
        public void ShouldBeConstructedWithSetter () {
            Symbol setterName = Namespaces.User.Get ("favourite-colour");
            AnyObject value = null;
            var method = new NativeMethod (new AnySchemaObject (), (self, args) => value = args [0]);
            AnyObject setterMember = RuntimeModule.CreateStructure (Symbols.RuntimeName, setterName, Symbols.RuntimeSetter, method);
            AnyObject proto = PrototypeObject.New (RuntimeModule.Object, RuntimeModule.Null, setterMember);

            AnyObject newFavColour = "blue";
            proto.SetProperty (proto, setterName, newFavColour);

            Assert.IsTrue (newFavColour.Equals (value));
        }

        [Test]
        public void ShouldBeConstructedWithMethodAndPrototype () {
            bool isCalled = false;
            bool otherIsCalled = false;

            Symbol methodName = Namespaces.User.Get ("do-stuff");
            var method = new NativeMethod (new AnySchemaObject (), (self, args) => isCalled = true);
            AnyObject methodMember = RuntimeModule.CreateStructure (Symbols.RuntimeName, methodName, Symbols.RuntimeMethod, method);
            AnyObject proto = PrototypeObject.New (RuntimeModule.Object, RuntimeModule.Null, methodMember);

            Symbol otherMethodName = Namespaces.User.Get ("do-other-stuff");
            var otherMethod = new NativeMethod (new AnySchemaObject (), (self, args) => otherIsCalled = true);
            AnyObject otherMethodMember = RuntimeModule.CreateStructure (Symbols.RuntimeName, otherMethodName, Symbols.RuntimeMethod, otherMethod);
            AnyObject obj = PrototypeObject.New (RuntimeModule.Object, proto, otherMethodMember);

            obj.InvokeMethod (proto, methodName);
            obj.InvokeMethod (proto, otherMethodName);

            Assert.IsTrue (isCalled);
            Assert.IsTrue (otherIsCalled);
        }
    }
}
