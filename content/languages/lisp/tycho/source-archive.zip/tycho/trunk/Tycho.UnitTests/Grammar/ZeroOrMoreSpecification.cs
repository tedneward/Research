using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;
using Tycho.Parser.Tests.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class ZeroOrMoreSpecification {
        [Test]
        public void ShouldParseZeroOrMore () {
            IProduction zeroOrMore = GrammarLoader.CreateZeroOrMore (IdentifierProduction.CreateTerminal ());

            ITerm t = zeroOrMore.ParseTerm ("a*");

            t.ShouldBe ("zero-or-more {rule: a}");
        }

        [Test]
        public void ShouldNotParse () {
            IProduction zeroOrMore = GrammarLoader.CreateZeroOrMore (IdentifierProduction.CreateTerminal ());

            zeroOrMore.AssertNotParsed ("a");
        }
    }
}