﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Lexer;
using Tycho.Parser;

namespace Tycho.UnitTests.Parser {
    [TestFixture]
    public class ParserTest {
        [Test]
        public void ShouldParseItemsInGivenPrecedence () {
            var parser = new Tycho.Parser.Parser ("parser");

            parser.AddSyntax (ParseSyntax (parser, @"s left ""+"" right"));
            parser.AddSyntax (ParseSyntax (parser, @"t left ""+"" right"));

            var term = parser.Parse (NativeLexer.Lex ("a + b"), false);
            Assert.AreEqual ("s", term.TermName ());
        }

        [Test]
        public void ShouldPlaceSyntaxAboveOtherSyntax () {
            var parser = new Tycho.Parser.Parser ("parser");

            parser.AddSyntax (ParseSyntax (parser, @"t left ""+"" right"));
            parser.AddSyntax (ParseSyntax (parser, @"s > t left ""+"" right"));

            var term = parser.Parse (NativeLexer.Lex ("a + b"), false);
            Assert.AreEqual ("s", term.TermName ());
        }

        [Test]
        public void ShouldPlaceSyntaxAboveOtherSyntaxAfterAlreadyParsedSomething () {
            var parser = new Tycho.Parser.Parser ("parser");

            parser.AddSyntax (ParseSyntax (parser, @"t left ""-"" right"));
            parser.AddSyntax (ParseSyntax (parser, @"s left ""+"" right"));

            var term = parser.Parse (NativeLexer.Lex ("a + b"), false);
            Assert.AreEqual ("s", term.TermName ());

            parser.AddSyntax (ParseSyntax (parser, @"r > s left ""+"" right"));
            term = parser.Parse (NativeLexer.Lex ("a + b"), false);
            Assert.AreEqual ("r", term.TermName ());
        }

        [Test]
        public void FirstSyntaxShouldBeLowerPrecedence () {
            var parser = new Tycho.Parser.Parser ("parser");

            parser.AddSyntax (ParseSyntax (parser, @"t left ""-"" right"));
            parser.AddSyntax (ParseSyntax (parser, @"s left ""+"" right"));

            var term = parser.Parse (NativeLexer.Lex ("a + b - c"), false);
            Assert.AreEqual ("t", term.TermName ());

            term = parser.Parse (NativeLexer.Lex ("a - b + c"), false);
            Assert.AreEqual ("t", term.TermName ());
        }

        [Test]
        public void ShouldAllowSyntaxWithBrackets () {
            var parser = new Tycho.Parser.Parser ("parser");

            parser.AddSyntax (ParseSyntax (parser, @"t func ""{"" args ""}"" ""+"""));
            parser.AddSyntax (ParseSyntax (parser, @"s left ""+"" right"));

            var term = parser.Parse (NativeLexer.Lex ("func-name {a + b} +"), false);
            Assert.AreEqual ("t", term.TermName ());
            Assert.AreEqual ("s", term.SubTerm ("args").TermName ());
        }

        [Test]
        public void ShouldAcceptOptionalSyntax () {
            var parser = new Tycho.Parser.Parser ("parser");

            parser.AddSyntax (ParseSyntax (parser, @"do ""do"" ""{"" something ""}"" [ ""ensure"" i ]"));
            parser.AddSyntax (ParseSyntax (parser, @"add left ""+"" right"));
            parser.AddSyntax (ParseSyntax (parser, @"multiply left ""*"" right"));

            var term = parser.Parse (NativeLexer.Lex ("do {a + b} ensure xyz"), false);
            Assert.AreEqual ("do", term.TermName ());
            Assert.AreEqual ("add", term.SubTerm ("something").TermName ());
        }

        [Test]
        public void MultilineProductionShouldReturnListForJustOneStatement () {
            var parser = new Tycho.Parser.Parser ("parser");

            parser.AddSyntax (ParseSyntax (parser, @"block ""{"" multiline expression ""}"""));
            parser.AddSyntax (ParseSyntax (parser, @"add left ""+"" right"));
            parser.AddSyntax (ParseSyntax (parser, @"multiply left ""*"" right"));

            var term = parser.Parse (NativeLexer.Lex ("{a + b}"), false);
            Assert.AreEqual ("block", term.TermName ());
            Assert.AreEqual (1, term.SubTerm ("expression").Count);
            Assert.AreEqual ("add", term.SubTerm ("expression") [0].TermName ());
        }

        [Test]
        public void MultilineProductionShouldReturnListForTwoStatements () {
            var parser = new Tycho.Parser.Parser ("parser");

            parser.AddSyntax (ParseSyntax (parser, @"block ""{"" multiline expression ""}"""));
            parser.AddSyntax (ParseSyntax (parser, @"add left ""+"" right"));
            parser.AddSyntax (ParseSyntax (parser, @"multiply left ""*"" right"));

            var term = parser.Parse (NativeLexer.Lex ("{a + b; c * d}"), false);
            Assert.AreEqual ("block", term.TermName ());
            Assert.AreEqual (2, term.SubTerm ("expression").Count);
            Assert.AreEqual ("add", term.SubTerm ("expression") [0].TermName ());
            Assert.AreEqual ("multiply", term.SubTerm ("expression") [1].TermName ());
        }

        [Test]
        public void MultilineProductionShouldAllowMultilineSyntax () {
            var parser = new Tycho.Parser.Parser ("parser");

            parser.AddSyntax (ParseSyntax (parser, @"block ""{"" multiline expression ""}"""));
            parser.AddSyntax (ParseSyntax (parser, @"add left ""+"" right "";"" top ""*"" bottom"));

            var term = parser.Parse (NativeLexer.Lex ("{a + b; c * d}"), false);
            Assert.AreEqual ("block", term.TermName ());
            Assert.AreEqual (1, term.SubTerm ("expression").Count);
            Assert.AreEqual ("add", term.SubTerm ("expression") [0].TermName ());
        }

        Syntax ParseSyntax (IParser defaultParser, string syntax) {
            SyntaxParser syntaxParser = new SyntaxParser (defaultParser, NativeLexer.Lex (syntax), new Dictionary<string, IParser>());
            return syntaxParser.ParseSyntax ();
        }
    }
}
