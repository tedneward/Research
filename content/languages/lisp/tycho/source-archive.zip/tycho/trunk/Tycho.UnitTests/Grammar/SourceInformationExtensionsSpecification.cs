using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;
using Tycho.Parser.Tokens;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class SourceInformationExtensionsSpecification {
        [Test]
        public void ShouldReturnSourceLocationWithNoLineStartEnd () {
            var translator = new SourceInformationTranslator ();
            SourceLocation sloc = translator.ToSourceLocation (new SourceInformation ("filename", 4, 8));

            Assert.That (sloc.FileName, Is.EqualTo ("filename"));
            Assert.That (sloc.ColumnStart, Is.EqualTo (5));
            Assert.That (sloc.ColumnEnd, Is.EqualTo (12));
            Assert.That (sloc.LineStart, Is.EqualTo (-1));
            Assert.That (sloc.LineEnd, Is.EqualTo (-1));
        }
    }
}