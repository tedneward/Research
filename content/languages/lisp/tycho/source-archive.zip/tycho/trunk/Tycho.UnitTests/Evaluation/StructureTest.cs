﻿using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class StructureTest {
        [Test]
        public void TestConstruction () {
            Script.Test (
@"struct {x := 1, y := 2}",

@"> struct {user:x := 1, user:y := 2}");
        }

        [Test]
        public void TestPropertyGet () {
            Script.Test (
@"x = struct {a := 1}
x.a",

@"> 1");
        }
        
        [Test]
        public void TestPropertySet () {
            Script.Test (
@"x = struct {}
x.a = 1
x.a",

@"> 1");
        }
        
        [Test]
        public void TestPropertyPropertySet () {
            Script.Test (
@"x = struct {y := struct {}}
x.y.a = 1
x.y.a",

@"> 1");
        }

        [Test]
        public void PropertyShouldBeAccessibleBySymbolExpression () {
            Script.Test (
@"prop-name = symbol x
str = struct {x := 7}
str.(prop-name)",

@"> 7");
        }

    }
}
