using System.Collections.Generic;
using NUnit.Framework;
using Tycho.Lexer;
using Tycho.Parser;
using Tycho.Parser.Tokens;

namespace Tycho.UnitTests.Parser {
    [TestFixture]
    public class OptionalPatternTest {
        [Test]
        public void CompiledNodesShouldMatchNothing () {
            var pattern = new OptionalPattern (new SequencePattern(new [] { new KeywordPattern ("a"), new KeywordPattern ("b") }));
            NodePair nodePair = pattern.CompileNodes ();

            var production = new Production (null, new ProductionItem [0]);
            nodePair.LastTransitionNode.Transitions.Add (new FinishTransition (new FinishNode (production, false)));
            List<Token> tokens = NativeLexer.Lex ("");

            var match = nodePair.First.Match (tokens, 0, new HashSet<NodeIndex> ());
            Assert.IsNotNull (match);
        }

        [Test]
        public void CompiledNodesShouldMatchSomething () {
            var pattern = new OptionalPattern (new SequencePattern(new [] { new KeywordPattern ("a"), new KeywordPattern ("b") }));
            NodePair nodePair = pattern.CompileNodes ();

            var production = new Production (null, new ProductionItem [0]);
            nodePair.LastTransitionNode.Transitions.Add (new FinishTransition (new FinishNode (production, false)));
            List<Token> tokens = NativeLexer.Lex ("a b");

            var match = nodePair.First.Match (tokens, 0, new HashSet<NodeIndex> ());
            Assert.IsNotNull (match);
        }
    }
}