﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Compiler;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class SyntaxTest {
        [Test]
        public void ShouldDefineMacroSyntax () {
            Script.Test (
@"macro times-2 ""times-2"" arg
    2.tycho:runtime:multiply (#arg)

times-2 45",

@"> 90");
        }

        [Test]
        public void ShouldDefineMacroSyntaxWithinBracketedCode () {
            Script.AssertEvaluationThrows (typeof (TermNotRecognisedException),
@"condition = true
if condition
    macro times-2 ""times-2"" arg
       2.tycho:runtime:multiply (#arg)

    times-2 45

times-2 13");
        }
    }
}
