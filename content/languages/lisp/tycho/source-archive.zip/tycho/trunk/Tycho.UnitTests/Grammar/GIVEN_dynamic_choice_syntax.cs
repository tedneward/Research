using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;
using Tycho.Parser.Tests.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class GIVEN_dynamic_choice_syntax {
        [Test]
        public void WHEN_Parse_with_commas_and_semi_colons_THEN_should_accept_both_to_delimit_productions () {
            IProduction choice = GrammarLoader.CreateDynamicChoice (GrammarLoader.CreateProduction ());

            ITerm t = choice.ParseTerm ("choice {x, y; z}");

            t.ShouldBe ("dynamic-choice {choices: [x, y, z]}");
        }

        [Test]
        public void WHEN_Parse_with_named_productions_THEN_those_named_productions_should_parse_as_named_productions () {
            IProduction choice = GrammarLoader.CreateDynamicChoice (GrammarLoader.CreateProduction ());

            ITerm t = choice.ParseTerm ("choice {n = p, no-name-production}");

            t.ShouldBe ("dynamic-choice {choices: [named-production {name: n, production: p}, no-name-production]}");
        }

        [Test]
        public void WHEN_Parse_with_incorrect_syntax_THEN_fail_to_parse () {
            AssertNotParsed ("choice []");
            AssertNotParsed ("choice identifier");
        }

        private void AssertNotParsed (string source) {
            IProduction choice = GrammarLoader.CreateDynamicChoice (GrammarLoader.CreateProduction ());

            choice.AssertNotParsed (source);
        }
    }
}