﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Runtime;

namespace Tycho.UnitTests.Runtime {
    [TestFixture]
    public class ProtocolObjectTest {
        [Test]
        public void ShouldMatchAnyObjectImplementingItself () {
            var protocol = new ProtocolObject ();

            var obj = new PrototypeObject (RuntimeModule.Null);

            obj.AddField (Symbols.RuntimeProtocolsImplemented, RuntimeModule.CreateSet (protocol), false);

            Assert.IsTrue (protocol.Match (RuntimeModule.Null, obj));
        }

        [Test]
        public void ShouldNotMatchAnyObjectNotImplementingItself () {
            var protocol = new ProtocolObject ();
            var protocol2 = new ProtocolObject ();

            var obj = new PrototypeObject (RuntimeModule.Null);

            obj.AddField (Symbols.RuntimeProtocolsImplemented, RuntimeModule.CreateSet (protocol2), false);

            Assert.IsFalse (protocol.Match (RuntimeModule.Null, obj));
        }

        [Test]
        public void ShouldNotMatchAnyObjectNotImplementingAnything () {
            var protocol = new ProtocolObject ();

            var obj = new PrototypeObject (RuntimeModule.Null);

            Assert.IsFalse (protocol.Match (RuntimeModule.Null, obj));
        }
    }
}
