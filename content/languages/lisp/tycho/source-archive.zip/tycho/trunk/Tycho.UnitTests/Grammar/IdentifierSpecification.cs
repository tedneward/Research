using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;
using Tycho.Parser.Tests.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class IdentifierSpecification {
        [Test]
        public void ShouldParseIdentifierKeyword () {
            IProduction production = GrammarLoader.CreateIdentifier ();

            ITerm term = production.ParseTerm ("identifier");
            Assert.IsNotNull (term);
            var compositeTerm = term as CompositeTerm;
            Assert.IsNotNull (compositeTerm);
            Assert.AreEqual ("identifier", compositeTerm.Name);
            Assert.AreEqual (0, compositeTerm.SubTerms.Count);
        }

        [Test]
        public void ShouldNotParse () {
            IProduction production = GrammarLoader.CreateIdentifier ();

            production.AssertNotParsed ("id3");
            production.AssertNotParsed ("i");
            production.AssertNotParsed ("8");
        }
    }
}