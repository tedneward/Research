using NUnit.Framework;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class CompositeTermFactoryFactorySpecification {
        [Test]
        public void IfRuleIsInfixThenCreateInfixBuilder () {
            
        }
    }
}