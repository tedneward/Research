﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar
{
    [TestFixture]
    public class CaptureSpecification
    {
        [Test]
        public void ShouldParseCaptureWithSyntaxProduction () {
            IProduction capture = GrammarLoader.CreateCapture(IntegerProduction.CreateTerminal ());
            ITerm t = capture.ParseTerm ("a: 8");
            Assert.IsNotNull (t);
            var captureTerm = t as CompositeTerm;
            Assert.IsNotNull (captureTerm);
            Assert.AreEqual ("capture", captureTerm.Name);
            Assert.AreEqual (2, captureTerm.SubTerms.Count);
            Assert.AreEqual ("a", ((IdentifierTerm) captureTerm.SubTerms["name"]).Name);
            Assert.AreEqual (8, ((IntegerTerm) captureTerm.SubTerms["production"]).Value);
        }
    }
}
