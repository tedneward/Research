﻿using NUnit.Framework;
using Tycho.Compiler;
using Tycho.Runtime;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class ObjectTest {
        [Test]
        public void ShouldDefineFieldFromConstant () {
            Script.Test (
@"point = object
    property x := 0, y := 0
list [point.x, point.y]",

@"> list [0, 0]");
        }
        
        [Test]
        public void ShouldDefineFieldFromArgument () {
            Script.Test (
@"create-point = (x, y) => object
    property x := x, y := y
p = create-point (4, 3)
list [p.x, p.y]",

@"> list [4, 3]");
        }

        [Test]
        public void ShouldDefinePropertyGetter () {
            Script.Test (
@"create-square = (width, height) => object
    property area
       get => width * height
s = create-square (3, 4)
s.area",

@"> 12");
        }

        [Test]
        public void ShouldDefinePropertySetter () {
            Script.Test (
@"create-person = () => object
    age := 0

    property age
       set =>
           print ""setting age""
           age := value
s = create-person ()
s.age = 12",

@"""setting age""
> 12");
        }

        [Test]
        public void ShouldDefinePropertyGetterAndSetter () {
            Script.Test (
@"create-person = () => object
    age := 0

    property age
       set =>
           print ""setting age""
           age := value
       get => age
s = create-person ()
print s.age
print s.age = 12
s.age",

@"0
""setting age""
12
> 12");
        }

        [Test]
        public void ShouldDefineMethod () {
            Script.Test (
@"create-logger = msg-start => object
    method log (msg) =>
       print ""#msg-start: #msg""

l = create-logger (""a"")
l.log(""method call"")",

@"""a: method call""
> null");
        }

        [Test]
        public void ShouldNotImplementProtocol () {
            Script.Test (
@"person = protocol
create-contact = name => object
    property name := name
c = create-contact (""Julius"")
c :: person",

@"> false");
        }

        [Test]
        public void ShouldImplementProtocol () {
            Script.Test (
@"person = protocol
create-contact = name => object
    implements person
    property name := name
c = create-contact (""Julius"")
c :: person",

@"> true");
        }

        [Test]
        public void ShouldImplementTwoSeparateProtocols () {
            Script.Test (
@"person = protocol
emailable = protocol
create-contact = name => object
    implements person
    property name := name
    implements emailable
    property email := ""#name@email.com""

c = create-contact (""Julius"")
c :: person and c :: emailable",

@"> true");
        }

        [Test]
        public void ShouldInheritFromOtherConstructor () {
            Script.Test (
@"create-point = () => object
    property x := 1, y := 2
create-size = () => object
    property width := 3, height := 4
create-rectangle = () => object
    inherit create-point ()
    inherit create-size ()
r = create-rectangle ()
list [r.x, r.y, r.width, r.height]",

@"> list [1, 2, 3, 4]");
        }

        [Test]
        public void ShouldInheritFromOtherConstructorPasingArguments () {
            Script.Test (
@"create-point = (x, y) => object
    property x := x, y := y
create-size = (width, height) => object
    property width := width, height := height
create-rectangle = (x, y, width, height) => object
    inherit create-point (x, y)
    inherit create-size (width, height)
r = create-rectangle (1, 2, 3, 4)
list [r.x, r.y, r.width, r.height]",

@"> list [1, 2, 3, 4]");
        }

        [Test]
        public void ShouldThrowExceptionIfFieldAleadyDefined () {
            Script.AssertEvaluationThrows (typeof (MemberAlreadyDefinedException),
@"point = object
    property x := 0
    property x := 10");
        }

        [Test]
        public void ShouldThrowExceptionIfPropertyGetterAleadyDefined () {
            Script.AssertEvaluationThrows (typeof (MemberAlreadyDefinedException),
@"point = object
    property x
       get => 0
    property x
       get => 10");
        }

        [Test]
        public void ShouldThrowExceptionIfPropertySetterAleadyDefined () {
            Script.AssertEvaluationThrows (typeof (MemberAlreadyDefinedException),
@"point = object
    property x
       set => 0
    property x
       set => 10");
        }


        [Test]
        public void MethodCallShouldAcceptArgumentsInBlock () {
            Script.Test (
@"o = object {method x (i, j) => i + j}
o.x
    7
    9",

@"> 16");
        }
        
        [Test]
        public void ShouldAllowObjectsWithinObjects () {
            Script.Test (
@"outer = object
    property inner := object
        property name := ""inner""
    property name := ""outer""

print outer.name
print outer.inner.name",

@"""outer""
""inner""
> null");
        }
        
        [Test]
        public void VariablesDefinedInObjectShouldNotBeAccessibleOutsideObject () {
            Script.AssertEvaluationThrows (typeof (VariableNotDeclaredException),
@"object
    x = 7

print x");
        }

        [Test]
        public void ShouldReturnMethodFromDispatchMethodWhenSuitableMethodFound () {
            Script.Test (
@"o = object
    method alax (x :: tycho:runtime:string) => x * 2
method = o.tycho:runtime:dispatch-method (symbol alax, ""some string"")
method ()",

@"> ""some stringsome string""");
        }

        [Test]
        public void ShouldReturnNullFromDispatchMethodWhenNoSuitableMethodFound () {
            Script.Test (
@"o = object
    method alax (x :: tycho:runtime:string) => x * 2
method = o.tycho:runtime:dispatch-method (symbol alax, 89)
method == null",

@"> true");
        }

    }
}
