using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class TychoIdentifierFactorySpecification {
        [Test]
        public void ShouldParseIdentifierWithNamespace () {
            IProduction tychoIdentifier = TychoIdentifierFactory.CreateTychoIdentifierProduction ();

            var term = tychoIdentifier.ParseTerm ("a:b:c");

            term.ShouldBe ("identifier {identifier: 'c', module: ['a', 'b']}");
        }

        [Test]
        public void ShouldNotParseNormalIdentifier () {
            IProduction tychoIdentifier = TychoIdentifierFactory.CreateTychoIdentifierProduction ();

            Assert.That(tychoIdentifier.Parse ("c"), Is.Null);
        }

        [Test]
        public void ShouldNotBeInfix () {
            IProduction tychoIdentifier = TychoIdentifierFactory.CreateTychoIdentifierProduction ();
            Assert.That (tychoIdentifier.InfixInformation.IsInfix, Is.False);
        }
    }
}