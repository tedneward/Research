﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Compiler;
using Tycho.Parser.Tokens;
using Tycho.Runtime;

namespace Tycho.UnitTests.Compiler {
    [TestFixture]
    public class FrameSymbolScopeTest {
        private SourceLocation Sloc;
        private Symbol A;

        [SetUp]
        public void SetUp () {
            Sloc = new SourceLocation ("source", "filename", 1, 1, 1, 1);
            A = Symbol.Parse ("a");
        }

        [Test]
        public void DeclareVariableShouldDeclareVariable () {
            var scope = new FrameSymbolScope (null);
            scope.DeclareVariable (A, Sloc);
            Assert.AreEqual (0, scope.GetFrameIndex (A, false, Sloc));
        }

        [Test]
        public void DeclareVariableShouldThrowVariableAlreadyDeclaredException () {
            var scope = new FrameSymbolScope (null);
            scope.DeclareVariable (A, Sloc);
            try {
                scope.DeclareVariable (A, Sloc);
                Assert.Fail ("expected " + typeof (VariableAlreadyDeclaredException));
            } catch (VariableAlreadyDeclaredException) {}
        }

        [Test]
        public void GetFrameIndexShouldFindVariableInParentScope () {
            var parentScope = new FrameSymbolScope (null);
            var scope = new FrameSymbolScope (parentScope);
            parentScope.DeclareVariable (A, Sloc);
            Assert.AreEqual (1, scope.GetFrameIndex (A, false, Sloc));
        }

        [Test]
        public void DeclareVariableTentativeShouldDoNothingIfVariableAlreadyDeclared () {
            var scope = new FrameSymbolScope (null);
            scope.DeclareVariable (A, Sloc);
            scope.DeclareVariableTentative (A, Sloc);
            Assert.AreEqual (0, scope.GetFrameIndex (A, false, Sloc));
        }

        [Test]
        public void DeclareVariableTentativeShouldDelcareVariableIfNotAlready () {
            var scope = new FrameSymbolScope (null);
            scope.DeclareVariableTentative (A, Sloc);
            Assert.AreEqual (0, scope.GetFrameIndex (A, false, Sloc));
        }

        [Test]
        public void GetFrameIndexShouldThrowVariableReadonlyIfForWritingIsTrue () {
            var scope = new FrameSymbolScope (null);
            scope.DeclareConstant (A, Sloc);
            try {
                scope.GetFrameIndex (A, true, Sloc);
                Assert.Fail ("expected " + typeof (AssignmentToConstantException));
            } catch (AssignmentToConstantException) {
            }
        }

        [Test]
        public void DeclareVariableTentativeShouldDoNothingIfVariableAlreadyDeclaredInParentScope () {
            var parentScope = new FrameSymbolScope (null);
            var scope = new FrameSymbolScope (parentScope);
            parentScope.DeclareVariable (A, Sloc);
            scope.DeclareVariableTentative (A, Sloc);
            Assert.AreEqual (1, scope.GetFrameIndex (A, false, Sloc));
        }

        [Test]
        public void DeclareVariableOverrideShouldOverrideVariableInParentScope () {
            var parentScope = new FrameSymbolScope (null);
            var scope = new FrameSymbolScope (parentScope);
            parentScope.DeclareVariable (A, Sloc);
            scope.DeclareVariableOverride (A, Sloc);
            Assert.AreEqual (0, scope.GetFrameIndex (A, false, Sloc));
        }

        [Test]
        public void DeclareVariableOverrideShouldThrowVariableAlreadyDeclaredIfVariableDeclaredInSameScope () {
            var scope = new FrameSymbolScope (null);
            scope.DeclareVariable (A, Sloc);
            try {
                scope.DeclareVariableOverride (A, Sloc);
                Assert.Fail ("expected " + typeof (VariableAlreadyDeclaredException));
            } catch (VariableAlreadyDeclaredException) {}
        }

        [Test]
        public void GetFrameIndexShouldThrowVariableNotDeclaredExceptionIfNotDeclared () {
            var scope = new FrameSymbolScope (null);

            try {
                scope.GetFrameIndex (A, false, Sloc);
                Assert.Fail("expected " + typeof(VariableNotDeclaredException));
            } catch (VariableNotDeclaredException) {
            }
        }
    }
}
