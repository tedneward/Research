using Moq;
using NUnit.Framework;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class InfixInformationSpecification {
        [Test]
        public void ShouldReturnTrueIfBothFirstAndLastProductionsAreBaseProduction () {
            var production = new Mock<IProduction> ().Object;
            Mock<IRule> first = CreateRuleWithProduction (production);
            Mock<IRule> last = CreateRuleWithProduction (production);

            var infix = new InfixInformation (first.Object, last.Object, production);

            Assert.That (infix.IsInfixWith (production));
        }

        [Test]
        public void ShouldReturnFalseIfNotBothFirstAndLastHaveBaseProduction () {
            var production = new Mock<IProduction> ().Object;
            var infix = new InfixInformation (new Mock<IRule> ().Object, new Mock<IRule> ().Object, production);

            var production1 = new Mock<IProduction> ().Object;
            Assert.False (infix.IsInfixWith (production1));
        }

        [Test]
        public void ShouldBeInfix () {
            var infix = new InfixInformation (new Mock<IRule> ().Object,
                                              new Mock<IRule> ().Object,
                                              new Mock<IProduction> ().Object);

            Assert.That (infix.IsInfix, Is.True);
        }

        private static Mock<IRule> CreateRuleWithProduction (IProduction production) {
            var rule = new Mock<IRule> ();
            rule.SetupGet (r => r.Production).Returns (production);
            return rule;
        }
    }
}