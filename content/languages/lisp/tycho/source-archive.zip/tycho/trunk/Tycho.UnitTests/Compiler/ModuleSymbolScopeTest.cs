﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Moq;
using NUnit.Framework;
using Tycho.Compiler;
using Tycho.Parser.Tokens;
using Tycho.Runtime;

namespace Tycho.UnitTests.Compiler {
    [TestFixture]
    public class ModuleSymbolScopeTest {
        [Test]
        public void FindFrameIndexShouldLoadModuleOfSameNamespace () {
            Mock<IModuleScopeLoader> loader = new Mock<IModuleScopeLoader> ();
            Namespace ns = Namespace.Parse ("x:y");
            Symbol a = ns.Get ("a");
            FrameSymbolScope scope = new FrameSymbolScope (null);
            SourceLocation sloc = new SourceLocation ("", "", 1, 1, 1, 1);
            scope.DeclareVariable (a, sloc);
            loader.Setup (l => l.LoadModule (It.IsAny<Namespace> ())).Returns (scope);
            ModuleSymbolScope moduleSymbol = new ModuleSymbolScope (loader.Object);

            Assert.AreEqual (0, moduleSymbol.GetFrameIndex (a, false, sloc));
        }

        [Test]
        public void FindFrameIndexShouldThrowVariableReadonlyExceptionIfForWrite () {
            Mock<IModuleScopeLoader> loader = new Mock<IModuleScopeLoader> ();
            Namespace ns = Namespace.Parse ("x:y");
            Symbol a = ns.Get ("a");
            FrameSymbolScope scope = new FrameSymbolScope (null);
            SourceLocation sloc = new SourceLocation ("", "", 1, 1, 1, 1);
            scope.DeclareVariable (a, sloc);
            loader.Setup (l => l.LoadModule (It.IsAny<Namespace> ())).Returns (scope);
            ModuleSymbolScope moduleSymbol = new ModuleSymbolScope (loader.Object);

            try {
                moduleSymbol.GetFrameIndex (a, true, sloc);
                Assert.Fail ("expected " + typeof (AssignmentToConstantException));
            } catch (AssignmentToConstantException) {
            }
        }

        [Test]
        public void GetFrameIndexForWritingShouldThrowVariableNotDeclaredForVariableNotDeclared () {
            Mock<IModuleScopeLoader> loader = new Mock<IModuleScopeLoader> ();
            Namespace ns = Namespace.Parse ("x:y");
            Symbol a = ns.Get ("a");
            FrameSymbolScope scope = new FrameSymbolScope (null);
            SourceLocation sloc = new SourceLocation ("", "", 1, 1, 1, 1);
            loader.Setup (l => l.LoadModule (It.IsAny<Namespace> ())).Returns (scope);
            ModuleSymbolScope moduleSymbol = new ModuleSymbolScope (loader.Object);

            try {
                moduleSymbol.GetFrameIndex (a, true, sloc);
                Assert.Fail ("expected " + typeof (VariableNotDeclaredException));
            } catch (VariableNotDeclaredException) {
            }
        }
    }
}
