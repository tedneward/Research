using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class TermGrammarBuilderSpecification {
        [Test]
        public void ShouldParseCompositeTerm () {
            var grammar = new TermGrammarBuilder ();

            var sources = new[] {
                                    "name {field1: value1, field2: value2}",
                                    "name {field1: value1; field2: value2}",
@"name {
    field1: value1
    field2: value2
}",
                                };

            foreach (var source in sources) {
                ITerm term = grammar.Production.ParseTerm (source);
                term.ShouldBe ("composite-term {name: name, sub-terms: [sub-term {name: field1, term: value1}, sub-term {name: field2, term: value2}]}");
            }
        }

        [Test]
        public void ShouldParseListTerm () {
            var grammar = new TermGrammarBuilder ();

            var sources = new[] {
                                    "[value1, value2]",
                                    "[value1; value2]",
@"[value1
    value2]",
                                };

            foreach (var source in sources) {
                ITerm term = grammar.Production.ParseTerm (source);
                term.ShouldBe ("list-term {terms: [value1, value2]}");
            }
        }

        [Test]
        public void ShouldParseExpression () {
            var grammar = new TermGrammarBuilder ();

            ITerm term = grammar.Production.ParseTerm ("#value1");
            term.ShouldBe ("expression {name: value1}");
        }

        [Test]
        public void ShouldParseIdentifier () {
            var grammar = new TermGrammarBuilder ();

            ITerm term = grammar.Production.ParseTerm ("id2");
            term.ShouldBe ("id2");
        }

        [Test]
        public void ShouldParseInteger () {
            var grammar = new TermGrammarBuilder ();

            ITerm term = grammar.Production.ParseTerm ("8");
            term.ShouldBe ("8");
        }

        [Test]
        public void ShouldParseString () {
            var grammar = new TermGrammarBuilder ();

            ITerm term = grammar.Production.ParseTerm ("'a string'");
            term.ShouldBe ("'a string'");
        }
    }
}