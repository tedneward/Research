﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Moq;
using NUnit.Framework;
using Tycho.Parser;
using Tycho.Runtime;

namespace Tycho.UnitTests.Parser {
    [TestFixture]
    public class ListGeneratorTest {
        [Test]
        public void ShouldGenerateSubTerms () {
            var termGen1 = new Mock<TermGenerator> ();
            var termGen2 = new Mock<TermGenerator> ();

            var term1 = new Mock<AnyObject> ();
            var term2 = new Mock<AnyObject> ();

            termGen1.Setup (t => t.BuildTerm (It.IsAny<AnyObject []> ())).Returns (term1.Object);
            termGen2.Setup (t => t.BuildTerm (It.IsAny<AnyObject []> ())).Returns (term2.Object);

            var list = new ListGenerator ();

            list.AddItem (termGen1.Object);
            list.AddItem (termGen2.Object);

            var terms = list.BuildTerm ();

            Assert.AreEqual (2, terms.Count);
            Assert.IsTrue (term1.Object.Equals (terms [0]));
            Assert.IsTrue (term2.Object.Equals (terms [1]));
        }

        [Test]
        public void ShouldGenerateVariableSubTerms () {
            var termGen1 = new Mock<TermGenerator> ();
            var vartermGen = new Mock<TermGenerator> ();
            var termGen2 = new Mock<TermGenerator> ();

            var term1 = new Mock<AnyObject> ();
            var varterm1 = new Mock<AnyObject> ();
            var varterm2 = new Mock<AnyObject> ();
            var varTerms = new ListObject (RuntimeModule.Null);
            varTerms.Add (varterm1.Object);
            varTerms.Add (varterm2.Object);
            var term2 = new Mock<AnyObject> ();

            termGen1.Setup (t => t.BuildTerm (It.IsAny<AnyObject []> ())).Returns (term1.Object);
            vartermGen.Setup (t => t.BuildTerm (It.IsAny<AnyObject[]> ())).Returns (varTerms);
            termGen2.Setup (t => t.BuildTerm (It.IsAny<AnyObject []> ())).Returns (term2.Object);

            var list = new ListGenerator ();

            list.AddItem (termGen1.Object);
            list.AddVariableItems (vartermGen.Object);
            list.AddItem (termGen2.Object);

            var terms = list.BuildTerm ();

            Assert.AreEqual (4, terms.Count);
            Assert.IsTrue (term1.Object.Equals (terms [0]));
            Assert.IsTrue (varterm1.Object.Equals (terms [1]));
            Assert.IsTrue (varterm2.Object.Equals (terms [2]));
            Assert.IsTrue (term2.Object.Equals (terms [3]));
        }
    }
}
