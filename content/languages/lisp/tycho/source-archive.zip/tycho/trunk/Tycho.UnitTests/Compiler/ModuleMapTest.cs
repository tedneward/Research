﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Compiler;
using Tycho.Runtime;

namespace Tycho.UnitTests.Compiler {
    [TestFixture]
    public class ModuleMapTest {
        [Test]
        public void ShouldMapNamespaces () {
            Namespace def = Namespace.BuildNamespace ("a", "b");
            Namespace target = def.GetNamespace ("c");
            Namespace alias = Namespace.BuildNamespace ("i");

            ModuleMap map = new ModuleMap (def);

            Assert.IsTrue (target.Equals (map [target]));
            Assert.IsTrue (alias.Equals (map [alias]));

            map.Add (alias, target);

            Assert.IsTrue (target.Equals (map [target]));
            Assert.IsTrue (target.Equals (map [alias]));
        }

        [Test]
        public void ChildModuleMapShouldMapAllParentsAndChildsToo () {
            Namespace def = Namespace.BuildNamespace ("a", "b");
            Namespace target1 = Namespace.BuildNamespace ("x", "y", "z");
            Namespace target2 = def.GetNamespace ("c");
            Namespace alias1 = Namespace.BuildNamespace ("i");
            Namespace alias2 = Namespace.BuildNamespace ("r");

            ModuleMap parentMap = new ModuleMap (def);
            parentMap.Add (alias1, target1);

            ModuleMap map = new ModuleMap (parentMap);
            map.Add (alias2, target2);

            Assert.IsTrue (target1.Equals (map [alias1]));
            Assert.IsTrue (target2.Equals (map [alias2]));
        }
    }
}
