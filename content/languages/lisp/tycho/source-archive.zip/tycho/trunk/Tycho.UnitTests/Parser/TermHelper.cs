using NUnit.Framework;
using Tycho.Runtime;

namespace Tycho.UnitTests.Parser {
    static class TermHelper {
        public static AnyObject SubTerm (this AnyObject term, string name) {
            return term.GetProperty (Namespaces.Parser.Get (name));
        }

        public static string TermName (this AnyObject term) {
            AnyObject name = term.GetProperty (Symbols.ParserTermName);
            Symbol sym = name as Symbol;
            Assert.IsNotNull (sym);
            Assert.AreSame (Namespaces.Parser, sym.Namespace);
            return sym.Name;
        }
    }
}