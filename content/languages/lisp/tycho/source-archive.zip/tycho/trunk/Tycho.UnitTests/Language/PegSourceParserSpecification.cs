﻿using Moq;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Language;
using Tycho.Parser.Peg;
using Tycho.Runtime;

namespace Tycho.UnitTests.Language
{
    [TestFixture]
    public class PegSourceParserSpecification
    {
        [Test]
        public void ShouldUseGrammarToCompileTermsThenTranslate () {
            var translator = new Mock<ITermTranslator> ();
            var parser = new Mock<IParser> ();

            ITerm intermediateTerm = new Mock<ITerm> ().Object;
            AnyObject obj = 8;
            translator.Setup (t => t.Translate (intermediateTerm)).Returns (obj);

            const string source = "source";
            const string filename = "filename";

            parser.Setup (g => g.ParseTerm (source, filename)).Returns (intermediateTerm);

            var expressionParser = new PegSourceParser (translator.Object, parser.Object);

            AnyObject term = expressionParser.Parse (source, filename);
            Assert.That (term.Equals (obj));
        }
    }
}
