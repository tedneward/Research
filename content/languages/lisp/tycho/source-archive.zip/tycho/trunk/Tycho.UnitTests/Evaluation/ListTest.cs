﻿using System;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class ListTest {
        [Test]
        public void TestConstant () {
            Script.Test (
@"list [1, 2, 3]",

@"> list [1, 2, 3]");
        }
        
        [Test]
        public void TestEmptyConstant () {
            Script.Test (
@"list []",

@"> list []");
        }

        [Test]
        public void TestCount () {
            Script.Test (
@"list [1, 2, 3].tycho:runtime:count",

@"> 3");
        }

        [Test]
        public void TestIndexGet () {
            Script.Test (
@"list [1, 2, 3] [1]",

@"> 2");
        }

        [Test]
        public void TestIndexGetFromEnd () {
            Script.Test (
@"list [1, 2, 3] [-1]",

@"> 3");
        }

        [Test]
        public void TestIndexSet () {
            Script.Test (
@"a = list [1, 2]
a [1] = 3
a",

@"> list [1, 3]");
        }

        [Test]
        public void TestIndexSetFromEnd () {
            Script.Test (
@"a = list [1, 2]
a [-2] = 3
a",

@"> list [3, 2]");
        }

        [Test]
        public void RemoveShouldRemoveItemFromList () {
            Script.Test (
@"a = list [1, 2]
a.tycho:runtime:remove (2)
a",

@"> list [1]");
        }

        [Test]
        public void RemoveShouldReturnTrueIfItemFound () {
            Script.Test (
@"a = list [1, 2]
a.tycho:runtime:remove (2)",

@"> true");
        }

        [Test]
        public void RemovingItemNotFoundShouldReturnFalse () {
            Script.Test (
@"a = list [1, 2]
a.tycho:runtime:remove (3)",

@"> false");
        }

        [Test]
        public void RemoveIndexShouldRemoveItemAtIndexGiven () {
            Script.Test (
@"a = list [1, 2]
a.tycho:runtime:remove-index (0)
a",

@"> list [2]");
        }

        [Test]
        public void RemoveIndexShouldRemoveItemAtIndexFromEnd () {
            Script.Test (
@"a = list [1, 2]
a.tycho:runtime:remove-index (-2)
a",

@"> list [2]");
        }

        [Test]
        public void InsertShouldInsertItemAtIndex () {
            Script.Test (
@"a = list [1, 2]
a.tycho:runtime:insert (1, 3)
a",

@"> list [1, 3, 2]");
        }

        [Test]
        public void InsertShouldInsertItemAtIndexFromEnd () {
            Script.Test (
@"a = list [1, 2]
a.tycho:runtime:insert (-2, 3)
a",

@"> list [3, 1, 2]");
        }

        [Test]
        public void TestIndexOutOfBoundsException () {
            try {
                Script.Test (
                    @"list [1, 2, 3] [3]",

                    @"");
                Assert.Fail ("expected out of range exception");
            } catch (ArgumentOutOfRangeException) {
            }
        }

        [Test]
        public void RemoveIndexShouldThrowExceptionIfIndexOutOfBounds () {
            try {
                Script.Test (
                    @"list [1, 2, 3].tycho:runtime:remove-index(4)",

                    @"");
                Assert.Fail ("expected out of range exception");
            } catch (ArgumentOutOfRangeException) {
            }
        }
        
        [Test]
        public void TestMap () {
            Script.Test (
@"list [1, 2, 3].tycho:runtime:map ((n) => n + 1)",

@"> list [2, 3, 4]");
        }

        [Test]
        public void MapShouldWorkWithArgumentsSpecifiedInBlock () {
            Script.Test (
@"list [1, 2, 3].tycho:runtime:map
    n => n + 1",

@"> list [2, 3, 4]");
        }

        [Test]
        public void FilterShouldReturnListWithItemsThatReturnTrueForPredicate () {
            Script.Test (
@"a = list [1, 2, 3]
print a.tycho:runtime:filter ((n) => n < 2)
a",

@"list [1]
> list [1, 2, 3]");
        }

        [Test]
        public void MapShouldReturnIntoFilterWhichShouldReturnMappedAndFilteredList () {
            Script.Test (
@"a = list [1, 2, 3]
print a.tycho:runtime:map {
    n => n * 5
}.tycho:runtime:filter {
    n => n < 12}",

@"list [5, 10]
> null");
        }

        [Test]
        public void TestEach () {
            Script.Test (
@"list [1, 2, 3].tycho:runtime:each ((n) => {print n; n})",

@"1
2
3
> 3");
        }
        
        [Test]
        public void TestEmptyEach () {
            Script.Test (
@"list [].tycho:runtime:each ((n) => {print n; n})",

@"> null");
        }

        [Test]
        public void TestSort () {
            Script.Test (
@"list [2, 3, 1].tycho:runtime:sort ()",

@"> list [1, 2, 3]");
        }

        [Test]
        public void TestConcatenate () {
            Script.Test (
@"list [1, 2, 3].tycho:runtime:concatenate (list [4, 5, 6])",

@"> list [1, 2, 3, 4, 5, 6]");
        }

        [Test]
        public void TestPlus () {
            Script.Test (
@"list [1, 2, 3] + list [4, 5, 6]",

@"> list [1, 2, 3, 4, 5, 6]");
        }

        [Test]
        public void ToSetShouldReturnUniqueSet () {
            Script.Test (
@"list [1, 2, 3, ""one"", ""one"", 3].tycho:runtime:to-set ()",

@"> set {""one"", 1, 2, 3}");
        }

        [Test]
        public void FoldLeftShouldFoldLeftAssociative () {
            Script.Test (
@"list [2, 3, 4].tycho:runtime:fold-left ((left, right) => left ^ right)",

@"> 4096");
        }

        [Test]
        public void FoldLeftShouldReturnFirstItemForListWithOnlyOneItem () {
            Script.Test (
@"list [2].tycho:runtime:fold-left ((left, right) => left ^ right)",

@"> 2");
        }

        [Test]
        public void FoldLeftShouldReturnNullForEmptyList () {
            Script.Test (
@"list [].tycho:runtime:fold-left ((left, right) => left ^ right)",

@"> null");
        }

        [Test]
        public void FoldRightShouldFoldRightAssociative () {
            Script.Test (
@"list [2, 3, 2].tycho:runtime:fold-right ((left, right) => left ^ right)",

@"> 512");
        }

        [Test]
        public void FoldRightShouldReturnFirstItemForListWithOnlyOneItem () {
            Script.Test (
@"list [2].tycho:runtime:fold-right ((left, right) => left ^ right)",

@"> 2");
        }

        [Test]
        public void FoldRightShouldReturnNullForEmptyList () {
            Script.Test (
@"list [].tycho:runtime:fold-right ((left, right) => left ^ right)",

@"> null");
        }

        [Test]
        public void ReverseShouldReturnNewListWithItemsReversed () {
            Script.Test (
@"list [1, 2, 3, 4].tycho:runtime:reverse ()",

@"> list [4, 3, 2, 1]");
        }

        [Test]
        public void ZipShouldReturnListWithItemsFromBothListsInSameOrder () {
            Script.Test (
@"list [1, 2, 3, 4].tycho:runtime:zip (list [""one"", ""two"", ""three"", ""four""])",

@"> list [list [1, ""one""], list [2, ""two""], list [3, ""three""], list [4, ""four""]]");
        }

        [Test]
        public void JoinShouldJoinListItemsBasedOnTheirKeys () {
            Script.Test (
@"left = list [struct {name := ""Tim"", colour := ""red""}, struct {name := ""John"", colour := ""blue""}, struct {name := ""Rowan"", colour := ""yellow""}]
right = list [struct {fname := ""Rowan"", shape := ""square""}, struct {fname := ""John"", shape := ""circle""}, struct {fname := ""Tim"", shape := ""triangle""}]
left.tycho:runtime:join (right, l => l.name, r => r.fname)",

@"> list [list [struct {user:name := ""Tim"", user:colour := ""red""}, struct {user:fname := ""Tim"", user:shape := ""triangle""}], list [struct {user:name := ""John"", user:colour := ""blue""}, struct {user:fname := ""John"", user:shape := ""circle""}], list [struct {user:name := ""Rowan"", user:colour := ""yellow""}, struct {user:fname := ""Rowan"", user:shape := ""square""}]]");
        }

        [Test]
        public void JoinShouldIncludeItemsOnlyFoundInLeftAndRight () {
            Script.Test (
@"left = list [struct {name := ""Tim"", colour := ""red""}, struct {name := ""John"", colour := ""blue""}, struct {name := ""Rowan"", colour := ""yellow""}]
right = list [struct {fname := ""Rowan"", shape := ""square""}, struct {fname := ""Tim"", shape := ""triangle""}]
left.tycho:runtime:join (right, l => l.name, r => r.fname)",

@"> list [list [struct {user:name := ""Tim"", user:colour := ""red""}, struct {user:fname := ""Tim"", user:shape := ""triangle""}], list [struct {user:name := ""Rowan"", user:colour := ""yellow""}, struct {user:fname := ""Rowan"", user:shape := ""square""}]]");
        }

        [Test]
        public void LeftJoinShouldJoinListItemsBasedOnTheirKeys () {
            Script.Test (
@"left = list [struct {name := ""Tim"", colour := ""red""}, struct {name := ""John"", colour := ""blue""}, struct {name := ""Rowan"", colour := ""yellow""}]
right = list [struct {fname := ""Rowan"", shape := ""square""}, struct {fname := ""John"", shape := ""circle""}, struct {fname := ""Tim"", shape := ""triangle""}]
left.tycho:runtime:left-join (right, l => l.name, r => r.fname)",

@"> list [list [struct {user:name := ""Tim"", user:colour := ""red""}, struct {user:fname := ""Tim"", user:shape := ""triangle""}], list [struct {user:name := ""John"", user:colour := ""blue""}, struct {user:fname := ""John"", user:shape := ""circle""}], list [struct {user:name := ""Rowan"", user:colour := ""yellow""}, struct {user:fname := ""Rowan"", user:shape := ""square""}]]");
        }

        [Test]
        public void LeftJoinShouldIncludeAllItemsFromLeftAndNullIfNoCorrespondingItemFoundInRight () {
            Script.Test (
@"left = list [struct {name := ""Tim"", colour := ""red""}, struct {name := ""John"", colour := ""blue""}, struct {name := ""Rowan"", colour := ""yellow""}]
right = list [struct {fname := ""Rowan"", shape := ""square""}, struct {fname := ""Tim"", shape := ""triangle""}]
left.tycho:runtime:left-join (right, l => l.name, r => r.fname)",

@"> list [list [struct {user:name := ""Tim"", user:colour := ""red""}, struct {user:fname := ""Tim"", user:shape := ""triangle""}], list [struct {user:name := ""John"", user:colour := ""blue""}, null], list [struct {user:name := ""Rowan"", user:colour := ""yellow""}, struct {user:fname := ""Rowan"", user:shape := ""square""}]]");
        }
    }
}
