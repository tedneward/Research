﻿using NUnit.Framework;
using Tycho.Runtime;
using Tycho.Language;

namespace Tycho.UnitTests.Runtime {
    [TestFixture]
    public class ModuleLoaderTest {
        [Test]
        public void ShouldLoadAndInitialiseModuleVariables () {
            AnyObject runtimeModule = TopLevel.RuntimeAssemblyModule;
            var moduleFrame = new ModuleFrameObject (RuntimeModule.ModuleFrame);
            var moduleManifest = new ModuleManifest (moduleFrame);
            moduleManifest.ModuleLoaders.Add (Namespaces.Runtime, new ImmediateModuleLoader (runtimeModule));

            Namespace ns = Namespace.BuildNamespace ("a", "b");
            var language = new ExpressionLanguage (runtimeModule, ns);

            string source = @"
import tycho:runtime as r
export numbers = list [1, 2, 3]
export transform-numbers = () => numbers.r:map (num => num * 2)
";

            AnyObject module = language.LoadModule (source, "my-module.tycho", moduleFrame, moduleManifest);

            Assert.AreEqual ("list [1, 2, 3]", module [ns.Get ("numbers")].ToString ());
            Assert.AreEqual ("list [2, 4, 6]", module [ns.Get ("transform-numbers")].Invoke ().ToString ());
            Assert.IsTrue (ns.Equals (module.GetProperty (Symbols.RuntimeNamespace)));
        }
    }
}
