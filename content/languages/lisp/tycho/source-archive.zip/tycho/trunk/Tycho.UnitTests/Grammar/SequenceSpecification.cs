using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;
using Tycho.Parser.Tests.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class SequenceSpecification {
        [Test]
        public void ShouldParseSequence () {
            IProduction production = GrammarLoader.CreateSequence (IdentifierProduction.CreateTerminal ());

            ITerm t = production.ParseTerm ("a b c");
            Assert.IsNotNull (t);
            var term = t as CompositeTerm;
            Assert.IsNotNull (term);
            Assert.AreEqual ("sequence", term.Name);
            Assert.AreEqual (1, term.SubTerms.Count);
            var rules = term.SubTerms["rules"] as ListTerm;
            Assert.IsNotNull (rules);
            Assert.AreEqual (3, rules.Terms.Count);
            Assert.AreEqual ("a", ((IdentifierTerm) rules.Terms[0]).Name);
            Assert.AreEqual ("b", ((IdentifierTerm) rules.Terms[1]).Name);
            Assert.AreEqual ("c", ((IdentifierTerm) rules.Terms[2]).Name);
        }

        [Test]
        public void ShouldNotParse () {
            IProduction production = GrammarLoader.CreateSequence (IdentifierProduction.CreateTerminal ());

            production.AssertNotParsed ("a / b");
            production.AssertNotParsed ("a*");
            production.AssertNotParsed ("a");
        }
    }
}