using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;
using Tycho.Parser.Tests.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class OneOrMoreSpecification {
        [Test]
        public void ShouldParseOneOrMore () {
            IProduction oneOrMore = GrammarLoader.CreateOneOrMore (IdentifierProduction.CreateTerminal ());

            ITerm t = oneOrMore.ParseTerm ("a+");
            Assert.IsNotNull (t);
            var oneOrMoreTerm = t as CompositeTerm;
            Assert.IsNotNull (oneOrMoreTerm);
            Assert.AreEqual ("one-or-more", oneOrMoreTerm.Name);
            Assert.AreEqual (1, oneOrMoreTerm.SubTerms.Count);
            var rule = oneOrMoreTerm.SubTerms["rule"] as IdentifierTerm;
            Assert.IsNotNull (rule);
            Assert.AreEqual ("a", rule.Name);
        }

        [Test]
        public void ShouldNotParse () {
            IProduction oneOrMore = GrammarLoader.CreateOneOrMore (IdentifierProduction.CreateTerminal ());

            oneOrMore.AssertNotParsed ("a*");
            oneOrMore.AssertNotParsed ("a");
            oneOrMore.AssertNotParsed ("");
        }
    }
}