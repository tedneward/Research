﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Runtime;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class MultimethodTest {

        [Test]
        public void ShouldInvokeCorrectMethod () {
            Script.Test (
@"m = method
    i :: tycho:runtime:string => ""is string""
    i :: tycho:runtime:integer => ""is integer""

print m (4)
print m (""s"")",

@"""is integer""
""is string""
> null");
        }

        [Test]
        public void ShouldThrowNoSuchMethodWhenArgumentsPassedDontMatch () {
            Script.AssertEvaluationThrows (typeof (NoMatchingMethodInMultimethodException),
@"m = method
    i :: 7 => 14

m (6)");
        }

        [Test]
        public void DispatchMethodShouldReturnMethodThatReturnsResultFromInvocationWhenSuitableMethodFound () {
            Script.Test (
@"m = method
    i :: 7 => 14
method = m.tycho:runtime:dispatch-method (symbol tycho:runtime:invoke, 7)
method ()",

@"> 14");
        }

        [Test]
        public void DispatchMethodShouldReturnNullWhenNoSuitableMethodFound () {
            Script.Test (
@"m = method
    i :: 7 => 14
method = m.tycho:runtime:dispatch-method (symbol tycho:runtime:invoke, 4)
method == null",

@"> true");
        }
    }
}
