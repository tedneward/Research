using NUnit.Framework;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class NotInfixInformationSpecification {
        [Test]
        public void ShouldNotBeInfix () {
            Assert.That (new NotInfixInformation ().IsInfix, Is.False);
        }
    }
}