using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class OptionalSpecification {
        [Test]
        public void ShouldParseOptionalRule () {
            IProduction optional = GrammarLoader.CreateOptional (IdentifierProduction.CreateTerminal ());

            ITerm t = optional.ParseTerm ("a?");
            Assert.IsNotNull (t);
            var optionalTerm = t as CompositeTerm;
            Assert.IsNotNull (optionalTerm);
            Assert.AreEqual ("optional", optionalTerm.Name);
            Assert.AreEqual (1, optionalTerm.SubTerms.Count);
            Assert.AreEqual ("a", ((IdentifierTerm) optionalTerm.SubTerms["rule"]).Name);
        }
    }
}