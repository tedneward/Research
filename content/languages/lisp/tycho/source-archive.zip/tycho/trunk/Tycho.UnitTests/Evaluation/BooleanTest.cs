﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class BooleanTest {
        [Test]
        public void NotTrueShouldReturnFalse () {
            Script.Test (
@"not true",

@"> false");
        }
        
        [Test]
        public void NotFalseShouldReturnTrue () {
            Script.Test (
@"not false",

@"> true");
        }

        [Test]
        public void TrueAndFalseShouldReturnFalse () {
            Script.Test (
@"true and false",

@"> false");
        }
        
        [Test]
        public void OrShouldReturnOrOfOperands () {
            Script.Test (
@"true or true",

@"> true");
        }
        
        [Test]
        public void XorShouldReturnExclusiveOrOfOperands () {
            Script.Test (
@"true xor false",

@"> true");
        }
        
        [Test]
        public void AndShouldHaveHigherPrecedenceThanOr () {
            Script.Test (
@"true or true and false",

@"> true");
        }
    }
}
