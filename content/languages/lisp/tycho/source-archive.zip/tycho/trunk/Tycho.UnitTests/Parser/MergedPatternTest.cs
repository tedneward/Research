using System;
using System.Collections.Generic;
using Moq;
using NUnit.Framework;
using Tycho.Lexer;
using Tycho.Parser;

namespace Tycho.UnitTests.Parser {
    [TestFixture]
    public class MergedPatternTest {
        [Test]
        public void MergeMustMergePatternsIfPatternsAreEquivalent () {
            var patternA1 = new Mock<Pattern> ();
            var patternA2 = new Mock<Pattern> ();
            var patternB = new Mock<Pattern> ();
            var patternC = new Mock<Pattern> ();

            var syntax1 = new [] { patternA1.Object, patternB.Object };
            var syntax2 = new [] { patternA2.Object, patternC.Object };

            patternA1.Setup (p => p.PatternEquals (patternA2.Object)).Returns (true);
            patternB.Setup (p => p.PatternEquals (patternC.Object)).Returns (false);

            MergedPattern mergedPattern = new MergedPattern ();

            mergedPattern.Merge (syntax1);
            mergedPattern.Merge (syntax2);

            Assert.AreEqual (1, mergedPattern.MergedPatterns.Count);
            var mergedPattern2 = mergedPattern.MergedPatterns [0];
            Assert.AreEqual (patternA1.Object, mergedPattern2.Pattern);
            Assert.AreEqual (2, mergedPattern2.MergedPatterns.Count);
            Assert.AreEqual (patternB.Object, mergedPattern2.MergedPatterns [0].Pattern);
            Assert.AreEqual (patternC.Object, mergedPattern2.MergedPatterns [1].Pattern);
        }

        [Test]
        public void MergeMustNotMergePatternsIfPatternsAreNotEquivalent () {
            var patternA1 = new Mock<Pattern> ();
            var patternA2 = new Mock<Pattern> ();

            patternA1.Setup (p => p.PatternEquals (patternA2.Object)).Returns (false);

            var syntax1 = new [] { patternA1.Object };
            var syntax2 = new [] { patternA2.Object };

            MergedPattern mergedPattern = new MergedPattern ();

            mergedPattern.Merge (syntax1);
            mergedPattern.Merge (syntax2);

            Assert.AreEqual (2, mergedPattern.MergedPatterns.Count);
            Assert.AreEqual (patternA1.Object, mergedPattern.MergedPatterns[0].Pattern);
            Assert.AreEqual (patternA2.Object, mergedPattern.MergedPatterns[1].Pattern);
        }

        [Test]
        public void SequenceShouldProduceLinkedChainOfMergedPatterns () {
            var patternA = new Mock<Pattern> ();
            var patternB = new Mock<Pattern> ();
            var patternC = new Mock<Pattern> ();

            var syntax = new [] { patternA.Object, patternB.Object, patternC.Object };

            var merged = MergedPattern.Sequence (syntax, 0);

            Assert.AreEqual (patternA.Object, merged.Pattern);
            Assert.AreEqual (1, merged.MergedPatterns.Count);
            Assert.AreEqual (patternB.Object, merged.MergedPatterns [0].Pattern);
            Assert.AreEqual (1, merged.MergedPatterns [0].MergedPatterns.Count);
            Assert.AreEqual (patternC.Object, merged.MergedPatterns [0].MergedPatterns [0].Pattern);

            merged = MergedPattern.Sequence (syntax, 1);

            Assert.AreEqual (patternB.Object, merged.Pattern);
            Assert.AreEqual (1, merged.MergedPatterns.Count);
            Assert.AreEqual (patternC.Object, merged.MergedPatterns [0].Pattern);
        }

        [Test]
        public void CompileShouldReturnAllNodesFromPatternsLinkedTogether() {
            var patternA = new Mock<Pattern> ();
            var patternB1 = new Mock<Pattern> ();
            var patternB2 = new Mock<Pattern> ();
            var patternC1 = new Mock<Pattern> ();
            var patternC2 = new Mock<Pattern> ();

            NodePair nodesA = CreateLinkedNodes ();
            NodePair nodesB1 = CreateLinkedNodes ();
            NodePair nodesB2 = CreateLinkedNodes ();
            NodePair nodesC1 = CreateLinkedNodes ();
            NodePair nodesC2 = CreateLinkedNodes ();

            patternA.Setup (p => p.CompileNodes ()).Returns (nodesA);
            patternB1.Setup (p => p.CompileNodes ()).Returns (nodesB1);
            patternB2.Setup (p => p.CompileNodes ()).Returns (nodesB2);
            patternC1.Setup (p => p.CompileNodes ()).Returns (nodesC1);
            patternC2.Setup (p => p.CompileNodes ()).Returns (nodesC2);

            MergedPattern start = new MergedPattern();
            MergedPattern mergedPatternA = new MergedPattern (patternA.Object);
            MergedPattern mergedPatternB1 = new MergedPattern (patternB1.Object);
            MergedPattern mergedPatternB2 = new MergedPattern (patternB2.Object);
            MergedPattern mergedPatternC1 = new MergedPattern (patternC1.Object);
            MergedPattern mergedPatternC2 = new MergedPattern (patternC2.Object);

            start.MergedPatterns.Add (mergedPatternA);
            mergedPatternA.MergedPatterns.Add (mergedPatternB1);
            mergedPatternA.MergedPatterns.Add (mergedPatternB2);
            mergedPatternB1.MergedPatterns.Add (mergedPatternC1);
            mergedPatternB2.MergedPatterns.Add (mergedPatternC2);

            TransitionNode node = (TransitionNode) start.Compile ();

            Assert.AreEqual (1, node.Transitions.Count);
            node = (TransitionNode) node.Transitions[0].Node;

            var nodeALast = AssertNodePairEqualTo (node, nodesA);
            Assert.AreEqual (2, nodeALast.Transitions.Count);

            var nodeB1First = (TransitionNode) nodeALast.Transitions [0].Node;
            var nodeB1Last = AssertNodePairEqualTo (nodeB1First, nodesB1);
            Assert.AreEqual (1, nodeB1Last.Transitions.Count);

            var nodeC1First = (TransitionNode) nodeB1Last.Transitions [0].Node;
            var nodeC1Last = AssertNodePairEqualTo (nodeC1First, nodesC1);
            Assert.AreEqual (0, nodeC1Last.Transitions.Count);

            var nodeB2First = (TransitionNode) nodeALast.Transitions [1].Node;
            var nodeB2Last = AssertNodePairEqualTo (nodeB2First, nodesB2);
            Assert.AreEqual (1, nodeB2Last.Transitions.Count);

            var nodeC2First = (TransitionNode) nodeB2Last.Transitions [0].Node;
            var nodeC2Last = AssertNodePairEqualTo (nodeC2First, nodesC2);
            Assert.AreEqual (0, nodeC2Last.Transitions.Count);
        }

        private TransitionNode AssertNodePairEqualTo (TransitionNode first, NodePair nodePair) {
            Assert.AreEqual (nodePair.First, first);
            Assert.AreEqual (1, first.Transitions.Count);
            var last = (TransitionNode) first.Transitions[0].Node;
            Assert.AreEqual (nodePair.Last, last);
            return last;
        }

        private NodePair CreateLinkedNodes () {
            TransitionNode nodeAFirst = new TransitionNode ();
            TransitionNode nodeALast = new TransitionNode ();
            nodeAFirst.Transitions.Add (new FreeTransition (nodeALast));
            return new NodePair (nodeAFirst, nodeALast);
        }
    }
}