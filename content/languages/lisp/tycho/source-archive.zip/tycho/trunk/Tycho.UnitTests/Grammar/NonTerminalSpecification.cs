using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class NonTerminalSpecification {
        [Test]
        public void ShouldParseSequence () {
            IProduction production = GrammarLoader.CreateNonTerminal (new IdentifierTerminal ());

            Term t = production.ParseTerm ("tro {a+ 'keyword' b :: lang c?}");
            Assert.IsNotNull (t);
            var expected =
                "non-terminal {name: 'tro', rules: sequence {rules: [one-or-more {rule: capture {name: 'a'}}, keyword {name: \"keyword\"}, capture {name: 'b', production: 'lang'}, optional {rule: capture {name: 'c'}}]}}";
            Assert.AreEqual (expected, t.ToString ());
        }

        [Test]
        public void ShouldParseChoice () {
            IProduction production = GrammarLoader.CreateNonTerminal(new IdentifierTerminal ());

            Term t = production.ParseTerm ("tri {a / b / c}");
            Assert.IsNotNull (t);
            var expected =
                "non-terminal {name: 'tri', rules: choice {choices: [capture {name: 'a'}, capture {name: 'b'}, capture {name: 'c'}]}}";
            Assert.AreEqual (expected, t.ToString ());
        }
    }
}