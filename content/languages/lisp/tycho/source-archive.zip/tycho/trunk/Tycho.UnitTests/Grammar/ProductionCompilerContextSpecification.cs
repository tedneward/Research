using Moq;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class ProductionCompilerContextSpecification {
        [Test]
        public void CloneShouldReturnContextWithSameContents () {
            var environment = new Mock<IProductionCompilerEnvironment> ().Object;
            var lookup = new Mock<IProductionLookup> ().Object;
            var grammar = new Mock<IDynamicGrammar> ().Object;
            var deferredCompilations = new Mock<IDeferredCompilations> ().Object;

            var context = new ProductionCompilerContext (environment, lookup, grammar, deferredCompilations);

            var clone = context.Clone ();

            Assert.That (clone.Environment, Is.SameAs (environment));
            Assert.That (clone.Lookup, Is.SameAs (lookup));
            Assert.That (clone.Grammar, Is.SameAs (grammar));
            Assert.That (clone.DeferredCompilations, Is.SameAs (deferredCompilations));
        }
    }
}