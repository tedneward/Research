﻿using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class ActorTest {
        [Test]
        public void ActorShouldBeCalledWithNameForEveryMethodCall () {
            Script.Test (
@"p = actor (s, name, arguments, ...) =>
    print name
p.some-method ()
p.some-other-method ()",

@"user:some-method
user:some-other-method
> null");
        }

        [Test]
        public void ProxyShouldBeCalledWithArgumentsForEveryMethodCall () {
            Script.Test (
@"p = actor (s, name, arguments, ...) =>
    print arguments
p.some-method (1, 2, 3, 4, 5)
p.some-other-method (""x"", ""y"", ""z"")",

@"list [1, 2, 3, 4, 5]
list [""x"", ""y"", ""z""]
> null");
        }

        [Test]
        public void BuildLazyKeywordAndRuntime () {
            Script.Test (
@"macro lazy > function-call ""lazy"" expression {user:create-lazy-object (() => #expression)}

create-lazy-object = (operation) =>
    cached := null
    is-cached := false

    actor (s, name, arguments, ...) =>
        if not is-cached
            cached := operation ()
            is-cached := true
        cached.(name) (arguments, ...)

x = lazy
       print ""running lazy operation""
       list [1, 2, 3]

print x.tycho:runtime:count
x.tycho:runtime:count",

@"""running lazy operation""
3
> 3");
        }

        [Test]
        public void ShouldCallToString () {
            Script.Test (
@"value = list [1, 2, 3]
p = actor (self, name, arguments, ...) =>
       value.(name) (arguments, ...)
print p",

@"list [1, 2, 3]
> null");
        }

        [Test]
        public void ShouldPassThroughDispatchMethod () {
            Script.Test (
@"a = actor (self, name, args, ...) => print name
a.tycho:runtime:dispatch-method (symbol some-method, 1, 2, 3)",

@"tycho:runtime:dispatch-method
> null");
        }

    }
}
