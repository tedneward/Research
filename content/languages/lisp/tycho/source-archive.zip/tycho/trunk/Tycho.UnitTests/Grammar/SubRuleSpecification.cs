using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class SubRuleSpecification {
        [Test]
        public void ShouldParseSubRule () {
            IProduction subRule = GrammarLoader.CreateSubRule (IdentifierProduction.CreateTerminal ());

            ITerm t = subRule.ParseTerm ("(a)");
            Assert.IsNotNull (t);
            var subRuleTerm = t as CompositeTerm;
            Assert.IsNotNull (subRuleTerm);
            Assert.AreEqual ("sub-rule", subRuleTerm.Name);
            Assert.AreEqual (1, subRuleTerm.SubTerms.Count);
            Assert.AreEqual ("a", ((IdentifierTerm) subRuleTerm.SubTerms["rule"]).Name);
        }
    }
}