﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class WhileTest {
        [Test]
        public void ShouldLoopWhileConditionIsTrue () {
            Script.Test (
@"n := 0
while n < 4
    print n
    n := n + 1",

@"0
1
2
3
> 4");
        }
    }
}
