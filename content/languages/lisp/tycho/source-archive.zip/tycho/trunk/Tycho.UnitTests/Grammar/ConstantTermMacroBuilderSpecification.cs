using Moq;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class ConstantTermMacroBuilderSpecification {
        [Test]
        public void ShouldReturnSameTermAsPassedInConstructor () {
            var term = new Mock<ITerm> ().Object;
            var builder = new ConstantTermMacroBuilder (term);
            Assert.That (builder.BuildTerm (null), Is.SameAs (term));
        }
    }
}