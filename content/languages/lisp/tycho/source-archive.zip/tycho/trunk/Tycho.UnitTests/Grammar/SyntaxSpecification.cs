using System;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class SyntaxSpecification {
        [Test]
        public void ShouldParseSequence () {
            IProduction production = GrammarLoader.CreateSyntax (IdentifierProduction.CreateTerminal ());

            ITerm t = production.ParseTerm ("a+ 'keyword' b: lang (c d)?");
            Assert.IsNotNull (t);
            var expected =
                "sequence {rules: [one-or-more {rule: 'a'}, keyword {name: \"keyword\"}, capture {name: 'b', production: 'lang'}, optional {rule: sub-rule {rule: sequence {rules: ['c', 'd']}}}]}";
            Assert.AreEqual (expected, t.ToString ());
        }

        [Test]
        public void ShouldParseChoice () {
            IProduction production = GrammarLoader.CreateSyntax (IdentifierProduction.CreateTerminal ());

            ITerm t = production.ParseTerm ("a / b / c");
            Assert.IsNotNull (t);
            var expected =
                "choice {choices: ['a', 'b', 'c']}";
            Assert.AreEqual (expected, t.ToString ());
        }
    }
}