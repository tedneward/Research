using System.Collections.Generic;
using Tycho.Compiler;
using Tycho.Runtime;

namespace Tycho.UnitTests.Evaluation {
    class MockModuleLoader : IModuleLoader {
        private Dictionary<string, AnyObject> Objects;

        public MockModuleLoader (Dictionary<string, AnyObject> objects) {
            Objects = objects;
        }

        public AnyObject LoadModule (Namespace ns, string [] modulePath, IModuleScopeLoader moduleLoader) {
            var module = RuntimeModule.CreateModule (ns);

            foreach (var entry in Objects) {
                module [ns.Get (entry.Key)] = entry.Value;
            }

            return module;
        }
    }
}