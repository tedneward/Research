using Moq;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class PrecedenceFactorySpecification {
        [Test]
        public void ShouldCreatePrecedenceWithCorrectProperties () {
            var factory = new PrecedenceFactory ();
            var context = new Mock<IProduction> ().Object;
            var operatorProduction = new Mock<IProduction> ().Object;
            var precedence = factory.Create (context, 34, operatorProduction, false) as Precedence;

            Assert.That (precedence, Is.Not.Null);
            Assert.That (precedence.Context, Is.EqualTo (context));
            Assert.That (precedence.OperatorProduction, Is.EqualTo (operatorProduction));
            Assert.That (precedence.Order, Is.EqualTo (34));
        }
    }
}