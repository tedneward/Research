﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Compiler;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class EvalCompileTest {
        [Test]
        public void EvalShouldHaveReadAccessToCurrentStackFrame () {
            Script.Test (
@"a = 7
eval ""a""",

@"> 7");
        }

        [Test]
        public void EvalShouldHaveWriteAccessToCurrentStackFrame () {
            Script.Test (
@"a := 8
eval ""a := 10""
a",

@"> 10");
        }
        
        [Test]
        public void EvalShouldDeclareNewVariablesAvailableToOtherEvals () {
            Script.Test (
@"
eval ""a := 10""
eval ""a""
",

@"> 10");
        }
        
        [Test]
        public void WritingToConstantInEvalShouldThrowAssignmentToConstantException () {
            Script.AssertEvaluationThrows (typeof (AssignmentToConstantException),
@"a = 10
eval ""a := 8""");
        }

        [Test]
        public void CompileShouldReturnClosure () {
            Script.Test (
@"a = 10
f = tycho:runtime:compile (""a"", current-stack-frame)
f ()
",

@"> 10");
        }

        [Test]
        public void CompileMacroShouldCompileWithCurrentStackFrame () {
            Script.Test (
@"a = 10
f = compile ""a""
f ()",

@"> 10");
        }

    }
}
