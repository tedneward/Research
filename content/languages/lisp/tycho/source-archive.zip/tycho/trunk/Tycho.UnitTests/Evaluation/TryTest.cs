using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class TryTest {
        
        [Test]
        public void ShouldReturnResultOfBlockIfNoExceptionThrown () {
            Script.Test (
@"try
    5
catch 10 => print ""nothing""",

@"> 5");
        }
        
        [Test]
        public void ShouldReturnResultOfMatchingExceptionHandlerIfExceptionThrown () {
            Script.Test (
@"try
    throw 5
catch 5 => 10",

@"> 10");
        }

        [Test]
        public void ShouldAllowMultipleExceptionHandlers () {
            Script.Test (
@"try
    throw struct {width := 3, height := 4}
catch
    {depth, height} => 10 * depth * height
    {width, height} => width * height
    {width, weight} => 20 * width * weight
",

@"> 12");
        }
     
        [Test]
        public void ShouldExecuteFinallyBlockIfNoExceptionThrown () {
            Script.Test (
@"try
    5
finally
    print ""something""",

@"""something""
> 5");
        }

        [Test]
        public void ShouldExecuteFinallyBlockIfExceptionThrown () {
            Script.Test (
@"try
    throw 5
catch 5 => 6
finally
    print ""something""",

@"""something""
> 6");
        }
    }
}