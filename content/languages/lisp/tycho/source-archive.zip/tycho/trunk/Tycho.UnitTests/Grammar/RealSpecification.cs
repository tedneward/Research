using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;
using Tycho.Parser.Tests.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class RealSpecification {
        [Test]
        public void ShouldParseIntegerKeyword () {
            IProduction production = GrammarLoader.CreateReal ();

            ITerm term = production.ParseTerm ("real");
            Assert.IsNotNull (term);
            var compositeTerm = term as CompositeTerm;
            Assert.IsNotNull (compositeTerm);
            Assert.AreEqual ("real", compositeTerm.Name);
            Assert.AreEqual (0, compositeTerm.SubTerms.Count);
        }

        [Test]
        public void ShouldNotParse () {
            IProduction production = GrammarLoader.CreateReal ();

            production.AssertNotParsed ("_real");
            production.AssertNotParsed ("r");
            production.AssertNotParsed ("8");
        }
    }
}