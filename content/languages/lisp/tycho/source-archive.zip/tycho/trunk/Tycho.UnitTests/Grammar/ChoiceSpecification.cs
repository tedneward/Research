using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;
using Tycho.Parser.Tests.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class ChoiceSpecification {
        [Test]
        public void ShouldParseChoiceOperator () {
            IProduction choice = GrammarLoader.CreateChoice (IdentifierProduction.CreateTerminal ());

            ITerm t = choice.ParseTerm ("a / b / c");
            Assert.IsNotNull (t);
            var choiceTerm = t as CompositeTerm;
            Assert.IsNotNull (choiceTerm);
            Assert.AreEqual ("choice", choiceTerm.Name);
            Assert.AreEqual (1, choiceTerm.SubTerms.Count);
            var choices = choiceTerm.SubTerms["choices"] as ListTerm;
            Assert.IsNotNull (choices);
            Assert.AreEqual (3, choices.Terms.Count);
            Assert.AreEqual ("a", ((IdentifierTerm) choices.Terms[0]).Name);
            Assert.AreEqual ("b", ((IdentifierTerm) choices.Terms[1]).Name);
            Assert.AreEqual ("c", ((IdentifierTerm) choices.Terms[2]).Name);
        }

        [Test]
        public void ShouldNotParseNoChoice () {
            IProduction choice = GrammarLoader.CreateChoice (IdentifierProduction.CreateTerminal ());

            choice.AssertNotParsed ("a");
        }
    }
}