﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class RealTest {
        [Test]
        public void TestPlus () {
            Script.Test (
@"1.1 + 2.2",

@"> 3.3");
        }

        [Test]
        public void TestMinus () {
            Script.Test (
@"2.2 - 1.1",

@"> 1.1");
        }

        [Test]
        public void TestNegative () {
            Script.Test (
@"-1.1",

@"> -1.1");
        }

        [Test]
        public void TestMultiply () {
            Script.Test (
@"2.5 * 3.9",

@"> 9.75");
        }

        [Test]
        public void TestDivide () {
            Script.Test (
@"8.1 / 2.5",

@"> 3.24");
        }
        
        [Test]
        public void TestPlusInteger () {
            Script.Test (
@"1.1 + 2",

@"> 3.1");
        }
        
        [Test]
        public void TestMinusInteger () {
            Script.Test (
@"5.5 - 3",

@"> 2.5");
        }
        
        [Test]
        public void TestMultiplyInteger () {
            Script.Test (
@"5.4 * 2",

@"> 10.8");
        }
        
        [Test]
        public void TestDivideInteger () {
            Script.Test (
@"3.3 / 3",

@"> 1.1");
        }

        [Test]
        public void TestLessThan () {
            Script.Test (
@"5.6 < 7.2",

@"> true");
        }

        [Test]
        public void TestLessThanInteger () {
            Script.Test (
@"5.6 < 7",

@"> true");
        }
        
        [Test]
        public void TestLessThanOrEqualTo () {
            Script.Test (
@"5.6 <= 5.6",

@"> true");
        }

        [Test]
        public void TestGreaterThan () {
            Script.Test (
@"4.3 > 2.3",

@"> true");
        }

        [Test]
        public void TestGreaterThanInteger () {
            Script.Test (
@"4.3 > 2",

@"> true");
        }
        
        [Test]
        public void TestGreaterThanOrEqualTo () {
            Script.Test (
@"4.3 >= 4.3",

@"> true");
        }
        
        [Test]
        public void TestToPower () {
            Script.Test (
@"3.1 ^ 4.5",

@"> 162.602651148962");
        }
        
        [Test]
        public void TestToPowerInteger () {
            Script.Test (
@"3.4 ^ 2",

@"> 11.56");
        }

    }
}
