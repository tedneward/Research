using Moq;
using NUnit.Framework;
using Tycho.Compiler;
using Tycho.Runtime;

namespace Tycho.UnitTests.Runtime {
    [TestFixture]
    public class NonRecursiveModuleLoaderTest {
        [Test]
        public void LoadModuleShouldReturnNullIfNamespaceIsNamespaceToBlock () {
            var moduleScopeLoader = new Mock<IModuleScopeLoader> ();

            var symbolScope = new Mock<SymbolScope> ();
            moduleScopeLoader.Setup (m => m.LoadModule (It.IsAny<Namespace> ())).Returns (symbolScope.Object);

            Namespace toBlock = Namespaces.Root.GetNamespace ("to-block");

            var loader = new NonRecursiveModuleLoader (toBlock, moduleScopeLoader.Object);

            Assert.IsNull (loader.LoadModule (toBlock));
        }

        [Test]
        public void LoadModuleShouldReturnNullIfNamespaceIsNestedNamespaceOfNamespaceToBlockAndIncludeNestedNamespaces () {
            var moduleScopeLoader = new Mock<IModuleScopeLoader> ();

            var symbolScope = new Mock<SymbolScope> ();
            moduleScopeLoader.Setup (m => m.LoadModule (It.IsAny<Namespace> ())).Returns (symbolScope.Object);

            Namespace toBlock = Namespaces.Root.GetNamespace ("to-block");
            Namespace nested = toBlock.GetNamespace ("nested");

            var loader = new NonRecursiveModuleLoader (toBlock, moduleScopeLoader.Object, true);

            Assert.IsNull (loader.LoadModule (nested));
        }

        [Test]
        public void LoadModuleShouldReturnResultOfNestedLoaderIfNamespaceIsNestedNamespaceOfNamespaceToBlockAndNotIncludeNestedNamespaces () {
            var moduleScopeLoader = new Mock<IModuleScopeLoader> ();

            Namespace toBlock = Namespaces.Root.GetNamespace ("to-block");
            Namespace nested = toBlock.GetNamespace ("nested");

            var symbolScope = new Mock<SymbolScope> ();
            moduleScopeLoader.Setup (m => m.LoadModule (It.IsAny<Namespace> ())).Callback<Namespace> (ns => Assert.IsTrue(ns == nested)).Returns (symbolScope.Object);

            var loader = new NonRecursiveModuleLoader (toBlock, moduleScopeLoader.Object);

            Assert.AreSame (symbolScope.Object, loader.LoadModule (nested));
        }

        [Test]
        public void LoadModuleShouldReturnResultOfNestedLoaderIfNotBlocking () {
            var moduleScopeLoader = new Mock<IModuleScopeLoader> ();

            Namespace toBlock = Namespaces.Root.GetNamespace ("to-block");
            Namespace notToBlock = Namespaces.Root.GetNamespace ("not-to-block");

            var symbolScope = new Mock<SymbolScope> ();
            moduleScopeLoader.Setup (m => m.LoadModule (It.IsAny<Namespace> ())).Callback<Namespace> (ns => Assert.IsTrue (ns == notToBlock)).Returns (symbolScope.Object);

            var loader = new NonRecursiveModuleLoader (toBlock, moduleScopeLoader.Object);

            Assert.AreSame (symbolScope.Object, loader.LoadModule (notToBlock));
        }
    }
}