﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class AssignmentTest {
        [Test]
        public void TestVariable () {
            Script.Test (
@"a = 8
a",

@"> 8 ");
        }

        [Test]
        public void AssignmentCanBeUsedAsExpressionForAnotherAssignment () {
            Script.Test (
@"a = b = 8
a",

@"> 8 ");
        }

        [Test]
        public void ShouldBeAbleToDeconstructList () {
            Script.Test (
@"[x, y] = list [1, 2]
list [y, x]",

@"> list [2, 1]");
        }

        [Test]
        public void ShouldPlaceStructureFieldsInVariablesOfSameNames () {
            Script.Test (
@"{name, age} = struct {name := ""Ptolemy"", age := ""Neo-lithic""}
list [name, age]",

@"> list [""Ptolemy"", ""Neo-lithic""]");
        }

        [Test]
        public void ShouldPlaceStructureFieldsInVariables () {
            Script.Test (
@"{name = n, age = a} = struct {name := ""Ptolemy"", age := ""Neo-lithic""}
list [n, a]",

@"> list [""Ptolemy"", ""Neo-lithic""]");
        }

        [Test]
        public void TestProperty () {
            Script.Test (
@"a = struct {}
a.name = ""fun ball""
a.name",

@"> ""fun ball""");
        }

        [Test]
        public void TestProperties () {
            Script.Test (
@"a = struct {}
[a.x, a.y] = list [1, 2]
a",

@"> struct {user:x := 1, user:y := 2}");
        }

        [Test]
        public void TestPropertiesExpressionValue () {
            Script.Test (
@"a = struct {}
[a.x, a.y] = list [1, 2]",

@"> list [1, 2]");
        }
        
        [Test]
        public void TestIndex () {
            Script.Test (
@"a = list [1, 2]
a [0] = 3
a",

@"> list [3, 2]");
        }

    }
}
