﻿using System;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class IfTest {
        [Test]
        public void TestIfTrue () {
            Script.Test (
@"if true
	print ""true""
	1",

@"""true""
> 1");
        }

        [Test]
        public void TestIfElseTrue () {
            Script.Test (
@"if true
	print ""true""
	1
else
	print ""false""
	0",

@"""true""
> 1");
        }

        [Test]
        public void TestIfElseFalse () {
            Script.Test (
@"if false
	print ""true""
	1
else
	print ""false""
	0",

@"""false""
> 0");
        }

        [Test]
        public void TestIfFalse () {
            Script.Test (
@"if false
	print ""true""
	1",

@"> null");
        }

        [Test]
        public void ShouldAllowMultipleIfStatements () {
            Script.Test (
@"
f = (a, b) =>
    if a
        if b
            print ""true true""
        else
            print ""true false""
    else
        if b
            print ""false true""
        else
            print ""false false""

f (true, false)
",

@"""true false""
> null");
        }

        [Test]
        public void StackUnwind()
        {
            Wind(12500);
        }

        [Test]
        public void StackUnwindWithContinuations()
        {
            Bounce next = () => BouncingWind(1500000);

            while (next != null)
            {
                next = next();
            }
        }

        private delegate Bounce Bounce();

        void Wind(int n)
        {
            if (n > 0)
            {
                Wind(n - 1);
            }
            else if (n == 0)
            {
                //                throw new ApplicationException();
            }
        }

        Bounce BouncingWind(int n)
        {
            if (n > 0)
            {
                return () => BouncingWind(n - 1);
            } else
            {
                throw new ApplicationException();
            }
        }
    }
}
