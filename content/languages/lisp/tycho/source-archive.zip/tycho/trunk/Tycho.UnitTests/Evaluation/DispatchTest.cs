﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Runtime;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class DispatchTest {
        [Test]
        public void ShouldDispatchToCorrectCaseAndExecuteCase () {
            Script.Test (
@"dispatch 6
    5 =>
       print 5
    6 =>
       print 6",

@"6
> null");
        }

        [Test]
        public void ShouldAcceptSyntaxWithCommas () {
            Script.Test (
@"x = 5
j = dispatch x {7 => 14, 5 => 15}
j",

@"> 15");
        }

        [Test]
        public void ShouldThrowNoSuchCaseForDispatchExceptionWhenNoMatchForValue () {
            Script.AssertEvaluationThrows (typeof (NoSuchCaseForDispatchException),
@"dispatch 6 {1 => 2, 2 => 3}");
        }
    }
}
