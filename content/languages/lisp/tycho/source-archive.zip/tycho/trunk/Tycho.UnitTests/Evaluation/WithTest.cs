using System.Collections.Generic;
using Moq;
using NUnit.Framework;
using Tycho.Compiler;
using Tycho.Runtime;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class WithTest {
        [Test]
        public void WithShouldDisposeObjectAfterBlock () {
            var disposable = new FakeDisposableObject ();

            Dictionary<string, AnyObject> objects = new Dictionary<string, AnyObject> ();
            objects.Add ("disposable", disposable);

            Script.Test (
@"with test:disposable
    print 488
",

@"488
> null", objects);

            Assert.IsTrue (disposable.WasDisposed);
        }

        [Test]
        public void WithShouldAllowDeclarationOfVariableForBlock () {
            var disposable = new FakeDisposableObject ();

            Dictionary<string, AnyObject> objects = new Dictionary<string, AnyObject> ();
            objects.Add ("disposable", disposable);

            Script.Test (
@"with x = test:disposable
    print x
",

@"disposable
> null", objects);

            Assert.IsTrue (disposable.WasDisposed);
        }

        class FakeDisposableObject : AnyObject {
            public bool WasDisposed = false;

            public override AnyObject InvokeMethod (AnyObject self, AnyObject name, params AnyObject[] arguments) {
                if (name == Symbols.RuntimeDispose) {
                    if (!WasDisposed) {
                        WasDisposed = true;
                    } else {
                        Assert.Fail("disposed once too many");
                    }
                }

                return RuntimeModule.Null;
            }

            public override string ToString () {
                return "disposable";
            }
        }
    }
}