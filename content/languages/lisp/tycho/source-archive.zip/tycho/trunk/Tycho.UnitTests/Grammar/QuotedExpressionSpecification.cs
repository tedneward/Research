using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;
using Tycho.Parser.Tests.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class QuotedExpressionSpecification {
        [Test]
        public void ShouldParseIdentifierKeyword () {
            IProduction production = GrammarLoader.CreateQuotedExpression (IdentifierProduction.CreateTerminal ());

            ITerm term = production.ParseTerm ("#a");
            Assert.IsNotNull (term);
            var compositeTerm = term as CompositeTerm;
            Assert.IsNotNull (compositeTerm);
            Assert.AreEqual ("quote", compositeTerm.Name);
            Assert.AreEqual (1, compositeTerm.SubTerms.Count);
            Assert.AreEqual ("a", ((IdentifierTerm) compositeTerm.SubTerms["expression"]).Name);
        }

        [Test]
        public void ShouldNotParse () {
            IProduction production = GrammarLoader.CreateQuotedExpression (IdentifierProduction.CreateTerminal ());

            production.AssertNotParsed ("#3");
            production.AssertNotParsed ("i");
            production.AssertNotParsed ("#");
        }
    }
}