using Moq;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class CompositeTermMacroBuilderSpecification {
        [Test]
        public void ShouldReturnCompositeTermWithSubTerms () {
            var termA = new Mock<ITerm> ().Object;
            var termB = new Mock<ITerm> ().Object;
            var fields = new[] {
                                   new CompositeTermSubTerm ("a", new ConstantTermMacroBuilder (termA)),
                                   new CompositeTermSubTerm ("b", new ConstantTermMacroBuilder (termB))
                               };

            var sinfo = new SourceInformation (null, 0, 0);
            var compositeTermBuilder = new CompositeTermMacroBuilder ("name", fields, sinfo);

            var term = (CompositeTerm) compositeTermBuilder.BuildTerm (null);

            Assert.That (term.SubTerms.Count, Is.EqualTo (2));
            Assert.That (term.Name, Is.EqualTo ("name"));
            Assert.That (term.SubTerms["a"], Is.SameAs (termA));
            Assert.That (term.SubTerms["b"], Is.SameAs (termB));
            Assert.That (term.SourceInformation, Is.SameAs (sinfo));
        }
    }
}