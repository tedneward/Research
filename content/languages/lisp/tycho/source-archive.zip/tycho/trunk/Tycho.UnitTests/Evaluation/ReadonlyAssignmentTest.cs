﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Compiler;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class ReadonlyAssignmentTest {
        [Test]
        public void ShouldNotAllowMultipleAssignments () {
            try {
                Script.Test (
                    @"a = 1
a := 2",

                    @"");
                Assert.Fail ("expected " + typeof (AssignmentToConstantException));
            } catch (AssignmentToConstantException) {
            }
        }
        
        [Test]
        public void SingleAssignmentShouldAssignValue () {
            Script.Test (
@"a = 1
a",

@"> 1");
        }

        [Test]
        public void ComplexSingleAssignmentShouldAssignValue () {
            Script.Test (
@"[a, b] = list [1, 2]
list [b, a]",

@"> list [2, 1]");
        }

        [Test]
        public void ComplexReadonlyVariablesShouldNotBeReassigned () {
            try {
                Script.Test (
                    @"[a, b] = list [1, 2]
a := 6
list [b, a]",

                    @"");
                Assert.Fail ("expected " + typeof (AssignmentToConstantException));
            } catch (AssignmentToConstantException) {
            }
        }

        [Test]
        public void ReadonlyAssignmentShouldThrowVariableAlreadyDeclaredIfVariableIsAlreadyDeclared () {
            try {
                Script.Test (
                    @"a := 6
a = 6
a",

                    @"");
                Assert.Fail ("expected " + typeof (VariableAlreadyDeclaredException));
            } catch (VariableAlreadyDeclaredException) {
            }
        }

        [Test]
        public void ReadonlyAssignmentShouldThrowVariableAlreadyDeclaredIfVariableIsAlreadyDeclaredReadonly () {
            try {
                Script.Test (
                    @"a = 6
a = 6
a",

                    @"");
                Assert.Fail ("expected " + typeof (AssignmentToConstantException));
            } catch (VariableAlreadyDeclaredException) {
            }
        }
    }
}
