using System.Collections.Generic;
using Moq;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class NamedTermMacroBuilderSpecification {
        [Test]
        public void ShouldReturnTermFromNamedTermsWithSameName () {
            var builder = new NamedTermMacroBuilder ("x");

            var termX = new Mock<ITerm> ().Object;
            var namedTerms = new Dictionary<string, ITerm> {{"x", termX}};

            Assert.That (builder.BuildTerm (namedTerms), Is.SameAs (termX));
        }

        [Test]
        public void ShouldThrowExceptionIfTermNotFound () {
            var builder = new NamedTermMacroBuilder ("not-found");

            var termX = new Mock<ITerm> ().Object;
            var namedTerms = new Dictionary<string, ITerm> {{"x", termX}};

            Assert.That (() => { builder.BuildTerm (namedTerms); }, Throws.InstanceOf(typeof (NamedTermNotFoundException)));
        }
    }
}