﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Runtime;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class NamespacesTest {
        [Test]
        public void ShouldImportNamespaceForSubsequentIdentifiers () {
            Script.Test (
@"f = () =>
    import tycho:runtime as r
    list [1, 2, 3].r:map (n => n + 1)

f ()",
"> list [2, 3, 4]"
                );
        }

        [Test]
        public void ImportedNamespaceShouldBeActiveWithinScopeOnly () {
            try {
                Script.Test (
@"f = () =>
    import tycho:runtime as r
    list [1, 2, 3].r:map (n => n + 1)

f ().r:count",
                    "> null"
                    );
                Assert.Fail("expected to not find property r:count");
            } catch (NoSuchPropertyException) {
            }
        }
    }
}
