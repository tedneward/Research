using Moq;
using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class ListTermMacroBuilderSpecification {
        [Test]
        public void ShouldReturnListTermWithTermsReturnedFromBuilders () {
            var term1 = new Mock<ITerm> ().Object;
            var term2 = new Mock<ITerm> ().Object;
            var term3 = new Mock<ITerm> ().Object;
            var builders = new[] {
                                     new ConstantTermMacroBuilder (term1),
                                     new ConstantTermMacroBuilder (term2),
                                     new ConstantTermMacroBuilder (term3)
                                 };

            var sinfo = new SourceInformation (null, 0, 0);
            var listBuilder = new ListTermMacroBuilder (builders, sinfo);

            var term = (ListTerm) listBuilder.BuildTerm (null);
            Assert.That (term.Terms.Count, Is.EqualTo (3));
            Assert.That (term.Terms[0], Is.SameAs (term1));
            Assert.That (term.Terms[1], Is.SameAs (term2));
            Assert.That (term.Terms[2], Is.SameAs (term3));
            Assert.That (term.SourceInformation, Is.SameAs (sinfo));
        }
    }
}