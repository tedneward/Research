﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Tycho.UnitTests.Evaluation {
    [TestFixture]
    public class IntegerTest {
        [Test]
        public void TestPlus () {
            Script.Test ("1 + 2", "> 3");
        }

        [Test]
        public void TestMinus () {
            Script.Test ("2 - 1", "> 1");
        }

        [Test]
        public void TestNegative () {
            Script.Test ("-1", "> -1");
        }

        [Test]
        public void TestMultiply () {
            Script.Test ("2 * 3", "> 6");
        }
        
        [Test]
        public void TestDivide () {
            Script.Test ("7 / 2", "> 3");
        }

        [Test]
        public void TestPlusReal () {
            Script.Test ("1 + 2.1", "> 3.1");
        }

        [Test]
        public void TestMinusReal () {
            Script.Test ("5 - 3.5", "> 1.5");
        }

        [Test]
        public void TestMultiplyReal () {
            Script.Test ("2 * 5.4", "> 10.8");
        }

        [Test]
        public void TestDivideReal () {
            Script.Test ("3 / 2.5", "> 1.2");
        }

        [Test]
        public void TestPlusString () {
            Script.Test (
@"4 + "" hero""",

@"> ""4 hero""");
        }

        
        [Test]
        public void TestMultiplyString () {
            Script.Test (
@"4 * ""stars""",

@"> ""starsstarsstarsstars""");
        }

        [Test]
        public void TestLessThan () {
            Script.Test ("4 < 6", "> true");
        }

        [Test]
        public void TestLessThanReal () {
            Script.Test ("4 < 6.8", "> true");
        }
        
        [Test]
        public void TestLessThanOrEqualTo () {
            Script.Test ("4 <= 4", "> true");
        }

        [Test]
        public void TestGreaterThan () {
            Script.Test ("5 > 4", "> true");
        }

        [Test]
        public void TestGreaterThanReal () {
            Script.Test ("5 > 4.3", "> true");
        }
        
        [Test]
        public void TestGreaterThanOrEqualTo () {
            Script.Test ("5 >= 5", "> true");
        }
        
        [Test]
        public void TestToPower () {
            Script.Test ("2 ^ 3", "> 8");
        }
        
        [Test]
        public void TestToPowerReal () {
            Script.Test ("2 ^ 2.5", "> 5.65685424949238");
        }
        
        [Test]
        public void TestEquals () {
            Script.Test ("2 == 2", "> true");
        }
        
        [Test]
        public void TestEqualsFalse () {
            Script.Test ("2 == 3", "> false");
        }

        [Test]
        public void TestNotEqualsFalse () {
            Script.Test ("2 != 2", "> false");
        }
        
        [Test]
        public void TestNotEquals () {
            Script.Test ("2 != 3", "> true");
        }
        
        [Test]
        public void TestMultiplyPrecedenceOverPlus () {
            Script.Test ("2 + 3 * 4", "> 14");
            Script.Test ("3 * 4 + 2", "> 14");
        }

        [Test]
        public void ToPowerShouldBeRightAssociative () {
            Script.Test ("4 ^ 3 ^ 2", "> 262144");
        }

        [Test]
        public void DivideShouldBeLeftAssociative () {
            Script.Test ("8 / 2 / 2", "> 2");
        }

        [Test]
        public void MinusShouldBeLeftAssociative () {
            Script.Test ("8 - 2 - 2", "> 4");
        }

        [Test]
        public void PowerShouldBeHighPrecedenceThanPlus () {
            Script.Test ("2 ^ 3 + 4", "> 12");
        }
    }
}
