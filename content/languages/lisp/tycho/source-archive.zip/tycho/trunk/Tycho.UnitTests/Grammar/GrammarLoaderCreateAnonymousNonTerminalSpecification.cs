using NUnit.Framework;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.UnitTests.Grammar {
    [TestFixture]
    public class GrammarLoaderCreateAnonymousNonTerminalSpecification {
        [Test]
        public void ShouldParseSequence () {
            IProduction production = GrammarLoader.CreateAnonymousNonTerminal (IdentifierProduction.CreateTerminal ());

            ITerm t = production.ParseTerm ("('a' / 'b')");
            Assert.IsNotNull (t);
            var expected =
                "anonymous-non-terminal {rule: choice {choices: [keyword {name: \"a\"}, keyword {name: \"b\"}]}}";
            Assert.AreEqual (expected, t.ToString ());
        }
    }
}