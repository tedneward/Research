﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tycho.Runtime;

namespace Tycho.Transactions {
    public interface ITransactionalObject {
        void Commit ();
        void RollBack ();
        bool Prepare ();
        TransactionLog.LocalObject CreateTransactionLocalObject ();
        TransactionLog.LocalObject CreateNestedTransactionLocalObject (TransactionLog.LocalObject localObject);
        IEnumerable<AnyObject> ObjectReferences { get; }
        bool IsTransactional { get; }
        void Transactionalise ();
        long Version { get; }
    }
}
