﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tycho.Runtime;

namespace Tycho.Transactions {
    class NestedTransactionLog : TransactionLog, IDisposable {
        TransactionLog OuterLog;

        public NestedTransactionLog () {
            OuterLog = TransactionalObjectManager.Manager.TransactionLog;
            TransactionalObjectManager.Manager.TransactionLog = this;
        }

        protected override LocalObject GetObjectFromLive (ITransactionalObject liveObject) {
            LocalObject localObject = OuterLog.GetLocalObject (liveObject, false);
            return liveObject.CreateNestedTransactionLocalObject (localObject);
        }

        #region IDisposable Members

        public void Dispose () {
            TransactionalObjectManager.Manager.TransactionLog = OuterLog;
        }

        #endregion
    }
}
