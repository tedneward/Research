﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tycho.Runtime;

namespace Tycho.Transactions {
    public class TransactionConflictException : TychoException {
        public TransactionConflictException () : base ("transaction conflict") { }
    }
}
