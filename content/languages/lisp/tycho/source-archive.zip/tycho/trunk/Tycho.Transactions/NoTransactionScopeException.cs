﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tycho.Runtime;

namespace Tycho.Transactions {
    public class NoTransactionScopeException : TychoException {
        public NoTransactionScopeException () : base ("transactional object must have transaction scope") { }
    }
}
