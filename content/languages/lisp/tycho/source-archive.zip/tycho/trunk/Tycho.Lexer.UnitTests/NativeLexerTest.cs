﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Tycho.Parser.Tokens;

namespace Tycho.Lexer.UnitTests {
    [TestFixture]
    public class NativeLexerTest {
        private const string FileName = "filename";
        private const int LineStart = 3;
        private const int ColStart = 11;

        private List<Token> InterpolateString (string str) {
            return NativeLexer.InterpolateString (str, new SourceLocation (str, "filename", LineStart, LineStart, ColStart, ColStart + str.Length));
        }

        [Test]
        public void ShouldInterpolateIdentifier () {
            List<Token> tokens = InterpolateString (@"a #b c");

            Assert.AreEqual (3, tokens.Count);
            Assert.AreEqual ("a ", ((StringToken) tokens [0]).Value);
            Assert.AreEqual ("b", ((IdentifierToken) tokens [1]).Identifier);
            Assert.AreEqual (" c", ((StringToken) tokens [2]).Value);
        }

        [Test]
        public void ShouldInterpolateTwoIdentifiersInARow () {
            List<Token> tokens = InterpolateString (@"#a#b");

            Assert.AreEqual (2, tokens.Count);
            Assert.AreEqual ("a", ((IdentifierToken) tokens [0]).Identifier);
            Assert.AreEqual ("b", ((IdentifierToken) tokens [1]).Identifier);
        }

        [Test]
        public void ShouldNotInterpolateIdentifierWithNamespace () {
            List<Token> tokens = InterpolateString (@"#a:b");

            Assert.AreEqual (2, tokens.Count);
            IdentifierToken identifier = (IdentifierToken) tokens [0];
            Assert.AreEqual ("a", identifier.Identifier);
            Assert.IsNull (identifier.ModulePath);
            Assert.AreEqual (":b", ((StringToken) tokens [1]).Value);
        }

        [Test]
        public void ShouldInterpolateOneTokenOnly () {
            List<Token> tokens = InterpolateString (@"#a");

            Assert.AreEqual (1, tokens.Count);
            IdentifierToken identifier = (IdentifierToken) tokens [0];
            Assert.AreEqual ("a", identifier.Identifier);
        }

        [Test]
        public void ShouldInterpolateParenthesis () {
            List<Token> tokens = InterpolateString (@"a #(x + y) c");

            Assert.AreEqual (3, tokens.Count);
            Assert.AreEqual ("a ", ((StringToken) tokens [0]).Value);

            BracketToken bracketToken = (BracketToken) tokens [1];
            Assert.AreEqual (BracketType.Parenthesis, bracketToken.BracketType);
            Assert.AreEqual (3, bracketToken.Tokens.Count);
            Assert.AreEqual ("x", ((IdentifierToken) bracketToken.Tokens [0]).Identifier);
            Assert.AreEqual ("+", ((IdentifierToken) bracketToken.Tokens [1]).Identifier);
            Assert.AreEqual ("y", ((IdentifierToken) bracketToken.Tokens [2]).Identifier);

            Assert.AreEqual (" c", ((StringToken) tokens [2]).Value);
        }

        [Test]
        public void ShouldEscapeInterpolation () {
            List<Token> tokens = InterpolateString (@"a \#(x + y) c");

            Assert.AreEqual (1, tokens.Count);
            StringToken stringToken = (StringToken) tokens [0];
            Assert.AreEqual ("a \\#(x + y) c", stringToken.Value);
            Assert.AreEqual ("a #(x + y) c", stringToken.UnescapedValue);
        }

        [Test]
        public void ShouldInterpolateIdentifierWithCorrectSourceLocation () {
            List<Token> tokens = InterpolateString (@"a #y c");

            Assert.AreEqual (3, tokens.Count);
            Assert.AreEqual ("a ", ((StringToken) tokens [0]).Value);
            Assert.AreEqual ("y", ((IdentifierToken) tokens [1]).Identifier);
            SourceLocation sloc = tokens [1].SourceLocation;
            Assert.AreEqual (LineStart, sloc.LineStart);
            Assert.AreEqual (LineStart, sloc.LineEnd);
            Assert.AreEqual (ColStart + 3, sloc.ColumnStart);
            Assert.AreEqual (ColStart + 4, sloc.ColumnEnd);
            Assert.AreEqual (FileName, sloc.FileName);

            Assert.AreEqual (" c", ((StringToken) tokens [2]).Value);
        }

        [Test]
        public void ShouldLexTokensWithCorrectSourceLocations () {
            StringWriter writer = new StringWriter ();

            string code =
@"a b c
a * b
a (b c d e)
a {b c d e}
a [b c d e]
a
    b c d e
a {
    b
    c
    d
    e
}
a {b c
   d e}
a ""string""
""with \""quotes""";

            var tokens = NativeLexer.Lex (code, "filename");

            PrintSourceLocations (tokens, writer);

            string output = writer.ToString ();
            Console.WriteLine (output);
        }

        [Test]
        public void ShouldLexTokensWithCorrectSourceLocations2 () {
            StringWriter writer = new StringWriter ();

            string code =
@"a
    b
";

            var tokens = NativeLexer.Lex (code, "filename");

            PrintSourceLocations (tokens, writer);

            string output = writer.ToString ();
            Console.WriteLine (output);
        }

        private void PrintTokensFromSource (string source) {
            StringWriter writer = new StringWriter ();

            var tokens = NativeLexer.Lex (source, "filename");

            PrintTokens (tokens, writer, 0);

            string output = writer.ToString ();
            Console.WriteLine (output);
        }

        private static void PrintSourceLocations (List<Token> tokens, TextWriter writer) {
            foreach (Token token in tokens) {
                PrintSourceLocation (token.SourceLocation, writer);

                if (token is BracketToken) {
                    PrintSourceLocations (((BracketToken) token).Tokens, writer);
                }
            }
        }

        private static void PrintTokens (List<Token> tokens, TextWriter writer, int indent) {
            foreach (Token token in tokens) {
                if (token is BracketToken) {
                    writer.WriteLine (new string (' ', indent * 2) + "(bracket " + ((BracketToken) token).BracketType);
                    PrintTokens (((BracketToken) token).Tokens, writer, indent + 1);
                    writer.WriteLine(new string (' ', indent * 2) + ")");
                } else {
                    writer.WriteLine (new string (' ', indent * 2) + token);
                }
            }
        }

        private static void PrintSourceLocation (SourceLocation sloc, TextWriter writer) {
            if (sloc.FileName != null) {
                writer.WriteLine ("file: " + sloc.FileName);
            }

            if (sloc.LineStart != sloc.LineEnd) {
                StringReader source = new StringReader (sloc.Source);

                for (int n = 0; n < sloc.LineStart - 1; n++) {
                    source.ReadLine ();
                }

                int lineNumberLength = sloc.LineEnd.ToString ().Length;

                for (int n = sloc.LineStart; n <= sloc.LineEnd; n++) {
                    writer.WriteLine (PadLeftSpaces (n, lineNumberLength) + ": > " + source.ReadLine ());
                }
            } else {
                StringReader source = new StringReader (sloc.Source);

                for (int n = 0; n < sloc.LineStart - 1; n++) {
                    source.ReadLine ();
                }

                string lineNumber = sloc.LineEnd + ": ";
                string line = source.ReadLine ();
                string indicatorLine = new String (' ', lineNumber.Length) + GetPaddingFromIndent (line, sloc.ColumnStart) + new String ('^', sloc.ColumnEnd - sloc.ColumnStart);

                writer.WriteLine (lineNumber + line);
                writer.WriteLine (indicatorLine);
            }
        }

        static string GetPaddingFromIndent (string errorLine, int errorStart) {
            if (errorStart == 0) {
                return "";
            }

            StringBuilder sb = new StringBuilder (errorStart);
            char c = errorLine [0];
            int n = 0;

            while (n < errorLine.Length && n < errorStart && char.IsWhiteSpace (c = errorLine [n])) {
                sb.Append (c);
                n++;
            }

            while (n < errorStart) {
                sb.Append (' ');
                n++;
            }

            return sb.ToString ();
        }

        static string PadLeftSpaces (int number, int padToLength) {
            string numberString = number.ToString ();

            return new String (' ', padToLength - numberString.Length) + numberString;
        }
    }
}
