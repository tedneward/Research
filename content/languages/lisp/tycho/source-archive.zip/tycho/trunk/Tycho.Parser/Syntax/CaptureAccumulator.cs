using System.Collections.Generic;

namespace Tycho.Parser.Syntax {
    public class CaptureAccumulator : ICaptureAccumulator {
        public Dictionary<string, bool> Captures;

        public CaptureAccumulator() {
            Captures = new Dictionary<string, bool>();
        }

        public void Add (string name) {
            Add (name, false);
        }

        public void Add (string name, bool isMultiple) {
            if (Captures.ContainsKey (name)) {
                Captures[name] = true;
            } else {
                Captures.Add (name, isMultiple);
            }
        }
    }
}