using System;

namespace Tycho.Parser.Peg {
    public class Precedence : IPrecedence {
        public readonly IProduction OperatorProduction;
        public readonly int Order;
        public readonly IProduction Context;

        public Precedence (IProduction operatorProduction, int order, IProduction context) {
            OperatorProduction = operatorProduction;
            Order = order;
            Context = context;
        }

        public bool IsGreaterThan (IPrecedence p) {
            var precedence = (Precedence) p;
            if (precedence.OperatorProduction == OperatorProduction && OperatorProduction.IsLeftRecursive) {
                return true;
            } else if (Context == precedence.Context) {
                return Order < precedence.Order;
            } else {
                return false;
            }
        }
    }
}