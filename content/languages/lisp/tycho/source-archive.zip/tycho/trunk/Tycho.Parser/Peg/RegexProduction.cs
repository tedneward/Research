using System;
using System.Text.RegularExpressions;

namespace Tycho.Parser.Peg {
    public class RegexProduction : Production {
        private Regex Regex;

        public RegexProduction (string pattern) {
            Regex = new Regex (pattern);

            ErrorInformation = new RegexErrorInformation (pattern);
        }

        protected override ParseResult ReallyParse (char[] source, int index, ParseContext context, string sourceString, ParseEnvironment parseEnvironment) {
            Match match = Regex.Match (sourceString, index);

            if (match.Success && match.Index == index) {
                int endIndex = index + match.Value.Length;
                SourceInformation sinfo = parseEnvironment.SourceFileInformation.CreateSourceInformation (index, match.Value.Length);
                ITerm term = new StringTerm (match.Value, sinfo);
                return new ParseResult (endIndex, term, context);
            } else {
                return null;
            }
        }
    }
}