using System;

namespace Tycho.Parser.Peg {
    public class InfixInformation : IInfixInformation {
        private readonly IProduction Production;
        public IRule First { get; set; }
        public IRule Last { get; set; }

        public InfixInformation (IRule first, IRule last, IProduction production) {
            Production = production;
            First = first;
            Last = last;
        }

        public bool IsInfixWith (IProduction production) {
            return Production == production;
        }

        public bool IsInfix {
            get { return true; }
        }
    }
}