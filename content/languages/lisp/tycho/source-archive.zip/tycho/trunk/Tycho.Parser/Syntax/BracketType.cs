namespace Tycho.Parser.Syntax {
    public enum BracketType {
        Brace,
        Bracket,
        Parenthesis
    }
}