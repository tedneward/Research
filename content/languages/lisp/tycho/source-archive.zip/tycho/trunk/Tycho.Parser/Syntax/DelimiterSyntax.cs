using System;
using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Parser.Syntax {
    public class DelimiterSyntax : Syntax {
        public Syntax Item;
        public Syntax Delimiter;

        public DelimiterSyntax (Syntax item, Syntax delimiter) {
            Item = item;
            Delimiter = delimiter;
        }

        public override Production Compile (ProductionLookup productionLookup) {
            throw new System.NotImplementedException ();
        }

        public override void AccumulateCaptures (ICaptureAccumulator accumulator) {
            var multipleAccumulator = new MultipleCaptureAccumulator (accumulator);
            Item.AccumulateCaptures (multipleAccumulator);
            Delimiter.AccumulateCaptures (multipleAccumulator);
        }
    }
}