namespace Tycho.Parser.Peg {
    public class ProductionErrorInformation : IErrorInformation {
        public string Name { get; private set; }

        public ProductionErrorInformation (string name) {
            Name = name;
        }

        public override string ToString()
        {
            return Name;
        }
    }
}