namespace Tycho.Parser.Peg {
    public struct ProductionInvocation {
        public readonly IProduction Production;
        public int Index;

        public ProductionInvocation (IProduction production, int index) {
            Production = production;
            Index = index;
        }
    }
}