using System;

namespace Tycho.Parser.Peg {
    public class EndOfFileProduction : Production {
        protected override ParseResult ReallyParse (char[] source, int index, ParseContext context, string sourceString, ParseEnvironment parseEnvironment) {
            index = SkipWhitespaceAndNewLines (source, index);
            if (index >= source.Length) {
                return new ParseResult (index, null, context);
            } else {
                return null;
            }
        }

        public static int SkipWhitespaceAndNewLines (char[] source, int index) {
            char c;
            while (index < source.Length && ((c = source[index]) == ' ' || c == '\t' || c == '\n' || c == '\r')) {
                index++;
            }

            return index;
        }
    }
}