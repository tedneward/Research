using System;
using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Parser.Syntax {
    public class CaptureSyntax : Syntax {
        public string Name;
        public Language Language;

        public CaptureSyntax (string name, Language language) {
            Name = name;
            Language = language;
        }

        public override Production Compile (ProductionLookup productionLookup) {
            var production = productionLookup[Language];
            productionLookup.IsFirst = false;
            return production;
        }

        public override void AccumulateCaptures (ICaptureAccumulator accumulator) {
            accumulator.Add (Name);
        }
    }
}