using System;

namespace Tycho.Parser.Peg {
    public class ParseResult : MemoisedParseResult {
        public ParseResult (int index, ITerm term, ParseContext context) {
            Index = index;
            Term = term;
            Context = context;
        }

        public override string ToString()
        {
            return String.Format ("({0}) {1}", Index, Term);
        }
    }
}