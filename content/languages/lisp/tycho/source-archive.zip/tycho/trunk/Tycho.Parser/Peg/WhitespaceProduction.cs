using System;

namespace Tycho.Parser.Peg {
    public class Whitespace {
        public static int SkipWhitespace (char[] source, int index) {
            char c;
            while (index < source.Length && ((c = source[index]) == ' ' || c == '\t')) {
                index++;
            }

            return index;
        }

        public static int SkipWhitespaceAndNewLines (char[] source, int index) {
            char c;
            while (index < source.Length && ((c = source[index]) == ' ' || c == '\t' || c == '\n' || c == '\r')) {
                index++;
            }

            return index;
        }
    }
}
