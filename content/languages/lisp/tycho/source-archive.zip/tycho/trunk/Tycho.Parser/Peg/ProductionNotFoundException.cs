using System;

namespace Tycho.Parser.Peg {
    public class ProductionNotFoundException : Exception {
        public ProductionNotFoundException () : base (String.Format("production not found in context")) {
        }
    }
}