using System;
using Tycho.Parser.Syntax;

namespace Tycho.Parser.Peg {
    public class KeywordRule : LiteralRule {
        public KeywordRule (string keyword) : this (keyword, new SpecialKeywordBuilder()) {}

        public KeywordRule (string keyword, ISpecialKeywordBuilder builder) : base (builder.Build (keyword)) {
        }
    }
}