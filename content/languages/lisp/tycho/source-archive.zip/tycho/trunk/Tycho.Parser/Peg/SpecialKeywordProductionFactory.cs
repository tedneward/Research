using System;

namespace Tycho.Parser.Peg {
    class SpecialKeywordProductionFactory : ISpecialKeywordProductionFactory {
        private readonly IProduction StatementDelimiter;
        private readonly IProduction EndBlock;
        private readonly IProduction BeginBlock;

        public SpecialKeywordProductionFactory () {
            var endBlockStatementDelimiter = new EndBlockStatementDelimiterFactory ().Create ();

            StatementDelimiter = endBlockStatementDelimiter.StatementDelimiter;
            EndBlock = endBlockStatementDelimiter.EndBlock;
            BeginBlock = BeginBlockProduction.CreateTerminal ();
        }

        public IProduction CreateBeginBlock () {
            return BeginBlock;
        }

        public IProduction CreateEndBlock () {
            return EndBlock;
        }

        public IProduction CreateStatementDelimiter () {
            return StatementDelimiter;
        }

        public IProduction CreateIdentifierKeyword (string keyword) {
            return IdentifierKeywordProduction.CreateTerminal (keyword);
        }

        public IProduction CreateOperatorKeyword (string keyword) {
            return OperatorKeywordProduction.CreateTerminal (keyword);
        }

        public IProduction CreatePunctuation (string keyword) {
            return PunctuationProduction.CreateTerminal (keyword);
        }

        public IProduction CreateDecrementingPunctuation (string keyword) {
            var punctuation = PunctuationProduction.CreateTerminal (keyword);
            punctuation.ResultTransform = ParseContext.ContextAction (c => c.BracketDepth--);
            return punctuation;
        }

        public IProduction CreateIncrementingPunctuation (string keyword) {
            var punctuation = PunctuationProduction.CreateTerminal (keyword);
            punctuation.ResultTransform = ParseContext.ContextAction (c => c.BracketDepth++);
            return punctuation;
        }
    }
}