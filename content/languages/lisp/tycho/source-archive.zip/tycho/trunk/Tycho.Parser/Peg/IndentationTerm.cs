using System;

namespace Tycho.Parser.Peg
{
    class IndentationTerm : Term
    {
        public string Indent;

        public IndentationTerm (string indent, SourceInformation sourceInformation) : base (sourceInformation)
        {
            Indent = indent;
        }

        public Indentation GetIndentation (string currentIndent) {
            if (Indent == null) {
                return Indentation.EndBlock;
            } else if (currentIndent == Indent) {
                return Indentation.StatementDelimiter;
            } if (Indent.StartsWith (currentIndent)) {
                return Indentation.BeginBlock;
            } else if (currentIndent.StartsWith (Indent)) {
                return Indentation.EndBlock;
            } else {
                return Indentation.Error;
            }
        }
    }
}