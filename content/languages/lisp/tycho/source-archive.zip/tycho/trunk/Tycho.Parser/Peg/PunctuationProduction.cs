namespace Tycho.Parser.Peg {
    public class PunctuationProduction : Production {
        private string Punctuation;

        public PunctuationProduction (string punctuation) {
            Punctuation = punctuation;
            ErrorInformation = new KeywordErrorInformation (punctuation);
        }

        public static Terminal CreateTerminal (string punctuation) {
            return new Terminal (new PunctuationProduction (punctuation));
        }

        protected override ParseResult ReallyParse (char[] source, int index, ParseContext context, string sourceString, ParseEnvironment parseEnvironment) {
            if (index + Punctuation.Length > source.Length) {
                return null;
            }

            if (new string (source, index, Punctuation.Length) == Punctuation) {
                return new ParseResult (index + Punctuation.Length, null, context);
            } else {
                return null;
            }
        }

        public override string ToString()
        {
            return Punctuation;
        }
    }
}