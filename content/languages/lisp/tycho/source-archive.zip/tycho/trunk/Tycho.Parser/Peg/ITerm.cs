namespace Tycho.Parser.Peg {
    public interface ITerm {
        SourceInformation SourceInformation { get; set; }
    }
}