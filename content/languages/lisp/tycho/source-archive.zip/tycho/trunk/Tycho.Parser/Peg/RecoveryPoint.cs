using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    public class RecoveryPoint {
        public readonly IProduction RecoveredProduction;
        public readonly IProduction RecoveryProduction;
        public readonly IEnumerable<ProductionInvocation> ProductionInvocationStack;

        public RecoveryPoint (IProduction recoveredProduction, IProduction recoveryProduction, IEnumerable<ProductionInvocation> productionInvocationStack) {
            ProductionInvocationStack = productionInvocationStack;
            RecoveredProduction = recoveredProduction;
            RecoveryProduction = recoveryProduction;
        }
    }
}