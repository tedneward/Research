using System;
using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Parser.Syntax {
    public class MultipleSyntax : Syntax {
        public int Minimum;
        public int Maximum;
        public Syntax Syntax;

        public MultipleSyntax (int minimum, int maximum, Syntax syntax) {
            Minimum = minimum;
            Maximum = maximum;
            Syntax = syntax;
        }

        public override Production Compile (ProductionLookup productionLookup) {
            bool initialIsFirst = productionLookup.IsFirst;
            var production = Syntax.Compile (productionLookup);
            productionLookup.IsFirst = initialIsFirst;
            return production;
        }

        public override void AccumulateCaptures (ICaptureAccumulator accumulator) {
            Syntax.AccumulateCaptures (new MultipleCaptureAccumulator (accumulator));
        }
    }
}