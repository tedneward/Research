using System;

namespace Tycho.Parser.Peg {
    public class IntegerProduction : Production {
        public IntegerProduction () {
            Name = "integer";
            ErrorInformation = new ProductionErrorInformation ("integer");
        }

        public static Terminal CreateTerminal () {
            return new Terminal (new IntegerProduction ());
        }

        protected override ParseResult ReallyParse (char[] source, int startIndex, ParseContext context, string sourceString, ParseEnvironment parseEnvironment) {
            int index = startIndex;

            char c = source[index];
            int accumulator = 0;
            while (c >= '0' && c <= '9') {
                accumulator = accumulator*10 + c - '0';

                index++;

                if (index < source.Length) {
                    c = source[index];
                } else {
                    break;
                }
            }

            if (index != startIndex) {
                return new ParseResult (index, new IntegerTerm (accumulator, parseEnvironment.SourceFileInformation.CreateSourceInformation (startIndex, index - startIndex)), context);
            } else {
                return null;
            }
        }
    }
}