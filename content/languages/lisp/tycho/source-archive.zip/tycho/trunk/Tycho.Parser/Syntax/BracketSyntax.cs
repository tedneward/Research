using System;
using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Parser.Syntax {
    public class BracketSyntax : Syntax {
        public BracketType BracketType;
        public bool isOpen;
        public override Production Compile (ProductionLookup productionLookup) {
            throw new System.NotImplementedException ();
        }

        public override void AccumulateCaptures (ICaptureAccumulator accumulator) {
        }
    }
}