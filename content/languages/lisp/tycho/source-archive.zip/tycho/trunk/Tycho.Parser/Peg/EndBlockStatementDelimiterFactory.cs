namespace Tycho.Parser.Peg {
    class EndBlockStatementDelimiterFactory {
        public EndBlockStatementDelimiter Create () {
            var statementDelimiter = StatementDelimiterProduction.CreateTerminal ();
            var clearer = new MemoClearer ();
            var endBlock = new EndBlockProduction (clearer);

            clearer.Productions = new[] {
                                            statementDelimiter,
                                            statementDelimiter.TerminalProduction,
                                            endBlock,
                                        };

            return new EndBlockStatementDelimiter {EndBlock = endBlock, StatementDelimiter = statementDelimiter};
        }

        internal class EndBlockStatementDelimiter {
            public IProduction EndBlock;
            public IProduction StatementDelimiter;
        }
    }
}