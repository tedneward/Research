using System;

namespace Tycho.Parser.Peg {
    public class SyntaxErrorRecoveryException : Exception {
        public readonly ParseResult Result;
        public readonly IProduction Production;

        public SyntaxErrorRecoveryException (ParseResult result, IProduction production) {
            Result = result;
            Production = production;
        }
    }
}