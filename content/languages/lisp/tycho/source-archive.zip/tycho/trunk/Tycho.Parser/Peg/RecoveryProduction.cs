namespace Tycho.Parser.Peg {
    public class RecoveryProduction : Production {
        private readonly IProduction Production;
        private readonly IProduction RecoveryPoint;

        public RecoveryProduction (IProduction production, IProduction recoveryPoint) {
            Production = production;
            RecoveryPoint = recoveryPoint;
            ErrorInformation = null;
        }

        protected override ParseResult ReallyParse (char[] source, int index, ParseContext context, string sourceString, ParseEnvironment environment) {
            environment.SyntaxErrorRecoverer.AddRecoveryPoint (RecoveryPoint);
//            environment.SyntaxErrorRecoverer.PushRecoveryPoint (new RecoveryPoint (this, RecoveryPoint, environment.LeftRecursionInformation.ProductionInvocationStack));
            try {
                return Production.Parse (source, index, context, sourceString, environment);
            } catch (SyntaxErrorRecoveryException rpe) {
                if (rpe.Production == RecoveryPoint) {
                    environment.SyntaxErrors.AddErrorRecovery (this, index, rpe.Result);
                    return rpe.Result;
                } else {
                    throw;
                }
            } finally {
//                environment.SyntaxErrorRecoverer.PopRecoveryPoint ();
            }
        }
    }
}