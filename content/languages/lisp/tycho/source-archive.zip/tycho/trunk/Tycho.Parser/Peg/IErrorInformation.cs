namespace Tycho.Parser.Peg {
    public interface IErrorInformation {}
}