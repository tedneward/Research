namespace Tycho.Parser.Peg {
    public interface ISourceFileInformation {
        SourceInformation CreateSourceInformation (int index, int length);
        string FileName { get; }
    }
}