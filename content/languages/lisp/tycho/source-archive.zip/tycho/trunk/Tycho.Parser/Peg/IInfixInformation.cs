using System;

namespace Tycho.Parser.Peg {
    public interface IInfixInformation {
        IRule First { get; }
        IRule Last { get; }
        bool IsInfixWith (IProduction production);
        bool IsInfix { get; }
    }
}