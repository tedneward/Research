using System;

namespace Tycho.Parser.Peg {
    public class NotInfixInformation : IInfixInformation {
        public IRule First {
            get { throw new InvalidOperationException (); }
        }

        public IRule Last {
            get { throw new InvalidOperationException (); }
        }

        public bool IsInfixWith (IProduction production) {
            return false;
        }

        public bool IsInfix {
            get { return false; }
        }
    }
}