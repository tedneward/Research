namespace Tycho.Parser.Peg {
    public class KeywordErrorInformation : IErrorInformation {
        public string Keyword { get; private set; }

        public KeywordErrorInformation (string keyword) {
            Keyword = keyword;
        }

        public override string ToString()
        {
            return "'" + Keyword + "'";
        }
    }
}