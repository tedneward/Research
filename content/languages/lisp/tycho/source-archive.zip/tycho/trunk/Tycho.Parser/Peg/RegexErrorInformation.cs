namespace Tycho.Parser.Peg {
    public class RegexErrorInformation : IErrorInformation {
        public string Pattern { get; private set; }

        public RegexErrorInformation (string pattern) {
            Pattern = pattern;
        }

        public override string ToString()
        {
            return "/" + Pattern + "/";
        }
    }
}