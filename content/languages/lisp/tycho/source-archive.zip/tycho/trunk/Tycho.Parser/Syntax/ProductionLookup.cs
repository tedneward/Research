using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Parser.Syntax {
    public class ProductionLookup {
        public bool IsFirst;
        public Language DefaultLanguage;
        public Dictionary<Language, Production> Productions;
        public Production NextProduction;

        public ProductionLookup (Language defaultLanguage, Dictionary<Language, Production> productions, Production nextProduction) {
            IsFirst = true;
            DefaultLanguage = defaultLanguage;
            Productions = productions;
            NextProduction = nextProduction;
        }

        public Production this [Language language] {
            get {
                if (language == null) {
                    language = DefaultLanguage;
                }

                if (language == DefaultLanguage && IsFirst) {
                    return NextProduction;
                }

                return Productions[language];
            }
        }
    }
}