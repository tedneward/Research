namespace Tycho.Parser.Peg {
    public abstract class Term : ITerm {
        public SourceInformation SourceInformation { get; set; }

        protected Term (SourceInformation sourceInformation) {
            SourceInformation = sourceInformation;
        }
    }
}