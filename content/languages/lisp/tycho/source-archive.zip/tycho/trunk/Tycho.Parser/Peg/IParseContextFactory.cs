using System;

namespace Tycho.Parser.Peg {
    public interface IParseContextFactory {
        ParseContext CreateWithDynamicGrammar (IDynamicGrammar dynamicGrammar);
    }
}