using System;

namespace Tycho.Parser.Peg {
    public interface IParseEnvironmentFactory {
        ParseEnvironment CreateWithFilename (string filename);
    }
}