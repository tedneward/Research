namespace Tycho.Parser.Peg {
    public interface IProductionMemoKey {}
}