using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    public class RuleParseResult {
        public List<Capture> Captures;
        public int Index { get; private set; }
        public ParseContext Context { get; private set; }

        public RuleParseResult (int index, ParseContext context) {
            Index = index;
            Context = context;

            Captures = new List<Capture> ();
        }

        public void MergeCapturesFrom (RuleParseResult result) {
            Captures.InsertRange (0, result.Captures);
        }

        public void AddCapture (string name, ITerm term) {
            Captures.Add (new Capture (name, term));
        }
    }
}