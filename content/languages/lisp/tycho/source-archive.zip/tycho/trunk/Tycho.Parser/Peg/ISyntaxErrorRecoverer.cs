using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    public interface ISyntaxErrorRecoverer {
        SyntaxErrorRecoveryException Recover (char [] source, int index, ParseContext context, string sourceString, ParseEnvironment environment, IProduction production);
        void AddRecoveryPoint (IProduction recoveryPoint);
        void PushRecoveryPoint (RecoveryPoint recoveryPoint);
        void PopRecoveryPoint ();
        void BeginRecovery ();
        IEnumerable<RecoveryPoint> CurrentRecoveryPoints { get; }
        bool Recovering { get; }
    }
}