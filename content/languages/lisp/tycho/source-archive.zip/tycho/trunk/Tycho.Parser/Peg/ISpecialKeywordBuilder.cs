namespace Tycho.Parser.Peg {
    public interface ISpecialKeywordBuilder {
        IProduction Build (string keyword);
    }
}