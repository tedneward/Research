namespace Tycho.Parser.Peg {
    internal class KeywordTerm : Term {
        public string Name;

        public KeywordTerm (string name, SourceInformation sourceInformation) : base (sourceInformation) {
            Name = name;
        }

        public override string ToString()
        {
            return Name;
        }
    }
}