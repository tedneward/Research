namespace Tycho.Parser.Peg {
    public interface IVirtualProductionContext {
        object VirtualProduction { get; }
    }
}