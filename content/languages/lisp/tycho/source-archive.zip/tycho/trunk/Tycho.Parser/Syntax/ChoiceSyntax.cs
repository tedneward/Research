using System;
using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Parser.Syntax {
    public class ChoiceSyntax : Syntax {
        public Syntax[] Syntaxes;

        public ChoiceSyntax (params Syntax[] syntaxes) {
            Syntaxes = syntaxes;
        }

        public override Production Compile (ProductionLookup productionLookup) {
            throw new System.NotImplementedException ();
        }

        public override void AccumulateCaptures (ICaptureAccumulator accumulator) {
            foreach (var s in Syntaxes) {
                s.AccumulateCaptures (accumulator);
            }
        }
    }
}