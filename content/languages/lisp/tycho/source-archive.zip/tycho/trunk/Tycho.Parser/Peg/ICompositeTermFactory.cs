namespace Tycho.Parser.Peg {
    public interface ICompositeTermFactory {
        CompositeTerm CreateCompositeTerm (string name, SourceInformation sinfo);
        CompositeTerm CreateInfixCompositeTerm (string name, IPrecedence precedence, string first, string last, SourceInformation sinfo);
    }
}