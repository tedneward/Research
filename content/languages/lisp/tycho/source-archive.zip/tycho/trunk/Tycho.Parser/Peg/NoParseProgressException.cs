using System;
namespace Tycho.Parser.Peg {
    public class NoParseProgressException : Exception {}
}