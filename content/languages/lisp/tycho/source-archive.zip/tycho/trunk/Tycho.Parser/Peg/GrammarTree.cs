using System;
using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    public class GrammarTree {
        public IProduction Production { get; set; }
        public Dictionary<string, GrammarTree> SubGrammars { get; set; }

        public GrammarTree (IProduction production) : this (production, new Dictionary<string, GrammarTree> ()) {}

        public GrammarTree (IProduction production, Dictionary<string, GrammarTree> subGrammars) {
            Production = production;
            SubGrammars = subGrammars;
        }

        public GrammarTreeInsertionPoint FindInsertionPoint (string [] grammarPath) {
            GrammarTree parent = this;
            GrammarTree addressed = null;

            foreach (var component in grammarPath) {
                if (addressed != null) {
                    parent = addressed;
                }

                addressed = parent.SubGrammars[component];
            }

            return new GrammarTreeInsertionPoint (parent.Production, addressed.Production);
        }
    }
}