using System;

namespace Tycho.Parser.Peg {
    public interface IMemoClearer {
        void ClearMemoFor (int index, char [] source);
    }
}