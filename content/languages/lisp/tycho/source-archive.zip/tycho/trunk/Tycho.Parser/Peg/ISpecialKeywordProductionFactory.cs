using System;

namespace Tycho.Parser.Peg {
    public interface ISpecialKeywordProductionFactory {
        IProduction CreateBeginBlock ();
        IProduction CreateEndBlock ();
        IProduction CreateStatementDelimiter ();
        IProduction CreateIdentifierKeyword (string keyword);
        IProduction CreateOperatorKeyword (string keyword);
        IProduction CreatePunctuation (string keyword);
        IProduction CreateDecrementingPunctuation (string keyword);
        IProduction CreateIncrementingPunctuation (string keyword);
    }
}