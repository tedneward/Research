using System;

namespace Tycho.Parser.Peg {
    public class RuleProduction : Production {
        public RuleProduction (IRule rule) {
            Rule = rule;
        }

        public IRule Rule { get; private set; }

        protected override ParseResult ReallyParse (char[] source, int index, ParseContext context, string sourceString, ParseEnvironment parseEnvironment) {
            var ruleResult = Rule.Parse (source, index, context, sourceString, parseEnvironment);

            if (ruleResult != null) {
                return new ParseResult (ruleResult.Index, null, ruleResult.Context);
            } else {
                return null;
            }
        }
    }
}