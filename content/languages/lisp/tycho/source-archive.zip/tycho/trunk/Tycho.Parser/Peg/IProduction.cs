using System;
using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    public interface IProduction {
        string Name { get; set; }
        bool IsIncludedInErrors { get; }
        IErrorInformation ErrorInformation { get; }
        Dictionary<int, ParseResult> MemoTable { get; }
        Dictionary<int, ParseResult> GetMemoTable (char[] source);
        bool IsInfix { get; }
        bool IsLeftRecursive { get; }
        IInfixInformation InfixInformation { get; }

        ParseResult Parse (char[] source, int index, ParseContext context, string sourceString, ParseEnvironment parseEnvironment);
        Yield Parse(char[] source, int index, ParseContext context, string sourceString, ParseEnvironment parseEnvironment, Func<ParseResult, Yield> continuation);
    }
}