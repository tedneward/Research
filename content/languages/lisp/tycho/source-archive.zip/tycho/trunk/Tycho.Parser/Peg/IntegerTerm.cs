namespace Tycho.Parser.Peg {
    public class IntegerTerm : Term {
        public int Value;

        public IntegerTerm (int value, SourceInformation sourceInformation) : base (sourceInformation) {
            Value = value;
        }

        public override string ToString()
        {
            return Value.ToString();
        }
    }
}