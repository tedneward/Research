namespace Tycho.Parser.Syntax {
    class MultipleCaptureAccumulator : ICaptureAccumulator {
        private readonly ICaptureAccumulator Accumulator;

        public MultipleCaptureAccumulator (ICaptureAccumulator accumulator) {
            Accumulator = accumulator;
        }

        public void Add (string name) {
            Accumulator.Add (name, true);
        }

        public void Add (string name, bool isMultiple) {
            Accumulator.Add (name, true);
        }
    }
}