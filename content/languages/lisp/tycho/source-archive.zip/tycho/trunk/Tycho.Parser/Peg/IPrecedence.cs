namespace Tycho.Parser.Peg {
    public interface IPrecedence {
        bool IsGreaterThan (IPrecedence precedence);
    }
}