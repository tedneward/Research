using System;

namespace Tycho.Parser.Peg {
    public interface IAssociationSwapper {
        CompositeTerm Swap (CompositeTerm outer);
    }
}