using System;
using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Parser.Syntax {
    public class KeywordSyntax : Syntax {
        public string Keyword;

        public KeywordSyntax (string keyword) {
            Keyword = keyword;
        }

        public override Production Compile (ProductionLookup productionLookup) {
            throw new System.NotImplementedException ();
        }

        public override void AccumulateCaptures (ICaptureAccumulator accumulator) {
        }
    }
}