using System;
using Tycho.Parser.Peg;

namespace Tycho.Parser.Syntax {
    public class SequenceSyntax : Syntax {
        public Syntax[] Syntaxes;

        public SequenceSyntax (params Syntax[] syntaxes) {
            Syntaxes = syntaxes;
        }

        public override Production Compile (ProductionLookup productionLookup) {
            foreach (var s in Syntaxes) {
                s.Compile (productionLookup);
            }

            return null;
        }

        public override void AccumulateCaptures (ICaptureAccumulator accumulator) {
            foreach (var s in Syntaxes) {
                s.AccumulateCaptures (accumulator);
            }
        }
    }
}