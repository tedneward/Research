using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    class MemoClearer : IMemoClearer {
        public IEnumerable<IProduction> Productions;

        public MemoClearer () : this (null) {}

        public MemoClearer (IEnumerable<IProduction> productions) {
            Productions = productions;
        }

        public void ClearMemoFor (int index, char [] source) {
            foreach (var production in Productions) {
                production.GetMemoTable (source).Remove (index);
            }
        }
    }
}