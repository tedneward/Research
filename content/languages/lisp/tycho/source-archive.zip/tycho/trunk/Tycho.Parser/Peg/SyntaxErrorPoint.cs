using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    public class SyntaxErrorPoint {
        public int Index;
        public IEnumerable<RecoveryPoint> RecoveryPoints;

        public SyntaxErrorPoint (int index, IEnumerable<RecoveryPoint> recoveryPoints) {
            Index = index;
            RecoveryPoints = recoveryPoints;
        }
    }
}