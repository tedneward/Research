namespace Tycho.Parser.Peg {
    public interface IParseContext {
        object VirtualProduction { get; }
    }
}