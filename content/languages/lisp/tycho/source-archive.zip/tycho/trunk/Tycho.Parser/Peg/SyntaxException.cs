using System;
using System.Collections.Generic;
using System.Text;

namespace Tycho.Parser.Peg {
    public class SyntaxException : Exception {
        public IEnumerable<SyntaxError> SyntaxErrors;
        public ITerm Term;

        public SyntaxException (ITerm term, IEnumerable<SyntaxError> syntaxErrors) : base (BuildMessage (syntaxErrors)) {
            Term = term;
            SyntaxErrors = syntaxErrors;
        }

        private static string BuildMessage(IEnumerable<SyntaxError> syntaxErrors)
        {
            var str = new StringBuilder();

            str.AppendLine ("syntax errors were found");

            foreach (var error in syntaxErrors) {
                str.AppendLine (error.ToString ());
            }

            return str.ToString ();
        }
    }
}