using System;

namespace Tycho.Parser.Peg {
    public class NamedListRuleAlreadySetException : Exception {
        public readonly string Name;

        public NamedListRuleAlreadySetException (string name)
            : base ("named rule `" + name + "' already set and not a list in results") {
            Name = name;
        }
    }
}