namespace Tycho.Parser.Peg {
    class EndOfFileErrorInformation : IErrorInformation {
        public override string ToString()
        {
            return "end-of-file";
        }
    }
}