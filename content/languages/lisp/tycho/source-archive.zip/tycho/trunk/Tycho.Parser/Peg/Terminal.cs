using System;

namespace Tycho.Parser.Peg {
    public class Terminal : Production {
        public IProduction TerminalProduction { get; private set; }

        public Terminal (IProduction terminalProduction) {
            TerminalProduction = terminalProduction;
            Name = TerminalProduction.Name;
        }

        /*
        protected override ParseResult ReallyParse (char[] source, int index, ParseContext context, string sourceString, ParseEnvironment parseEnvironment) {
            index = Whitespace.SkipWhitespace (source, index);

            if (index < source.Length) {
                return TerminalProduction.Parse (source, index, context, sourceString, parseEnvironment);
            } else {
                return null;
            }
        }
        */

        protected override Yield ReallyParse (char[] source, int index, ParseContext context, string sourceString, ParseEnvironment parseEnvironment, Func<ParseResult, Yield> continuation) {
            index = Whitespace.SkipWhitespace (source, index);

            if (index < source.Length) {
                return TerminalProduction.Parse(source, index, context, sourceString, parseEnvironment, continuation);
            } else {
                return () => continuation(null);
            }
        }
    }
}