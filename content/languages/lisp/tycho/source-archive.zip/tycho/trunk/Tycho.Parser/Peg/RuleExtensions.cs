namespace Tycho.Parser.Peg {
    public static class RuleExtensions {
        public static RuleParseResult Parse (this IRule rule, string source, int index, ParseContext context) {
            return rule.Parse (source.ToCharArray (), index, context, source, new ParseEnvironment (null));
        }
    }
}