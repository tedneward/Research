namespace Tycho.Parser.Peg {
    public class AssociationSwapper : IAssociationSwapper {
        private readonly string First;
        private readonly string Last;

        public AssociationSwapper (string first, string last) {
            First = first;
            Last = last;
        }

        public CompositeTerm Swap (CompositeTerm outer) {
            ITerm inner = outer.SubTerms[Last];
            if (inner is CompositeTerm) {
                var compositeInner = inner as CompositeTerm;

                if (compositeInner.Name == outer.Name) {
                    ITerm toSwap = compositeInner.SubTerms[First];
                    outer.SubTerms[Last] = toSwap;
                    compositeInner.SubTerms[First] = outer;

                    SourceInformation sinfoToSwap = compositeInner.SourceInformation;
                    compositeInner.SourceInformation = outer.SourceInformation;
                    outer.SourceInformation = sinfoToSwap;

                    return compositeInner;
                }
            }

            return outer;
        }
    }
}