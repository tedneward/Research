namespace Tycho.Parser.Peg {
    class ParseEnvironmentFactory : IParseEnvironmentFactory {
        public ParseEnvironment CreateWithFilename (string filename) {
            return new ParseEnvironment (filename);
        }
    }
}