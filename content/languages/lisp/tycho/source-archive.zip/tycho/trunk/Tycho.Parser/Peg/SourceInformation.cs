namespace Tycho.Parser.Peg {
    public class SourceInformation {
        public string FileName;
        public int Index;
        public int Length;

        public SourceInformation (string fileName, int index, int length) {
            FileName = fileName;
            Index = index;
            Length = length;
        }

        public override bool Equals(object obj)
        {
            var sinfo = obj as SourceInformation;
            if (sinfo != null) {
                return FileName == sinfo.FileName
                       && Index == sinfo.Index
                       && Length == sinfo.Length;
            } else {
                return false;
            }
        }

        public override string ToString () {
            return "sloc [" + Index + ", " + Length + "]";
        }
    }
}