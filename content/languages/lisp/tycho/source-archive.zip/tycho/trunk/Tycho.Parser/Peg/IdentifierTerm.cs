namespace Tycho.Parser.Peg {
    public class IdentifierTerm : Term {
        public string Name;

        public IdentifierTerm (string name, SourceInformation sourceInformation) : base (sourceInformation) {
            Name = name;
        }

        public override string ToString()
        {
            return "'" + Name + "'";
        }
    }
}