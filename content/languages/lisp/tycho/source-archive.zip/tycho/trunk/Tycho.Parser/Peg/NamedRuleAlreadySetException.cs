using System;

namespace Tycho.Parser.Peg {
    public class NamedRuleAlreadySetException : Exception {
        public readonly string Name;

        public NamedRuleAlreadySetException (string name)
            : base ("named rule `" + name + "' already set in results") {
            Name = name;
        }
    }
}