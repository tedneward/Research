namespace Tycho.Parser.Peg {
    public class RecoveredSyntaxError {
        public int Index;
        public RecoveryPoint RecoveryPoint;

        public RecoveredSyntaxError (int index, RecoveryPoint recoveryPoint) {
            Index = index;
            RecoveryPoint = recoveryPoint;
        }
    }
}