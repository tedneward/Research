namespace Tycho.Parser.Peg {
    class ParseContextFactory : IParseContextFactory {
        public ParseContext CreateWithDynamicGrammar (IDynamicGrammar dynamicGrammar) {
            return new ParseContext (dynamicGrammar);
        }
    }
}