using System;

namespace Tycho.Parser.Peg {
    class InfixCompositeTerm : CompositeTerm {
        public readonly string FirstName;
        public readonly string LastName;

        public InfixCompositeTerm (string name, IPrecedence precedence, string first, string last, SourceInformation sourceInformation) : base (name, sourceInformation) {
            FirstName = first;
            LastName = last;
            Precedence = precedence;
        }

        public ITerm First {
            get {
                return SubTerms[FirstName];
            }
            set {
                SubTerms[FirstName] = value;
            }
        }

        public ITerm Last {
            get {
                return SubTerms[LastName];
            }
            set {
                SubTerms[LastName] = value;
            }
        }

        public IPrecedence Precedence { get; private set; }
    }
}