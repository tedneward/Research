namespace Tycho.Parser.Peg {
    public class ErrorTerm : Term {
        public readonly IProduction Production;

        public ErrorTerm (IProduction production, SourceInformation sourceInformation) : base (sourceInformation) {
            Production = production;
        }

        public override string ToString()
        {
            return "error";
        }
    }
}