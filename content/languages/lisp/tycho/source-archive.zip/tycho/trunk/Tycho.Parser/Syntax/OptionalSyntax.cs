using System;
using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Parser.Syntax {
    public class OptionalSyntax : Syntax {
        public Syntax Syntax;

        public OptionalSyntax (Syntax syntax) {
            Syntax = syntax;
        }

        public override Production Compile (ProductionLookup productionLookup) {
            bool initialIsFirst = productionLookup.IsFirst;
            var production = Syntax.Compile (productionLookup);
            productionLookup.IsFirst = initialIsFirst;
            return production;
        }

        public override void AccumulateCaptures (ICaptureAccumulator accumulator) {
            Syntax.AccumulateCaptures (accumulator);
        }
    }
}