using System;
using System.Collections.Generic;
using System.Linq;

namespace Tycho.Parser.Peg {
    public class ListTerm : Term {
        public List<ITerm> Terms;

        public ListTerm (SourceInformation sourceInformation) : base (sourceInformation) {
            Terms = new List<ITerm> ();
        }

        public override string ToString()
        {
            return "[" + String.Join (", ", Terms.Select (t => t.ToString ()).ToArray ()) + "]";
        }
    }
}