using System;
using System.Collections;
using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    public class ImmutableStack<T> : IEnumerable<T> {
        private ImmutableStackNode<T> CurrentNode;

        public ImmutableStack () {
            CurrentNode = new ImmutableStackNode<T> ();
        }

        public bool IsEmpty {
            get { return CurrentNode.IsEmpty; }
        }

        public IEnumerable<T> CurrentItems {
            get { return CurrentNode; }
        }

        public IEnumerator<T> GetEnumerator () {
            return CurrentNode.GetEnumerator ();
        }

        IEnumerator IEnumerable.GetEnumerator () {
            return GetEnumerator ();
        }

        public void Push (T item) {
            CurrentNode = CurrentNode.Push (item);
        }

        public T Pop () {
            T item = CurrentNode.Item;
            CurrentNode = CurrentNode.Pop ();
            return item;
        }
    }
}