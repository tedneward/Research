using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    public interface IDynamicGrammar {
        IDynamicGrammar Clone ();
        IEnumerable<IProduction> GetChoices (object key);
        void AddDynamicChoice (object key, IEnumerable<IProduction> choices);
        void InsertChoiceBefore (object key, IProduction beforeProduction, IProduction toInsert);
        void InsertChoiceAfter (object key, IProduction afterProduction, IProduction toInsert);
        bool HasDynamicChoice (object key);
        void InsertChoiceFirst (object key, IProduction toInsert);
        void InsertChoiceLast (object key, IProduction toInsert);
    }
}