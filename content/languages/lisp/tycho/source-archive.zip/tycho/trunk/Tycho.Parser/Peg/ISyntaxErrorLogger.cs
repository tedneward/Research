using System;
using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    public interface ISyntaxErrorLogger {
        IEnumerable<SyntaxError> SyntaxErrors { get; }
        ParseResult ErrorResult { get; }
        bool HasLoggedErrors { get; }
        void CommitError (ITerm errorTerm);
        void SetErrorInMemoTable (char [] source);
        void LogSyntaxError (int index, IProduction production, ParseContext context, Func<IEnumerable<ProductionInvocation>> getProductionInvocations);
        void BeginRecovery ();
        void AddErrorRecovery (IProduction production, int result, ParseResult parseResult);
    }
}