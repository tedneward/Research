using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    public interface ICompositeTermBuilder {
        IEnumerable<string> Multiples { get; set; }
        void Build (CompositeTerm term, IEnumerable<Capture> captures);
    }
}