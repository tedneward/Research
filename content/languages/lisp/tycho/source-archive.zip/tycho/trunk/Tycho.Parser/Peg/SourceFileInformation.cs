using System;

namespace Tycho.Parser.Peg {
    class SourceFileInformation : ISourceFileInformation {
        public string FileName { get; private set; }

        public SourceFileInformation (string fileName) {
            FileName = fileName;
        }

        public SourceInformation CreateSourceInformation (int index, int length) {
            return new SourceInformation (FileName, index, length);
        }
    }
}