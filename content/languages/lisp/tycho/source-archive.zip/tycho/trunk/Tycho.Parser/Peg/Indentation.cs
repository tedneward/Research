namespace Tycho.Parser.Peg
{
    enum Indentation
    {
        BeginBlock,
        StatementDelimiter,
        EndBlock,
        Error
    }
}