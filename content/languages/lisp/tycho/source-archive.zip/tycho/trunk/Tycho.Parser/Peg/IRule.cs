using System;

namespace Tycho.Parser.Peg {
    public interface IRule {
        RuleParseResult Parse (char[] source, int index, ParseContext context, string sourceString, ParseEnvironment environment);
        Yield Parse(char[] source, int index, ParseContext context, string sourceString, ParseEnvironment environment, Func<RuleParseResult, Yield> continuation);
        bool IsInfix { get; }
        IInfixInformation InfixInformation { get; }
        bool HasProduction { get; }
        IProduction Production { get; set; }
    }
}