namespace Tycho.Parser.Peg {
    class IdentityAssociationSwapper : IAssociationSwapper {
        public CompositeTerm Swap (CompositeTerm outer) {
            return outer;
        }
    }
}