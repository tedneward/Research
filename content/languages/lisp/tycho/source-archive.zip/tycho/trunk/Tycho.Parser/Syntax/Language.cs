namespace Tycho.Parser.Syntax {
    public class Language {
        public string Name;

        public Language (string name) {
            Name = name;
        }
    }
}