namespace Tycho.Parser.Peg {
    public class Capture {
        public string Name;
        public ITerm Term;

        public Capture (string name, ITerm term) {
            Name = name;
            Term = term;
        }
    }
}