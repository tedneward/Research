using System;
using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    class ProductionMemoTable : IProductionMemoTable {
        private readonly Dictionary<IProductionMemoKey, ParseResult> Results;

        struct MemoKey : IProductionMemoKey {
            public IProduction Production;
            public int Index;
        }

        public ProductionMemoTable () {
            Results = new Dictionary<IProductionMemoKey, ParseResult> ();
        }

        public IProductionMemoKey CreateKey (IProduction production, int index) {
            return new MemoKey {
                                   Production = production,
                                   Index = index,
                               };
        }

        public bool TryGetResult (IProductionMemoKey key, out ParseResult result) {
            return Results.TryGetValue (key, out result);
        }

        public void SetResult (IProductionMemoKey key, ParseResult result) {
            Results[key] = result;
        }

        public ParseResult GetResult (IProductionMemoKey key) {
            return Results[key];
        }

        public bool ContainsKey (IProductionMemoKey key) {
            return Results.ContainsKey (key);
        }

        public void ClearResult (IProductionMemoKey key) {
            Results.Remove (key);
        }
    }
}