namespace Tycho.Parser.Peg {
    public class StringTerm : Term {
        public readonly string Value;

        public StringTerm (string value, SourceInformation sourceInformation) : base (sourceInformation) {
            Value = value;
        }

        public override string ToString()
        {
            return "\"" + Value + "\"";
        }
    }
}