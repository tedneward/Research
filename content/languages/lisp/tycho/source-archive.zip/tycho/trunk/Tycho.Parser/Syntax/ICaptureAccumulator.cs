namespace Tycho.Parser.Syntax {
    public interface ICaptureAccumulator {
        void Add (string name);
        void Add (string name, bool isMultiple);
    }
}