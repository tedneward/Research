using System;
using System.Collections.Generic;

namespace Tycho.Parser.Peg {
    public class ParseEnvironment {
        public LeftRecursionInformation LeftRecursionInformation;
        public ISyntaxErrorLogger SyntaxErrors;
        public ISourceFileInformation SourceFileInformation;
        public ISyntaxErrorRecoverer SyntaxErrorRecoverer;

        public ParseEnvironment (string filename) {
            SyntaxErrors = new SyntaxErrorLogger ();
            SyntaxErrorRecoverer = new SyntaxErrorRecoverer (SyntaxErrors);
            SourceFileInformation = new SourceFileInformation (filename);
            LeftRecursionInformation = new LeftRecursionInformation ();
        }

        public ParseEnvironment (string filename, ISyntaxErrorRecoverer syntaxErrorRecoverer) : this (filename) {
            SyntaxErrorRecoverer = syntaxErrorRecoverer;
        }
    }
}