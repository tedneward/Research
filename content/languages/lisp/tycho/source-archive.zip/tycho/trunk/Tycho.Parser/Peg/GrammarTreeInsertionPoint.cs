namespace Tycho.Parser.Peg {
    public class GrammarTreeInsertionPoint {
        public IProduction ParentProduction;
        public IProduction Production;

        public GrammarTreeInsertionPoint (IProduction parentProduction, IProduction production) {
            ParentProduction = parentProduction;
            Production = production;
        }
    }
}