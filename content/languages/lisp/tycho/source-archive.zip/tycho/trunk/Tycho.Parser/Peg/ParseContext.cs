using System;

namespace Tycho.Parser.Peg {
    public class ParseContext {
        public string LastIndent;
        public int BracketDepth;
        public IDynamicGrammar DynamicGrammar;
        public GrammarTree GrammarTree;

        public ParseContext () : this (new LazyDynamicGrammar ()) {}

        public ParseContext (IDynamicGrammar grammar) {
            LastIndent = "";
            BracketDepth = 0;
            DynamicGrammar = grammar;
        }

        public ParseContext Clone () {
            return new ParseContext () {
                                           LastIndent = LastIndent,
                                           BracketDepth = BracketDepth,
                                           DynamicGrammar = DynamicGrammar,
                                           GrammarTree = GrammarTree
                                       };
        }

        public static Func<ParseResult, ParseResult> ContextAction (Action<ParseContext> action) {
            return r => {
                       r.Context = r.Context.Clone ();
                       action (r.Context);
                       return r;
                   };
        }
    }
}