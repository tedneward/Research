using System;
using Tycho.Parser.Peg;

namespace Tycho.Parser.Syntax {
    public abstract class Syntax {
        public abstract Production Compile (ProductionLookup productionLookup);
        public abstract void AccumulateCaptures (ICaptureAccumulator accumulator);
    }
}