using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tycho.Parser.Peg {
    public class SyntaxError {
        public int Index;
        public ITerm Term;
        public IEnumerable<IErrorInformation> ExpectedProductions;

        public override string ToString () {
            var result = new StringBuilder();
            result.Append ("(" + Index + ") expected: ");

            var expectedProductions = ExpectedProductions
                .Select (errorInformation => errorInformation.ToString ())
                .ToArray ();

            result.Append (string.Join (" or ", expectedProductions));

            return result.ToString ();
        }
    }
}