namespace Tycho.Parser.Peg {
    public class MemoisedParseResult {
        public ParseContext Context;
        public ITerm Term;
        public int Index;
    }
}