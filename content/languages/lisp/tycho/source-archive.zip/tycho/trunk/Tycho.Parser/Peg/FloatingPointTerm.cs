namespace Tycho.Parser.Peg {
    public class FloatingPointTerm : Term {
        public readonly double Value;

        public FloatingPointTerm (double value, SourceInformation sourceInformation) : base (sourceInformation) {
            Value = value;
        }
    }
}