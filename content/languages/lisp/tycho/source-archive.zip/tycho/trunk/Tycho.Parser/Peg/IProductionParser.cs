namespace Tycho.Parser.Peg {
    public interface IProductionParser {
        ITerm Parse (string source, string filename);
    }
}