namespace Tycho.Parser.Peg {
    public interface IProductionMemoTable {
        IProductionMemoKey CreateKey (IProduction production, int index);
        bool TryGetResult (IProductionMemoKey key, out ParseResult result);
        void SetResult (IProductionMemoKey key, ParseResult result);
        void ClearResult (IProductionMemoKey key);
        ParseResult GetResult (IProductionMemoKey key);
        bool ContainsKey (IProductionMemoKey key);
    }
}