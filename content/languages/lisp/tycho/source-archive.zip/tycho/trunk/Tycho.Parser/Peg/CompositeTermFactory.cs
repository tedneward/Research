using System;

namespace Tycho.Parser.Peg {
    class CompositeTermFactory : ICompositeTermFactory {
        public CompositeTerm CreateCompositeTerm (string name, SourceInformation sinfo) {
            return new CompositeTerm (name, sinfo);
        }

        public CompositeTerm CreateInfixCompositeTerm (string name, IPrecedence precedence, string first, string last, SourceInformation sinfo) {
            return new InfixCompositeTerm (name, precedence, first, last, sinfo);
        }
    }
}