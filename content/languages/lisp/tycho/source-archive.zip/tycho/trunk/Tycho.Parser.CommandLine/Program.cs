﻿using System;
using System.IO;
using Tycho.Grammar;
using Tycho.Language;
using Tycho.Parser.Peg;

namespace Tycho.Parser.CommandLine
{
    class Program
    {
        private const string SourceFilename = "source.txt";
        private const string GrammarFilename = "grammar.txt";

        static void Main(string[] args)
        {
            try {
                var compiledGrammar = new ParserLoader ().LoadParser (File.ReadAllText (GrammarFilename));

                ParseSource (compiledGrammar);
            } catch (SyntaxException se) {
                PrintSyntaxErrors (GrammarFilename, se);
            }

            Console.ReadKey (true);
        }

        private static void ParseSource (Grammar.IParser compiledGrammar) {
            try {
                ITerm term = compiledGrammar.ParseTerm (File.ReadAllText (SourceFilename));

                Console.WriteLine (term);
            } catch (SyntaxException se) {
                PrintSyntaxErrors (SourceFilename, se);
            }
        }

        private static void PrintSyntaxErrors (string filename, SyntaxException se) {
            foreach (var syntaxError in se.SyntaxErrors) {
                Console.WriteLine (filename + ": " + syntaxError);
            }
        }
    }
}

