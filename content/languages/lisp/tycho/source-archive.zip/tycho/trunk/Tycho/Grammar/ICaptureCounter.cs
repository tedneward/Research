using System.Collections.Generic;

namespace Tycho.Grammar {
    public interface ICaptureCounter {
        void Add (string captureName);
        IEnumerable<string> MultipleCaptures { get; }
        ICaptureCounter CreateMultipleCaptureScope ();
        string FirstCapture { get; }
        string LastCapture { get; }
    }
}