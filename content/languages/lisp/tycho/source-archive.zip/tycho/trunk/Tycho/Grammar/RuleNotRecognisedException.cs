using System;

namespace Tycho.Grammar {
    public class RuleNotRecognisedException : Exception {}
}