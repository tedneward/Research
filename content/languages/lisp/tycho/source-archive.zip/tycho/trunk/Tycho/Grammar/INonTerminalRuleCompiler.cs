using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface INonTerminalRuleCompiler {
        RuleCaptures Compile (ITerm rule, ProductionCompilerContext context);
    }
}