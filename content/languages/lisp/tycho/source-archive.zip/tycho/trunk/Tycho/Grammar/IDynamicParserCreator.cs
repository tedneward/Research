using System;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface IDynamicParserCreator {
        IParser CreateDynamicParser (IDynamicGrammar dynamicGrammar, IProduction production);
    }
}