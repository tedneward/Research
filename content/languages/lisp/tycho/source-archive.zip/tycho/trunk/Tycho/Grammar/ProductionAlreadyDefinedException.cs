using System;

namespace Tycho.Grammar {
    public class ProductionAlreadyDefinedException : Exception {}
}