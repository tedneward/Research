using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface IChoiceAssociativityRewriter {
        IEnumerable<IProduction> RewriteForAssciativity (IEnumerable<IProduction> productions, IProduction baseProduction);
    }
}