using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public static class ParserExtensions {
        public static ITerm ParseTerm (this IParser parser, string source) {
            return parser.ParseTerm (source, null);
        }
    }
}