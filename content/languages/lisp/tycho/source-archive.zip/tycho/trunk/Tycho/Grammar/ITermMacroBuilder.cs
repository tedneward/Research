using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface ITermMacroBuilder {
        ITerm BuildTerm (Dictionary<string, ITerm> namedTerms);
    }
}