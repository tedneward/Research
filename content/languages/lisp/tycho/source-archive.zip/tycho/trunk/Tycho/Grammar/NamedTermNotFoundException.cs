using System;

namespace Tycho.Grammar {
    internal class NamedTermNotFoundException : Exception {
        public NamedTermNotFoundException (string name) : base ("named term `" + name + "' could not be found") {}
    }
}