using Tycho.Runtime;

namespace Tycho.Compiler {
    class TermWrapper {
        public AnyObject Term { get; private set; }

        public TermWrapper (AnyObject term) {
            Term = term;
        }

        public AnyObject this [string name] {
            get { return Term.GetProperty (Namespaces.Parser.Get (name)); }
        }

        public AnyObject this [Symbol name] {
            get { return Term.GetProperty (name); }
        }

        public bool Has (string name) {
            return Has (Namespaces.Parser.Get (name));
        }

        public bool Has (Symbol symbol) {
            return Term.HasProperty (symbol);
        }
    }
}