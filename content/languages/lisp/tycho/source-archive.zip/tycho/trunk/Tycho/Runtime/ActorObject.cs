﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tycho.Runtime {
    class ActorObject : PrototypeObject {
        AnyObject Function;

        public ActorObject (AnyObject prototype, AnyObject aspect) : base (prototype) {
            Function = aspect;
        }

        public override AnyObject InvokeMethod (AnyObject self, AnyObject name, params AnyObject [] arguments) {
            AnyObject [] aspectArgs = new AnyObject [arguments.Length + 2];
            aspectArgs [0] = self;
            aspectArgs [1] = name;
            arguments.CopyTo (aspectArgs, 2);
            return Function.Invoke (aspectArgs);
        }

        public override string ToString () {
            return Function.Invoke (Function, Symbols.RuntimeToString).ExpectValue<string> ();
        }
    }
}
