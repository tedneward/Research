using Tycho.Compiler;
using Tycho.Language;

namespace Tycho.Runtime {
    public class ExpressionModuleCompiler : IModuleCompiler {
        private readonly AnyObject ModuleFrame;

        public ExpressionModuleCompiler (AnyObject moduleFrame) {
            ModuleFrame = moduleFrame;
        }

        public AnyObject CompileModule (string source, string filename, Namespace ns, IModuleScopeLoader moduleLoader) {
            ExpressionLanguage language = new ExpressionLanguage (TopLevel.RuntimeAssemblyModule, ns);

            return language.LoadModule (source, filename, ModuleFrame, moduleLoader);
        }
    }
}