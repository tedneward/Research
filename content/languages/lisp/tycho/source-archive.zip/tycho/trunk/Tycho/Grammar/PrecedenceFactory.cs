using System;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    class PrecedenceFactory : IPrecedenceFactory {
        public IPrecedence Create (IProduction context, int order, IProduction operatorProduction, bool isLeftRecursive) {
            return new Precedence (operatorProduction, order, context);
        }
    }
}