using System.Collections.Generic;
using System.Linq;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    class CompositeTermMacroBuilder : ITermMacroBuilder {
        private readonly string Name;
        private readonly IEnumerable<CompositeTermSubTerm> Fields;
        private readonly SourceInformation SourceInformation;

        public CompositeTermMacroBuilder (string name, IEnumerable<CompositeTermSubTerm> fields, SourceInformation sourceInformation) {
            Name = name;
            Fields = fields;
            SourceInformation = sourceInformation;
        }

        public ITerm BuildTerm (Dictionary<string, ITerm> namedTerms) {
            var term = new CompositeTerm (Name, SourceInformation);

            term.SubTerms = Fields.ToDictionary (c => c.Name, c => c.TermMacroBuilder.BuildTerm (namedTerms));

            return term;
        }
    }
}