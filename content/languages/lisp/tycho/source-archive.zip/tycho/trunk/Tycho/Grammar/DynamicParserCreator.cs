using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    class DynamicParserCreator : IDynamicParserCreator {
        public IParser CreateDynamicParser (IDynamicGrammar dynamicGrammar, IProduction production) {
            return new DynamicParser (dynamicGrammar, production);
        }
    }
}