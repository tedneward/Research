using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface INonTerminalBuilder {
        void Build (string name, NonTerminal nonTerminal, RuleCaptures ruleCaptures);
    }
}