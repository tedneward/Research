﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Tycho.UnitTests")]