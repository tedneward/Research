using Tycho.Runtime;

namespace Tycho.Parser {
    public abstract class TermGenerator {
        public abstract AnyObject BuildTerm (params AnyObject [] arguments);
    }
}