﻿using System.Collections.Generic;
using System.Linq;
using Tycho.Runtime;
using Tycho.Parser.Tokens;

namespace Tycho.Parser {
    public class NodePair {
        public Node First { get; private set; }
        public Node Last { get; private set; }

        public NodePair (Node first, Node last) {
            First = first;
            Last = last;
        }

        public TransitionNode LastTransitionNode {
            get { return (TransitionNode) Last; }
        }

        public TransitionNode FirstTransitionNode {
            get { return (TransitionNode) First; }
        }
    }

    public class ProductionLookup {
        Dictionary<AnyObject, ProductionItem> _productions = new Dictionary<AnyObject, ProductionItem> ();
        int ProductionIndex = 1;

        public int AddProduction (AnyObject name, IParser parser, bool singular, bool subParser, bool isMultiline) {
            ProductionItem production;
            if (_productions.TryGetValue (name, out production)) {
                // now there's more than one of these productions in the pattern, it ain't singular no more.
                production.Singular = false;
                return production.Index;
            } else {
                _productions [name] = new ProductionItem (name, parser, singular, ProductionIndex, subParser, isMultiline);
                return ProductionIndex++;
            }
        }

        public IEnumerable<ProductionItem> Productions {
            get { return _productions.Values; }
        }
    }

    public abstract class Pattern {
        public abstract void AnalyseProductions (bool singular, bool subParser, ProductionLookup productions);

        public abstract bool PatternEquals (Pattern pattern);

        public abstract NodePair CompileNodes ();
    }

    public class ProductionPattern : Pattern {
        public AnyObject Name { get; private set; }
        public IParser Parser { get; set; }
        public bool Greedy { get; set; }
        public bool IsMultiline { get; set; }
        public int Index { get; private set; }

        public ProductionPattern (AnyObject name, IParser parser, bool greedy, bool isMultiline) {
            Name = name;
            Parser = parser;
            Greedy = greedy;
            IsMultiline = isMultiline;
            Index = 0;
        }

        public override void AnalyseProductions (bool singular, bool subParser, ProductionLookup productions) {
            Index = productions.AddProduction (Name, Parser, singular, subParser, IsMultiline);
        }

        public override bool PatternEquals (Pattern obj) {
            if (obj is ProductionPattern) {
                ProductionPattern otherPattern = (ProductionPattern) obj;
                return Index.Equals (otherPattern.Index) && Greedy.Equals (otherPattern.Greedy) && Parser == otherPattern.Parser;
            } else {
                return false;
            }
        }

        public override NodePair CompileNodes () {
            TransitionNode firstNode = new TransitionNode (),
                remainingNode = new TransitionNode(),
                finalNode = new TransitionNode ();

            firstNode.Transitions.Add (new AnyTokenTransition (remainingNode, Index, IsMultiline));

            var repeatTransition = new AnyTokenTransition (remainingNode, Index, IsMultiline);
            var completeTransition = new FreeTransition (finalNode);

            if (Greedy) {
                remainingNode.Transitions.Add (repeatTransition);
                remainingNode.Transitions.Add (completeTransition);
            } else {
                remainingNode.Transitions.Add (completeTransition);
                remainingNode.Transitions.Add (repeatTransition);
            }

            return new NodePair (firstNode, finalNode);
        }
    }

    internal class FinishPattern : Pattern {
        public Production Production { get; private set; }
        bool SingleToken;

        public FinishPattern (Production production, bool singleToken) {
            Production = production;
            SingleToken = singleToken;
        }

        public override bool PatternEquals (Pattern pattern) {
            return false;
        }

        public override void AnalyseProductions (bool singular, bool subParser, ProductionLookup productions) { }

        public override NodePair CompileNodes () {
            TransitionNode startNode = new TransitionNode ();
            FinishNode finishNode = new FinishNode (Production, SingleToken);

            startNode.Transitions.Add (new FinishTransition (finishNode));

            return new NodePair (startNode, finishNode);
        }
    }

    public class KeywordPattern : Pattern {
        public string Keyword { get; private set; }

        public KeywordPattern (string keyword) {
            Keyword = keyword;
        }

        public override bool PatternEquals (Pattern pattern) {
            return pattern is KeywordPattern && Keyword.Equals (((KeywordPattern) pattern).Keyword);
        }

        public override void AnalyseProductions (bool singular, bool subParser, ProductionLookup productions) { }

        public override NodePair CompileNodes () {
            TransitionNode startNode = new TransitionNode (),
                endNode = new TransitionNode ();

            startNode.Transitions.Add (new KeywordTransition (endNode, Keyword));

            return new NodePair (startNode, endNode);
        }
    }

    public class DualKeywordPattern : KeywordPattern {
        public string OtherKeyword { get; private set; }

        public DualKeywordPattern (string keyword, string otherKeyword)
            : base (keyword) {
            OtherKeyword = otherKeyword;
        }

        public override bool PatternEquals (Pattern pattern) {
            return pattern is DualKeywordPattern && Keyword.Equals (((DualKeywordPattern) pattern).Keyword) && OtherKeyword.Equals (((DualKeywordPattern) pattern).OtherKeyword);
        }

        public override NodePair CompileNodes () {
            TransitionNode startNode = new TransitionNode (),
                endNode = new TransitionNode ();

            startNode.Transitions.Add (new KeywordTransition (endNode, Keyword));
            startNode.Transitions.Add (new KeywordTransition (endNode, OtherKeyword));

            return new NodePair (startNode, endNode);
        }
    }

    public class PlusPattern : KleenePattern {
        public PlusPattern (Pattern pattern, bool greedy) : base (pattern, greedy) { }

        public override bool PatternEquals (Pattern obj) {
            if (obj is PlusPattern) {
                return base.PatternEquals (obj);
            } else {
                return false;
            }
        }

        public override NodePair CompileNodes () {
            NodePair patternNodes = Pattern.CompileNodes ();
            NodePair kleeneNodes = base.CompileNodes ();

            patternNodes.LastTransitionNode.Transitions.Add (new FreeTransition (kleeneNodes.First));

            return new NodePair (patternNodes.First, kleeneNodes.Last);
        }
    }

    public class KleenePattern : Pattern {
        protected Pattern Pattern { get; set; }
        bool Greedy { get; set; }

        public KleenePattern (Pattern pattern, bool greedy) {
            Pattern = pattern;
            Greedy = greedy;
        }

        public override bool PatternEquals (Pattern obj) {
            if (obj is PlusPattern) {
                PlusPattern otherPattern = (PlusPattern) obj;
                return Pattern.PatternEquals (otherPattern.Pattern);
            } else {
                return false;
            }
        }

        public override void AnalyseProductions (bool singular, bool subParser, ProductionLookup productions) {
            Pattern.AnalyseProductions (false, subParser, productions);
        }

        public override NodePair CompileNodes () {
            TransitionNode finalNode = new TransitionNode ();

            NodePair patternNodes = Pattern.CompileNodes ();

            if (Greedy) {
                patternNodes.LastTransitionNode.Transitions.Add (new FreeTransition (patternNodes.First));
                patternNodes.LastTransitionNode.Transitions.Add (new FreeTransition (finalNode));
            } else {
                patternNodes.LastTransitionNode.Transitions.Add (new FreeTransition (finalNode));
                patternNodes.LastTransitionNode.Transitions.Add (new FreeTransition (patternNodes.First));
            }

            return new NodePair (patternNodes.First, finalNode);
        }
    }

    public class OnePattern : Pattern {
        public AnyObject Name { get; private set; }
        public IParser Parser { get; private set; }
        public int Index { get; private set; }

        public OnePattern (AnyObject name, IParser parser) {
            Name = name;
            Parser = parser;
            Index = 0;
        }

        public override bool PatternEquals (Pattern obj) {
            return obj is OnePattern && Name.Equals (((OnePattern) obj).Name);
        }

        public override void AnalyseProductions (bool singular, bool subParser, ProductionLookup productions) {
            Index = productions.AddProduction (Name, Parser, singular, subParser, false);
        }

        public override NodePair CompileNodes () {
            TransitionNode firstNode = new TransitionNode (), lastNode = new TransitionNode ();

            firstNode.Transitions.Add (new AnyTokenTransition (lastNode, Index, false));

            return new NodePair (firstNode, lastNode);
        }
    }

    public class BracketPattern : Pattern {
        BracketType BracketType { get; set; }
        Pattern Pattern { get; set; }

        public BracketPattern (Pattern pattern, BracketType type) {
            Pattern = pattern;
            BracketType = type;
        }

        public override bool PatternEquals (Pattern obj) {
            return obj is BracketPattern && BracketType == ((BracketPattern) obj).BracketType && Pattern.PatternEquals(((BracketPattern) obj).Pattern);
        }

        public override void AnalyseProductions (bool singular, bool subParser, ProductionLookup productions) {
            Pattern.AnalyseProductions (singular, true, productions);
        }

        public override NodePair CompileNodes () {
            TransitionNode first = new TransitionNode (), last = new TransitionNode ();

            NodePair subNodes = Pattern.CompileNodes ();
            subNodes.LastTransitionNode.Transitions.Add (new SubFinishTransition ());
            first.Transitions.Add (new BracketTransition (last, subNodes.First, BracketType));

            return new NodePair (first, last);
        }
    }

    public class DelimitedPattern : Pattern {
        Pattern Pattern { get; set; }
        Pattern Delimiter { get; set; }

        public DelimitedPattern (Pattern pattern, Pattern delimiter) {
            Pattern = pattern;
            Delimiter = delimiter;
        }

        public override bool PatternEquals (Pattern obj) {
            return obj is DelimitedPattern
                && Pattern.PatternEquals (((DelimitedPattern) obj).Pattern)
                && Delimiter.PatternEquals (((DelimitedPattern) obj).Delimiter);
        }

        public override void AnalyseProductions (bool singular, bool subParser, ProductionLookup productions) {
            Pattern.AnalyseProductions (false, subParser, productions);
        }

        public override NodePair CompileNodes () {
            TransitionNode startNode = new TransitionNode ();
            NodePair patternNodes = Pattern.CompileNodes ();
            NodePair delimiterNodes = Delimiter.CompileNodes ();
            TransitionNode finalNode = new TransitionNode ();

            startNode.Transitions.Add (new FreeTransition (patternNodes.First));
            patternNodes.LastTransitionNode.Transitions.Add (new FreeTransition (delimiterNodes.First));
            delimiterNodes.LastTransitionNode.Transitions.Add (new FreeTransition (patternNodes.First));

            // match optional trailing delimiter, eg: "a, b, c," ignores the last ","
            delimiterNodes.LastTransitionNode.Transitions.Add (new FreeTransition (finalNode));

            patternNodes.LastTransitionNode.Transitions.Add (new FreeTransition (finalNode));

            // for matching nothing
            startNode.Transitions.Add (new FreeTransition (finalNode));

            return new NodePair (startNode, finalNode);
        }
    }

    public class OptionalPattern : Pattern {
        Pattern Pattern { get; set; }

        public OptionalPattern (Pattern pattern) {
            Pattern = pattern;
        }

        public override bool PatternEquals (Pattern obj) {
            return obj is OptionalPattern && Pattern.PatternEquals(((OptionalPattern) obj).Pattern);
        }

        public override void AnalyseProductions (bool singular, bool subParser, ProductionLookup productions) {
            Pattern.AnalyseProductions (singular, subParser, productions);
        }

        public override NodePair CompileNodes () {
            TransitionNode startNode = new TransitionNode (), endNode = new TransitionNode ();

            NodePair patternNodes = Pattern.CompileNodes ();
            startNode.Transitions.Add (new FreeTransition (patternNodes.First));
            startNode.Transitions.Add (new FreeTransition (endNode));
            patternNodes.LastTransitionNode.Transitions.Add (new FreeTransition (endNode));

            return new NodePair (startNode, endNode);
        }
    }

    public class AlternativePattern : Pattern {
        public List<Pattern> Alternatives { get; set; }

        public AlternativePattern () {
            Alternatives = new List<Pattern> ();
        }

        public override bool PatternEquals (Pattern obj) {
            return false;
        }

        public override void AnalyseProductions (bool singular, bool subParser, ProductionLookup productions) {
            foreach (Pattern pattern in Alternatives) {
                pattern.AnalyseProductions (singular, subParser, productions);
            }
        }

        public override NodePair CompileNodes () {
            TransitionNode startNode = new TransitionNode (), endNode = new TransitionNode ();

            foreach (Pattern pattern in Alternatives) {
                NodePair patternNodes = pattern.CompileNodes ();
                startNode.Transitions.Add (new FreeTransition (patternNodes.First));
                patternNodes.LastTransitionNode.Transitions.Add (new FreeTransition (endNode));
            }

            return new NodePair (startNode, endNode);
        }
    }

    public class SequencePattern : Pattern {
        private Pattern[] Patterns;

        public SequencePattern (Pattern[] patterns) {
            Patterns = patterns;
        }

        public override void AnalyseProductions (bool singular, bool subParser, ProductionLookup productions) {
            foreach (var pattern in Patterns) {
                pattern.AnalyseProductions (singular, subParser, productions);
            }
        }

        internal static bool AllPatternsEqual (Pattern [] patterns, Pattern [] otherPatterns) {
            if (patterns.Length == otherPatterns.Length) {
                for (int n = 0; n < patterns.Length; n++) {
                    if (!patterns [n].PatternEquals (otherPatterns [n])) {
                        return false;
                    }
                }

                return true;
            }

            return false;
        }

        public override bool PatternEquals (Pattern pattern) {
            if (pattern is SequencePattern) {
                return AllPatternsEqual (Patterns, ((SequencePattern) pattern).Patterns);
            } else {
                return false;
            }
        }

        public override NodePair CompileNodes () {
            return CompileSequence (Patterns);
        }

        protected NodePair CompileSequence (IEnumerable<Pattern> patterns) {
            if (patterns.Count () > 0) {
                Node first = null;
                Node last = null;

                foreach (var p in patterns) {
                    NodePair nodes = p.CompileNodes ();

                    if (first == null) {
                        first = nodes.First;
                    }

                    if (last != null) {
                        ((TransitionNode) last).Transitions.Add (new FreeTransition (nodes.First));
                    }

                    last = nodes.Last;
                }

                return new NodePair (first, last);
            } else {
                TransitionNode node = new TransitionNode ();
                return new NodePair (node, node);
            }
        }
    }
}
