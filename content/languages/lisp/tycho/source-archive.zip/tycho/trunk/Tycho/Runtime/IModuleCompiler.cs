using Tycho.Compiler;

namespace Tycho.Runtime {
    public interface IModuleCompiler {
        AnyObject CompileModule (string source, string filename, Namespace ns, IModuleScopeLoader moduleLoader);
    }
}