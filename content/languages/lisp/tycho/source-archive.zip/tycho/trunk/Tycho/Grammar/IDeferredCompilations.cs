using System;

namespace Tycho.Grammar {
    public interface IDeferredCompilations {
        void AddCompilationStep (object objectRequiringStep, Action deferredCompilationStep);
        void RunCompilationSteps ();
        void RunStepForObject (object objectRequiringStep);
    }
}