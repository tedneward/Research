using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public class IdentifierProductionCompilerEvaluator : IProductionCompilerEnvironment {
        private readonly IProduction DefaultProduction;
        private readonly Dictionary<string, IProduction> Productions;

        public IdentifierProductionCompilerEvaluator (IProduction defaultProduction) {
            DefaultProduction = defaultProduction;
            Productions = new Dictionary<string, IProduction> ();
        }

        public IProduction Default {
            get { return DefaultProduction; }
        }

        public IProduction EvaluateQuote (ITerm productionTerm) {
            var identifier = productionTerm as IdentifierTerm;

            if (identifier != null) {
                IProduction production;
                if (Productions.TryGetValue (identifier.Name, out production)) {
                    return production;
                }
            }

            throw new NoSuchProductionException (productionTerm);
        }

        public void Add (string name, IProduction production) {
            Productions.Add (name, production);
        }
    }
}