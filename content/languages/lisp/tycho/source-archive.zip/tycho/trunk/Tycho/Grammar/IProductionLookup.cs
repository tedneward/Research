using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface IProductionLookup {
        IProduction Lookup (string name);
        bool Contains (string name);
    }
}