using Tycho.Parser.Peg;
using Tycho.Parser.Tokens;

namespace Tycho.Grammar {
    public class SourceInformationTranslator {
        public SourceLocation ToSourceLocation (SourceInformation sinfo) {
            return new SourceLocation (null, sinfo.FileName, -1, -1, sinfo.Index + 1, sinfo.Index + sinfo.Length);
        }
    }
}