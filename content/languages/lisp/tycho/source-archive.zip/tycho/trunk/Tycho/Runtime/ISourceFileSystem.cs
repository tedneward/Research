namespace Tycho.Runtime {
    public interface ISourceFileSystem {
        string LoadSourceFile (string filename);
    }
}