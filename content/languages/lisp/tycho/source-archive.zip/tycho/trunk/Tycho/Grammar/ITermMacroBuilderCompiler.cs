using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface ITermMacroBuilderCompiler {
        ITermMacroBuilder Compile (ITerm term);
    }
}