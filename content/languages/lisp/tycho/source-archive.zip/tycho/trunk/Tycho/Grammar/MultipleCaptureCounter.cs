using System;
using System.Collections.Generic;

namespace Tycho.Grammar {
    class MultipleCaptureCounter : ICaptureCounter {
        private readonly HashSet<string> Captures;
        private readonly Action<string> SetFirstAndLast;

        public MultipleCaptureCounter (HashSet<string> captures, Action<string> setFirstAndLast) {
            Captures = captures;
            SetFirstAndLast = setFirstAndLast;
        }

        public void Add (string captureName) {
            SetFirstAndLast (captureName);
            Captures.Add (captureName);
        }

        public IEnumerable<string> MultipleCaptures {
            get { return Captures; }
        }

        public ICaptureCounter CreateMultipleCaptureScope () {
            return this;
        }

        public string FirstCapture {
            get { throw new NotImplementedException (); }
        }

        public string LastCapture {
            get { throw new NotImplementedException (); }
        }
    }
}