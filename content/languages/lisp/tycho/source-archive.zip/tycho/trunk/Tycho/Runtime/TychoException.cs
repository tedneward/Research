﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tycho.Runtime {
    public class TychoException : Exception {
        public AnyObject Body { get; private set; }

        public TychoException (string message) : base (message) {
            Body = BuildBody (message);
        }

        public TychoException (string message, Exception innerException)
            : base (message, innerException) {
            Body = BuildBody (message);
        }

        public TychoException (AnyObject body, Exception innerException)
            : base (body.ToString (), innerException) {
            Body = body;
        }

        public TychoException (AnyObject body)
            : base (body.ToString ()) {
            Body = body;
        }

        private static AnyObject BuildBody (string message) {
            return RuntimeModule.CreateStructure (Symbols.RuntimeDescription, message);
        }

        public static TychoException NoSuchMethod (AnyObject name) {
            return new TychoException ("no such method " + name);
        }

        public static TychoException NoSuchProperty (AnyObject name) {
            return new NoSuchPropertyException (name);
        }

        public static TychoException InvalidArguments () {
            return new TychoException ("invalid arguments");
        }

        public static TychoException NoMatchingMethod (AnyObject self, AnyObject name, params AnyObject [] arguments) {
            return new NoMatchingMethodException (self, name, arguments);
        }

        public static TychoException NoSuchCaseForDispatch (AnyObject value) {
            return new NoSuchCaseForDispatchException (value);
        }

        public static TychoException NoSuchVariable (AnyObject name) {
            return new TychoException ("variable " + name + " not found");
        }

        public static TychoException ReadOnlyProperty (AnyObject name) {
            return new TychoException ("property " + name + " is readonly");
        }

        public static TychoException AssignmentMatchFailed (AnyObject pattern, AnyObject result) {
            return new TychoException ("right hand side of assignment " + result + " failed to match left hand side " + pattern);
        }

        public static TychoException MemberAlreadyDefined (AnyObject memberName) {
            return new MemberAlreadyDefinedException (memberName);
        }

        public static TychoException NoMatchingMethodInMultimethod (AnyObject [] arguments) {
            return new NoMatchingMethodInMultimethodException (arguments);
        }
    }

    public class ExitException : TychoException {
        public ExitException () : base ("exit") { }
    }

    public class NoSuchPropertyException : TychoException {
        public NoSuchPropertyException (AnyObject name)
            : base ("no such property " + name) {
        }
    }

    public class NoMatchingMethodException : TychoException {
        public NoMatchingMethodException (AnyObject self, AnyObject name, AnyObject [] arguments)
            : base (ConstructMessage (self, name, arguments)) {
        }

        private static string ConstructMessage (AnyObject self, AnyObject name, AnyObject [] arguments) {
            string argumentsString = "(" + String.Join (", ", arguments.Select (a => a != null ? a.ToString () : "null").ToArray ()) + ")";
            return "no such method " + name + " for " + self + " that can match the arguments " + argumentsString;
        }
    }

    public class NoSuchCaseForDispatchException : TychoException {
        public NoSuchCaseForDispatchException (AnyObject value)
            : base (ConstructMessage (value)) {
        }

        private static string ConstructMessage (AnyObject value) {
            return "no such case for dispatch to match value: " + value;
        }
    }

    public class MemberAlreadyDefinedException : TychoException {
        public MemberAlreadyDefinedException (AnyObject memberName) : base (String.Format ("member `{0}' already defined", memberName)) {
        }
    }

    public class NoMatchingMethodInMultimethodException : TychoException {
        public AnyObject [] Arguments { get; private set; }

        public NoMatchingMethodInMultimethodException (AnyObject [] arguments)
            : base ("no matching method for arguments: " + String.Join (", ", arguments.Select (a => a.ToString ()).ToArray ())) {
            Arguments = arguments;
        }
    }
}
