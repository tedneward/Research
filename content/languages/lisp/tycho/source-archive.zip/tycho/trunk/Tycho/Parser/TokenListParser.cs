﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tycho.Compiler;
using Tycho.Parser.Tokens;
using Tycho.Runtime;

namespace Tycho.Parser {
    public class TokenListParser : IParser {
        public string Name {
            get {
                return "tokens";
            }
        }

        public IParser ExtendParser () {
            return this;
        }

        public AnyObject Parse (List<List<Token>> tokensList, bool parseMultiline) {
            return CompilerModule.CreateTermList (from tokens in tokensList select Parse (tokens, parseMultiline));
        }

        public AnyObject Parse (List<Token> tokens, bool parseMultiline) {
            return new NativeObject<List<Token>> (tokens);
        }
    }
}
