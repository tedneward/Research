using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface IProductionCompilerEnvironment {
        IProduction Default { get; }
        IProduction EvaluateQuote (ITerm productionTerm);
    }
}