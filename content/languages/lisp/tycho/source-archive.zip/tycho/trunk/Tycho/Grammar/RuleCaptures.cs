using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public struct RuleCaptures {
        public IRule Rule;
        public IEnumerable<string> MultipleCaptures;
        public string FirstCapture;
        public string LastCapture;
    }
}