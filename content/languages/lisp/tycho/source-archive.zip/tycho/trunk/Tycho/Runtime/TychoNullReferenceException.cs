﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tycho.Runtime {
    public class TychoNullReferenceException : TychoException {
        public TychoNullReferenceException () : base ("null pointer exception") { }
    }
}
