namespace Tycho.Grammar {
    public struct CompositeTermSubTerm {
        public string Name;
        public ITermMacroBuilder TermMacroBuilder;

        public CompositeTermSubTerm (string name, ITermMacroBuilder termMacroBuilder) {
            Name = name;
            TermMacroBuilder = termMacroBuilder;
        }
    }
}