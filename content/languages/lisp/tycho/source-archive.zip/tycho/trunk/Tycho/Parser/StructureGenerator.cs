using System.Collections.Generic;
using Tycho.Compiler;
using Tycho.Parser.Tokens;
using Tycho.Runtime;

namespace Tycho.Parser {
    class StructureGenerator : TermGenerator {
        public class Field {
            public AnyObject Name;
            public TermGenerator Value;
        }

        public List<Field> Fields;
        SourceLocation SourceLocation;

        public StructureGenerator (SourceLocation sourceLocation) {
            Fields = new List<Field> ();
            SourceLocation = sourceLocation;
        }

        public override AnyObject BuildTerm (params AnyObject [] arguments) {
            AnyObject term = CompilerModule.CreateTerm (SourceLocation);

            foreach (Field field in Fields) {
                term.SetProperty (field.Name, field.Value.BuildTerm (arguments));
            }

            return term;
        }
    }
}