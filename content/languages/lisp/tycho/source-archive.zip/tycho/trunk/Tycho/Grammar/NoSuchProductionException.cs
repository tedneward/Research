using System;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public class NoSuchProductionException : Exception {
        private readonly object Key;

        public NoSuchProductionException (object key) {
            Key = key;
        }

        public override string ToString() {
            return Key.ToString ();
        }
    }
}