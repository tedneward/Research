﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tycho.Utilities;
using System.IO;

namespace Tycho.Runtime {
    public class RuntimeFunctions {
        [TychoModuleLoad]
        static void ModuleLoad (AnyObject module) {
            module [Symbols.RuntimeObject] = RuntimeModule.Object;
            module [Symbols.RuntimeClosure] = RuntimeModule.Closure;
            module [Symbols.RuntimeStructure] = RuntimeModule.Structure;
            module [Symbols.RuntimeList] = RuntimeModule.List;
            module [Symbols.RuntimeSet] = RuntimeModule.Set;
            module [Symbols.RuntimeDictionary] = RuntimeModule.Dictionary;
            module [Symbols.RuntimeTrue] = RuntimeModule.CreateBoolean (true);
            module [Symbols.RuntimeFalse] = RuntimeModule.CreateBoolean (false);
            module [Symbols.RuntimeNull] = RuntimeModule.Null;
            module [Symbols.RuntimeSymbol] = RuntimeModule.Symbol;
            module [Symbols.RuntimeModule] = RuntimeModule.Module;
            module [Symbols.RuntimeStackFrame] = RuntimeModule.StackFrame;
            module [Symbols.RuntimeModuleFrame] = RuntimeModule.ModuleFrame;
            module [Symbols.RuntimeDynamicStackFrame] = RuntimeModule.DynamicStackFrame;
            module [Symbols.RuntimeMultimethod] = RuntimeModule.Multimethod;

            module [Symbols.RuntimeIf] = new NativeFunction (IfSchema, If);
        }

        static AnyObject IfSchema = new ParametersSchemaObject (2, RuntimeModule.Boolean, RuntimeModule.Closure, RuntimeModule.Closure);
        static AnyObject If (params AnyObject [] arguments) {
            bool condition = arguments [0].ExpectValue<bool> ();

            if (condition) {
                AnyObject thenBlock = arguments [1];
                return thenBlock.Invoke ();
            } else if (arguments.Length >= 3) {
                AnyObject elseBlock = arguments [2];
                return elseBlock.Invoke ();
            } else {
                return RuntimeModule.Null;
            }
        }

        [TychoFunction2 ("while")]
        public static AnyObject While (AnyObject condBlock, AnyObject doBlock) {
            AnyObject lastValue = RuntimeModule.Null;

            while (condBlock.Invoke ().ExpectValue<bool> ()) {
                lastValue = doBlock.Invoke ();
            }

            return lastValue;
        }

        [TychoFunctionSchema ("dispatch")]
        public static AnyObject DispatchSchema = new AnySchemaObject ();
        [TychoFunction ("dispatch")]
        public static AnyObject Dispatch (params AnyObject [] arguments) {
            Multimethod m = new Multimethod ();

            for (int n = 1; n < arguments.Length; n++) {
                m.Methods.Add (arguments [n]);
            }

            Func<AnyObject> method;
            if ((method = m.DispatchMethod (arguments [0])) != null) {
                return method ();
            } else {
                throw TychoException.NoSuchCaseForDispatch (arguments[0]);
            }
        }

        [TychoFunctionSchema ("create-multimethod")]
        public static AnyObject CreateMultimethodSchema = new AnySchemaObject ();
        [TychoFunction ("create-multimethod")]
        public static AnyObject CreateMultimethod (params AnyObject [] arguments) {
            return new MultiMethodObject (RuntimeModule.Multimethod, arguments);
        }

        [TychoFunctionSchema ("print")]
        public static AnyObject PrintSchema = new AnySchemaObject ();
        [TychoFunction ("print")]
        public static AnyObject Print (params AnyObject[] arguments) {
            TextWriter writer = ThreadContext.Current.GetProperty (Symbols.RuntimePrintStream).ExpectNative<TextWriter> ();
            writer.WriteLine (String.Join(", ", arguments.Select (a => a.ToString()).ToArray ()));
            return RuntimeModule.Null;
        }

        [TychoFunction2 ("compile")]
        public static AnyObject Compile (string sourceCode, AnyObject contextStackFrame) {
            return RuntimeModule.CompileExpression (sourceCode, contextStackFrame);
        }

        [TychoFunction2 ("exit")]
        public static AnyObject Exit () {
            throw new ExitException ();
        }

        [TychoFunction2 ("sleep")]
        public static AnyObject Sleep (int milliseconds) {
            System.Threading.Thread.Sleep (milliseconds);

            return RuntimeModule.Null;
        }

        [TychoFunction2 ("match-assignment")]
        public static AnyObject MatchAssignment (AnyObject pattern, AnyObject results, AnyObject value) {
            if (pattern.Match (results, value)) {
                return value;
            } else {
                throw TychoException.AssignmentMatchFailed (pattern, value);
            }
        }

        [TychoFunctionSchema ("concatenate-to-string")]
        public static AnyObject ConcatenateToStringSchema = new AnySchemaObject ();
        [TychoFunction ("concatenate-to-string")]
        public static AnyObject ConcatenateToString (params AnyObject [] arguments) {
            var result = new StringBuilder ();

            foreach (AnyObject arg in arguments) {
                StringObject str;
                if (arg.TryCastTo (out str)) {
                    result.Append (str.Value);
                } else {
                    result.Append (arg);
                }
            }

            return result.ToString ();
        }

        [TychoFunction2("new-protocol")]
        public static AnyObject NewProtocol () {
            return RuntimeModule.CreateProtocol ();
        }

        [TychoFunction2 ("create-actor")]
        public static AnyObject CreateActor (AnyObject function) {
            return new ActorObject (RuntimeModule.Object, function);
        }

        [TychoFunction2 ("with")]
        public static AnyObject With (AnyObject disposableObject, AnyObject block) {
            using (disposableObject) {
                return block.Invoke ();
            }
        }

        [TychoFunction2 ("try")]
        public static AnyObject Try (AnyObject block, AnyObject exceptionHandler, AnyObject finallyBlock) {
            try {
                return block.Invoke ();
            } catch (Exception e) {
                Func<AnyObject> handler;
                if ((handler = exceptionHandler.DispatchMethod (exceptionHandler, Symbols.RuntimeInvoke, TranslateException (e))) != null) {
                    return handler ();
                }
                throw;
            } finally {
                if (!finallyBlock.IsNull) {
                    finallyBlock.Invoke ();
                }
            }
        }

        static AnyObject TranslateException (Exception e) {
            if (e is TychoException) {
                return ((TychoException) e).Body;
            } else {
                return RuntimeModule.ConvertToRuntime (e);
            }
        }

        [TychoFunction2 ("create-object")]
        public static AnyObject CreateObject () {
            return RuntimeModule.CreatePrototype ();
        }

        [TychoFunction2 ("throw")]
        public static AnyObject Throw (AnyObject arg) {
            throw new TychoException (arg);
        }
    }
}
