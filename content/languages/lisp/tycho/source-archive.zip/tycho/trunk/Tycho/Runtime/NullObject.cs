﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tycho.Runtime {
    public class NullObject : SimpleObject {
        public override bool IsNull { get { return true; } }

        public override AnyObject InvokeMethod (AnyObject self, AnyObject name, params AnyObject [] arguments) {
            if (name == Symbols.RuntimeEquals) {
                return self.Equals (arguments[0]);
            } else {
                throw new TychoNullReferenceException ();
            }
        }

        public override string ToString (HashSet<AnyObject> done) {
            return "null";
        }

        public override AnyObject Serialize () {
            return this;
        }

        public override AnyObject ActuallySerialize () {
            return this;
        }

        public override bool Equals (object obj) {
            if (obj is AnyObject) {
                return ((AnyObject) obj).IsNull;
            } else {
                return false;
            }
        }
    }
}
