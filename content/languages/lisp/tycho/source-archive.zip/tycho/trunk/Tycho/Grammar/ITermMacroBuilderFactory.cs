using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface ITermMacroBuilderFactory {
        ITermMacroBuilder BuildNamedTermMacroBuilder (string name);
        ITermMacroBuilder BuildListTermMacroBuilder (IEnumerable<ITermMacroBuilder> terms, SourceInformation sourceInformation);
        ITermMacroBuilder BuildCompositeTermMacroBuilder (string name, IEnumerable<CompositeTermSubTerm> subTerms, SourceInformation sourceInformation);
        ITermMacroBuilder BuildConstantTermMacroBuilder (ITerm term);
    }
}