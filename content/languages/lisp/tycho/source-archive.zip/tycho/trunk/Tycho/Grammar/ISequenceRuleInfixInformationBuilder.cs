using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface ISequenceRuleInfixInformationBuilder {
        void Add (IRule rule);
        IInfixInformation CreateInfixInformation ();
    }
}