using Tycho.Runtime;

namespace Tycho.Parser {
    class ConstantGenerator : TermGenerator {
        AnyObject Value;

        public ConstantGenerator (AnyObject value) {
            Value = value;
        }

        public override AnyObject BuildTerm (params AnyObject [] arguments) {
            return Value;
        }
    }
}