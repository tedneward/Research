using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface IProductionCompiler {
        GrammarTree Compile (ITerm term, ChoicePrecedence precedence, ProductionCompilerContext context);
    }
}