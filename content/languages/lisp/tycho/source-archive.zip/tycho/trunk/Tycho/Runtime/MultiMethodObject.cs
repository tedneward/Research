using Tycho.Utilities;

namespace Tycho.Runtime {
    public class MultiMethodObject : InstanceObject {
        private Multimethod Multimethod;

        public MultiMethodObject (AnyObject prototype, params AnyObject[] methods) : base (prototype) {
            Multimethod = new Multimethod ();

            foreach (var method in methods) {
                Multimethod.Methods.Add (method);
            }
        }

        public override System.Func<AnyObject> DispatchMethod (AnyObject self, AnyObject name, params AnyObject [] arguments) {
            if (name == Symbols.RuntimeInvoke) {
                return Multimethod.DispatchMethod (arguments);
            } else {
                return base.DispatchMethod (self, name, arguments);
            }
        }

        public override AnyObject Invoke (params AnyObject [] arguments) {
            return Multimethod.Invoke (arguments);
        }

        [TychoMethodSchema ("multimethod", "invoke")]
        static AnyObject PrototypeInvokeSchema = new AnySchemaObject ();
        [TychoMethod ("multimethod", "invoke")]
        public static AnyObject PrototypeInvoke (AnyObject self, params AnyObject [] arguments) {
            return self.Invoke (arguments);
        }
    }
}