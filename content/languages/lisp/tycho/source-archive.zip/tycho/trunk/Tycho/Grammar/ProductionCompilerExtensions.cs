using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public static class ProductionCompilerExtensions {
        public static GrammarTree Compile (this IProductionCompiler compiler, ITerm term, IProductionCompilerEnvironment environment, IProductionLookup lookup, IDynamicGrammar grammar) {
            var compilations = new DeferredCompilations ();
            GrammarTree grammarTree = compiler.Compile (term, null, new ProductionCompilerContext (environment, lookup, grammar, compilations));
            compilations.RunCompilationSteps ();
            return grammarTree;
        }

        public static IProduction CompileProduction (this IProductionCompiler compiler, ITerm term, IProductionCompilerEnvironment environment) {
            return compiler.Compile (term, environment, new ProductionLookup (), new LazyDynamicGrammar ()).Production;
        }

        public static IProduction CompileProduction (this IProductionCompiler compiler, ITerm term, IProductionCompilerEnvironment environment, IProductionLookup lookup) {
            return compiler.Compile (term, environment, lookup, new LazyDynamicGrammar ()).Production;
        }
    }
}