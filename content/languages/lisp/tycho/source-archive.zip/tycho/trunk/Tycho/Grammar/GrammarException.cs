using System;

namespace Tycho.Grammar {
    internal class GrammarException : Exception {}
}