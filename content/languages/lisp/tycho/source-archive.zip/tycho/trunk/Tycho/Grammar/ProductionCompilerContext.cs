using System;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public class ProductionCompilerContext {
        public IProductionCompilerEnvironment Environment;
        public IProductionLookup Lookup;
        public IDynamicGrammar Grammar;
        public IDeferredCompilations DeferredCompilations;

        public ProductionCompilerContext (IProductionCompilerEnvironment environment, IProductionLookup lookup, IDynamicGrammar grammar, IDeferredCompilations deferredCompilations) {
            Environment = environment;
            Lookup = lookup;
            Grammar = grammar;
            DeferredCompilations = deferredCompilations;
        }

        public ProductionCompilerContext Clone () {
            return new ProductionCompilerContext (Environment, Lookup, Grammar, DeferredCompilations);
        }
    }
}