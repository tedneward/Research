using System;

namespace Tycho.Grammar {
    public class TermMacroBuilderCompilerException : Exception {
        public TermMacroBuilderCompilerException (string message) : base (message) {}
    }
}