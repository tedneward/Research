using Tycho.Parser.Peg;

namespace Tycho.Language {
    public interface IGrammarParser {
        ITerm LoadGrammarTerms (string source);
    }
}