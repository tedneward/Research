﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tycho.Runtime {
    class Slot {
    }

    class MethodSlot : Slot {
        Multimethod multimethod;

        public MethodSlot () {
            multimethod = new Multimethod ();
        }

        public List<AnyObject> Methods {
            get {
                return multimethod.Methods;
            }
        }

        public Func<AnyObject> DispatchMethod (params AnyObject [] arguments) {
            return multimethod.DispatchMethod (arguments);
        }
    }

    class FieldSlot : Slot {
        public AnyObject Value { get; set; }

        public FieldSlot (AnyObject value) {
            Value = value;
        }
    }

    class PropertySlot : Slot {
        public AnyObject Getter { get; set; }
        public AnyObject Setter { get; set; }

        public AnyObject GetValue (AnyObject self) {
            return Getter.Invoke (self);
        }

        public void SetValue (AnyObject self, AnyObject value) {
            Setter.Invoke (self, value);
        }
    }
}
