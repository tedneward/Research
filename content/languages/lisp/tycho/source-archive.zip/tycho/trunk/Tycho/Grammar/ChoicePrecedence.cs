using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public class ChoicePrecedence {
        public readonly IProduction Context;
        public readonly int Order;

        public ChoicePrecedence (IProduction context, int order) {
            Context = context;
            Order = order;
        }
    }
}