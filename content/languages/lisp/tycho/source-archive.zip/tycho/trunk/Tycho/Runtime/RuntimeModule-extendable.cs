﻿using System;
using System.Collections.Generic;

namespace Tycho.Runtime {
    public class RuntimeModule {
        static RuntimeModule () {
            Current = new DefaultRuntimeModule();
        }

        public static void Initialise () {
            // already set current runtime module to the default
        }

        public static void Initialise (IRuntimeModule runtimeModule) {
            Current = runtimeModule;
        }

        public static IRuntimeModule Current { get; set; }

        public static AnyObject Integer { get { return Current.Integer; } }
        public static AnyObject Real { get { return Current.Real; } }
        public static AnyObject Boolean { get { return Current.Boolean; } }
        public static AnyObject String { get { return Current.String; } }
        public static AnyObject DateTime { get { return Current.DateTime; } }
        public static AnyObject Operation { get { return Current.Operation; } }
        public static AnyObject Closure { get { return Current.Closure; } }
        public static AnyObject Module { get { return Current.Module; } }
        public static AnyObject ModuleFrame { get { return Current.ModuleFrame; } }
        public static AnyObject Dictionary { get { return Current.Dictionary; } }
        public static AnyObject StackFrame { get { return Current.StackFrame; } }
        public static AnyObject DynamicStackFrame { get { return Current.DynamicStackFrame; } }
        public static AnyObject List { get { return Current.List; } }
        public static AnyObject Set { get { return Current.Set; } }
        public static AnyObject Structure { get { return Current.Structure; } }
        public static AnyObject Object { get { return Current.Object; } }
        public static AnyObject Symbol { get { return Current.Symbol; } }
        public static AnyObject Constructor { get { return Current.Constructor; } }
        public static AnyObject Null { get { return Current.Null; } }

        public static AnyObject CreateInteger (int n) {
            return Current.CreateInteger (n);
        }

        public static AnyObject CreateString (string s) {
            return Current.CreateString (s);
        }

        public static AnyObject CreateBoolean (bool b) {
            return Current.CreateBoolean (b);
        }

        public static AnyObject CreateReal (double d) {
            return Current.CreateReal (d);
        }

        public static AnyObject CreateDateTime (DateTime d) {
            return Current.CreateDateTime (d);
        }

        public static AnyObject CreateStructure (params AnyObject [] fields) {
            return Current.CreateStructure (fields);
        }

        public static AnyObject CreateSet (IEnumerable<AnyObject> items) {
            return Current.CreateSet (items);
        }

        public static AnyObject CreateSet (params AnyObject [] items) {
            return Current.CreateSet (items);
        }

        public static AnyObject CreateList (IEnumerable<AnyObject> items) {
            return Current.CreateList (items);
        }

        public static AnyObject CreateList (params AnyObject [] items) {
            return Current.CreateList (items);
        }

        public static AnyObject CreateDictionary (params AnyObject [] entries) {
            return Current.CreateDictionary (entries);
        }

        public static AnyObject CreateModule (Namespace ns) {
            return Current.CreateModule (ns);
        }

        public static AnyObject CreatePrototype () {
            return Current.CreatePrototype ();
        }

        public static AnyObject CreatePrototype (AnyObject prototype) {
            return Current.CreatePrototype (prototype);
        }

        public static AnyObject CreateNative<T> (T native) {
            return Current.CreateNative<T>(native);
        }

        public static AnyObject CreateProtocol () {
            return Current.CreateProtocol ();
        }
    }
}
