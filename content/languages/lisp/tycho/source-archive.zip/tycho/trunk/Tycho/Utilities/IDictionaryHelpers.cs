using System;
using System.Collections.Generic;

namespace Tycho.Utilities {
    public static class IDictionaryHelpers {
        public static Value GetValueOrInitialise<Key, Value> (this IDictionary<Key, Value> dict, Key key, Func<Value> init) {
            Value value;
            if (!dict.TryGetValue (key, out value)) {
                dict [key] = value = init ();
            }
            return value;
        }
    }
}