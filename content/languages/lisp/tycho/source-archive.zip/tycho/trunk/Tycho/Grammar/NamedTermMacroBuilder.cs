using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    class NamedTermMacroBuilder : ITermMacroBuilder {
        private readonly string Name;

        public NamedTermMacroBuilder (string name) {
            Name = name;
        }

        public ITerm BuildTerm (Dictionary<string, ITerm> namedTerms) {
            ITerm term;
            if (namedTerms.TryGetValue (Name, out term)) {
                return term;
            } else {
                throw new NamedTermNotFoundException (Name);
            }
        }
    }
}