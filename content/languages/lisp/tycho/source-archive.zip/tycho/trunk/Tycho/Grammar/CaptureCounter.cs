using System;
using System.Collections.Generic;

namespace Tycho.Grammar {
    public class CaptureCounter : ICaptureCounter {
        private readonly HashSet<string> CountedCaptures;
        private readonly HashSet<string> MultipleCountedCaptures;

        public CaptureCounter () {
            CountedCaptures = new HashSet<string> ();
            MultipleCountedCaptures = new HashSet<string> ();
        }

        public void Add (string captureName) {
            SetFirstAndLast (captureName);

            if (!CountedCaptures.Add (captureName)) {
                MultipleCountedCaptures.Add (captureName);
            }
        }

        private void SetFirstAndLast (string captureName) {
            if (FirstCapture == null) {
                FirstCapture = captureName;
            }
            LastCapture = captureName;
        }

        public IEnumerable<string> MultipleCaptures {
            get { return MultipleCountedCaptures; }
        }

        public ICaptureCounter CreateMultipleCaptureScope () {
            return new MultipleCaptureCounter (MultipleCountedCaptures, SetFirstAndLast);
        }

        public string FirstCapture { get; private set; }
        public string LastCapture { get; private set; }
    }
}