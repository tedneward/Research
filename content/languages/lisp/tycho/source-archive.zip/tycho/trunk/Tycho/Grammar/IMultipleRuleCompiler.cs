using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    internal interface IMultipleRuleCompiler {
        IRule Compile (int minimum, int maximum, ITerm term, ProductionCompilerContext context, ICaptureCounter captureCounter);
    }
}