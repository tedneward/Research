using Tycho.Runtime;

namespace Tycho.Parser {
    class MacroOperation : NativeOperation {
        TermGenerator TermGenerator;

        public MacroOperation (TermGenerator termGenerator)
            : base (new AnySchemaObject ()) {
            TermGenerator = termGenerator;
        }

        public override AnyObject InvokeWithoutSchema (params AnyObject [] arguments) {
            return TermGenerator.BuildTerm (arguments);
        }
    }
}