using System;
using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    class ConstantTermMacroBuilder : ITermMacroBuilder {
        private readonly ITerm Term;

        public ConstantTermMacroBuilder (ITerm term) {
            Term = term;
        }

        public ITerm BuildTerm (Dictionary<string, ITerm> namedTerms) {
            return Term;
        }
    }
}