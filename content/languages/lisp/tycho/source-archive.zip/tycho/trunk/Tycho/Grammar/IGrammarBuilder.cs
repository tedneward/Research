using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface IGrammarBuilder {
        IProduction Production { get; }
    }
}