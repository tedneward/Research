using Tycho.Parser.Peg;
using Tycho.Runtime;

namespace Tycho.Grammar {
    public interface ITermTranslator {
        AnyObject Translate (ITerm term);
    }
}