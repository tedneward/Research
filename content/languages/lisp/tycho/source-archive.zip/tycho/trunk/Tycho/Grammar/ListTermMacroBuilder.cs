using System;
using System.Collections.Generic;
using System.Linq;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    class ListTermMacroBuilder : ITermMacroBuilder {
        private readonly IEnumerable<ITermMacroBuilder> Terms;
        private readonly SourceInformation SourceInformation;

        public ListTermMacroBuilder (IEnumerable<ITermMacroBuilder> terms, SourceInformation sourceInformation) {
            Terms = terms;
            SourceInformation = sourceInformation;
        }

        public ITerm BuildTerm (Dictionary<string, ITerm> namedTerms) {
            var listTerm = new ListTerm (SourceInformation);
            listTerm.Terms = Terms.Select (t => t.BuildTerm (namedTerms)).ToList ();
            return listTerm;
        }
    }
}