using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface IParser {
        ITerm ParseTerm (string source, string filename);
    }
}