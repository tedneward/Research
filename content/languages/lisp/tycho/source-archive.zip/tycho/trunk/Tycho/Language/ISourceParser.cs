using Tycho.Runtime;

namespace Tycho.Language {
    public interface ISourceParser {
        AnyObject Parse (string expression, string filename);
    }
}