﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;
using Tycho.Utilities;
using Tycho.Language;

namespace Tycho.Runtime {
    public class TopLevel : ITopLevel {
        AnyObject StackFrame;
        public ExpressionLanguage ExpressionLanguage { get; private set; }
        public ModuleManifest ModuleManifest { get; private set; }
        private static AnyObject CachedRuntimeAssemblyModule;
        public ModuleFrameObject ModuleFrame { get; private set; }
        public Namespace DefaultNamespace;

        public static AnyObject RuntimeAssemblyModule {
            get {
                if (CachedRuntimeAssemblyModule == null) {
                    CachedRuntimeAssemblyModule = AssemblyModuleLoader.LoadAssembly (Namespaces.Runtime, typeof (TopLevel).Assembly);
                }
                return CachedRuntimeAssemblyModule;
            }
        }

        public TopLevel (Namespace defaultNamespace, AnyObject stackFrame) {
            DefaultNamespace = defaultNamespace;
            ModuleFrame = new ModuleFrameObject (RuntimeModule.ModuleFrame);

            ModuleManifest = new ModuleManifest (ModuleFrame);
            ModuleManifest.ModuleLoaders.Add (Namespaces.Runtime, new ImmediateModuleLoader (RuntimeAssemblyModule));

            ModuleSecurityObject moduleAccess = new ModuleSecurityObject (defaultNamespace, ModuleFrame);
            if (stackFrame != null) {
                StackFrame = stackFrame;
                StackFrame.OuterScope = moduleAccess;
            } else {
                StackFrame = new StackFrameObject (RuntimeModule.StackFrame, moduleAccess);
            }

            ExpressionLanguage = new ExpressionLanguage (moduleAccess, defaultNamespace);
        }

        public TopLevel (Namespace defaultNamespace) : this (defaultNamespace, null) { }

        public TopLevel () : this (Namespaces.User) { }

        public AnyObject Evaluate (string source) {
            return Evaluate (source, null);
        }

        public AnyObject this [AnyObject name] {
            get { return StackFrame [name]; }
            set { StackFrame [name] = value; }
        }

        public AnyObject Evaluate (string source, string fileName) {
            return Compile (source, fileName).Invoke ();
        }

        private AnyObject Compile (string source, string fileName) {
            return Compile (source, fileName, StackFrame);
        }

        public AnyObject Compile (string source, string filename, AnyObject stackFrame) {
            return ExpressionLanguage.CompileOperation (source, null, stackFrame, new NonRecursiveModuleLoader (Namespaces.Parser, new NonRecursiveModuleLoader (DefaultNamespace, ModuleManifest), true));
        }
        
        public AnyObject EvaluateFile (string fileName) {
            return Evaluate (File.ReadAllText (fileName), fileName);
        }

        public void AddModule (Namespace ns, IModuleLoader moduleLoader) {
            ModuleManifest.ModuleLoaders.Add (ns, moduleLoader);
        }
    }
}
