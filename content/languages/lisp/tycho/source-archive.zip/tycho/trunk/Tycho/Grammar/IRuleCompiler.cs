using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public interface IRuleCompiler {
        IRule Compile (
            ITerm term,
            ProductionCompilerContext context,
            ICaptureCounter captureCounter);
    }
}