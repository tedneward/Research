﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Tycho.Compiler;
using Tycho.Parser.Tokens;
using Tycho.Runtime;

namespace Tycho.Parser {
    public static class Terms {
        public static AnyObject FromReal (double r, SourceLocation sloc) {
            AnyObject str = CompilerModule.CreateTerm (sloc);
            str.SetProperty (Symbols.ParserTermName, Symbols.ParserReal);
            str.SetProperty (Symbols.ParserReal, CompilerModule.CreateReal (r));
            return str;
        }

        public static AnyObject FromInteger (int i, SourceLocation sloc) {
            AnyObject str = CompilerModule.CreateTerm (sloc);
            str.SetProperty (Symbols.ParserTermName, Symbols.ParserInteger);
            str.SetProperty (Symbols.ParserInteger, CompilerModule.CreateInteger (i));
            return str;
        }

        public static AnyObject FromString (string s, SourceLocation sloc) {
            AnyObject str = CompilerModule.CreateTerm (sloc);
            str.SetProperty (Symbols.ParserTermName, Symbols.ParserString);
            str.SetProperty (Symbols.ParserString, CompilerModule.CreateString (s));
            return str;
        }

        public static AnyObject FromIdentifier (string id, SourceLocation sloc) {
            return FromIdentifier (id, null, sloc);
        }

        public static AnyObject FromIdentifier (string id, List<string> modulePath, SourceLocation sloc) {
            AnyObject str = CompilerModule.CreateTerm (sloc);
            str.SetProperty (Symbols.ParserTermName, Symbols.ParserIdentifier);
            str.SetProperty (Symbols.ParserIdentifier, CompilerModule.CreateString (id));

            if (modulePath != null) {
                str.SetProperty (Symbols.ParserModule, CompilerModule.CreateTermList (modulePath.Select ((name) => (AnyObject) CompilerModule.CreateString (name))));
            }

            return str;
        }

        public static AnyObject FromSymbol (Symbol s, SourceLocation sloc) {
            List<string> modulePath = new List<string> ();

            Namespace n = s.Namespace;
            while (n != Namespaces.Root) {
                modulePath.Insert (0, n.Name);
                n = n.Parent;
            }

            return FromIdentifier (s.Name, modulePath, sloc);
        }

        public static AnyObject FromError (string errorMessage, SourceLocation sloc) {
            AnyObject str = CompilerModule.CreateTerm (sloc);
            str.SetProperty (Symbols.ParserTermName, Symbols.ParserError);
            str.SetProperty (Symbols.ParserError, RuntimeModule.CreateString (errorMessage));
            return str;
        }

        public static AnyObject FromInterpolatedString (IEnumerable<AnyObject> tokens, SourceLocation sloc) {
            AnyObject str = CompilerModule.CreateTerm (sloc);
            str.SetProperty (Symbols.ParserTermName, Symbols.ParserInterpolatedString);
            str.SetProperty (Symbols.ParserValues, CompilerModule.CreateList (tokens));
            return str;
        }

        public static AnyObject ToTerm (this SourceLocation sloc) {
            AnyObject term = RuntimeModule.CreateStructure ();

            if (sloc.FileName != null) {
                term.SetProperty (Symbols.ParserFileName, CompilerModule.CreateString (sloc.FileName));
            }

            term.SetProperty (Symbols.ParserSourceCode, CompilerModule.CreateString (sloc.Source));

            term.SetProperty (Symbols.ParserLineStart, CompilerModule.CreateInteger (sloc.LineStart));
            term.SetProperty (Symbols.ParserLineEnd, CompilerModule.CreateInteger (sloc.LineEnd));
            term.SetProperty (Symbols.ParserColumnStart, CompilerModule.CreateInteger (sloc.ColumnStart));
            term.SetProperty (Symbols.ParserColumnEnd, CompilerModule.CreateInteger (sloc.ColumnEnd));

            return term;
        }

        public static SourceLocation ToSourceLocation (this AnyObject obj) {
            return new SourceLocation (
                obj.GetProperty (Symbols.ParserSourceCode).ExpectValue<string> (),
                obj.HasProperty (Symbols.ParserFileName)? obj.GetProperty (obj, Symbols.ParserFileName).ExpectValue<string> (): null,
                obj.GetProperty (Symbols.ParserLineStart).ExpectValue<int> (),
                obj.GetProperty (Symbols.ParserLineEnd).ExpectValue<int> (),
                obj.GetProperty (Symbols.ParserColumnStart).ExpectValue<int> (),
                obj.GetProperty (Symbols.ParserColumnEnd).ExpectValue<int> ());
        }

        public static string PrettyPrint (this AnyObject term) {
            TextWriter writer = new StringWriter ();
            term.PrettyPrint (writer);
            return writer.ToString ();
        }

        public static void PrettyPrint (this AnyObject term, TextWriter writer) {
            PrettyPrint (term, writer, 0);
        }

        public static void PrettyPrint (this AnyObject term, TextWriter writer, int indent) {
            if (term is ListObject) {
                PrettyPrintList (term as ListObject, writer, indent);
            } else if (term is StructureObject) {
                PrettyPrintStructure (term as StructureObject, writer, indent);
            } else if (term is Symbol) {
                var fieldSymbol = term as Symbol;
                if (fieldSymbol.Namespace == Namespaces.Parser) {
                    writer.Write (fieldSymbol.Name);
                } else {
                    writer.Write (fieldSymbol);
                }
            } else {
                writer.Write (term);
            }
        }

        private static void PrettyPrintStructure (StructureObject o, TextWriter writer, int indent) {
            if (o.HasProperty (Symbols.ParserTermName)) {
                o.GetProperty (Symbols.ParserTermName).PrettyPrint(writer);
                writer.Write (" ");
            }

            writer.Write ("{");

            foreach (var field in o.Fields) {
                if (field.Key != Symbols.ParserTermName) {
                    writer.Write (Indent (indent + 1));

                    field.Key.PrettyPrint (writer, indent + 1);
                    writer.Write (" = ");
                    field.Value.PrettyPrint (writer, indent + 1);
                }
            }

            writer.Write (Indent (indent) + "}");
        }

        private static string Indent (int indent) {
            return "\r\n" + new string (' ', indent*2);
        }

        private static void PrettyPrintList (ListObject termList, TextWriter writer, int indent) {
            writer.Write ("[");
            foreach (var term in termList) {
                writer.Write (Indent (indent + 1));
                term.PrettyPrint (writer, indent + 1);
            }
            writer.Write (Indent(indent) + "]");
        }

        public static AnyObject GetTermName (this AnyObject term) {
            return term.GetProperty (Symbols.ParserTermName);
        }
    }
}
