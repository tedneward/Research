using System.IO;
using Tycho.Runtime;
using Tycho.Grammar;

namespace Tycho.Language {
    public class PegSourceParser : ISourceParser {
        private readonly ITermTranslator Translator;
        private readonly IParser Parser;

        public PegSourceParser () : this (new TermTranslator(), new ParserLoader ().LoadParser (LoadGrammarSource ())) {}

        private static string LoadGrammarSource () {
            return File.ReadAllText ("expression.grammar");
        }

        public PegSourceParser (ITermTranslator translator, IParser parser) {
            Translator = translator;
            Parser = parser;
        }

        public AnyObject Parse (string expression, string filename) {
            return Translator.Translate (Parser.ParseTerm (expression, filename));
        }
    }
}