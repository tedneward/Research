using System;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.Language {
    public interface IParserLoader {
        IParser LoadParser (string source);
    }
}