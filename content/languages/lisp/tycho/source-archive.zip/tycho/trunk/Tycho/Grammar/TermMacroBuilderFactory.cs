using System;
using System.Collections.Generic;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    public class TermMacroBuilderFactory : ITermMacroBuilderFactory {
        public ITermMacroBuilder BuildNamedTermMacroBuilder (string name) {
            return new NamedTermMacroBuilder (name);
        }

        public ITermMacroBuilder BuildListTermMacroBuilder (IEnumerable<ITermMacroBuilder> terms, SourceInformation sourceInformation) {
            return new ListTermMacroBuilder (terms, sourceInformation);
        }

        public ITermMacroBuilder BuildCompositeTermMacroBuilder (string name, IEnumerable<CompositeTermSubTerm> subTerms, SourceInformation sourceInformation) {
            return new CompositeTermMacroBuilder (name, subTerms, sourceInformation);
        }

        public ITermMacroBuilder BuildConstantTermMacroBuilder (ITerm term) {
            return new ConstantTermMacroBuilder (term);
        }
    }
}