using Tycho.Runtime;

namespace Tycho.Parser {
    class QuoteVariableGenerator : TermGenerator {
        AnyObject FieldName;

        public QuoteVariableGenerator (AnyObject fieldName) {
            FieldName = fieldName;
        }

        public override AnyObject BuildTerm (params AnyObject [] arguments) {
            AnyObject term = arguments [0];
            if (term.HasProperty (FieldName)) {
                return term.GetProperty (FieldName);
            } else {
                return RuntimeModule.Null;
            }
        }
    }
}