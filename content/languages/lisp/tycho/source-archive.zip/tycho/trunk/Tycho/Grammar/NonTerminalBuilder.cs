using System;
using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    class NonTerminalBuilder : INonTerminalBuilder {
        public void Build (string name, NonTerminal nonTerminal, RuleCaptures ruleCaptures) {
            nonTerminal.Name = name;
            nonTerminal.FirstCaptureName = ruleCaptures.FirstCapture;
            nonTerminal.LastCaptureName = ruleCaptures.LastCapture;
            nonTerminal.Rule = ruleCaptures.Rule;
            nonTerminal.Multiples = ruleCaptures.MultipleCaptures;
        }
    }
}