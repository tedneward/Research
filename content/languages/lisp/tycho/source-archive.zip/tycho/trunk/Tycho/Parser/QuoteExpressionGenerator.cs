using Tycho.Runtime;

namespace Tycho.Parser {
    class QuoteExpressionGenerator : TermGenerator {
        private int ArgumentIndex;

        public QuoteExpressionGenerator (int argumentIndex) {
            ArgumentIndex = argumentIndex;
        }

        public override AnyObject BuildTerm (params AnyObject[] arguments) {
            return arguments[ArgumentIndex];
        }
    }
}