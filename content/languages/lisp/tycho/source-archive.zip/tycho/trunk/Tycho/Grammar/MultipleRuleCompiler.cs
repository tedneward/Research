using Tycho.Parser.Peg;

namespace Tycho.Grammar {
    class MultipleRuleCompiler : IMultipleRuleCompiler {
        private readonly IRuleCompiler RuleCompiler;

        public MultipleRuleCompiler (IRuleCompiler ruleCompiler) {
            RuleCompiler = ruleCompiler;
        }

        public IRule Compile (int minimum, int maximum, ITerm term, ProductionCompilerContext context, ICaptureCounter captureCounter) {
            var multipleCaptureCounter = captureCounter.CreateMultipleCaptureScope ();
            var compositeTerm = (CompositeTerm) term;
            ITerm rule = compositeTerm.SubTerms["rule"];
            return new MultipleRule (minimum, maximum, RuleCompiler.Compile (rule, context, multipleCaptureCounter));
        }
    }
}