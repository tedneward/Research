using System;
using System.Collections.Generic;
using System.IO;
using Tycho.Compiler;

namespace Tycho.Runtime {
    public class FileSystemModuleLoader : IModuleLoader {
        private string BaseDirectory;
        private IModuleCompiler ModuleCompiler;

        public FileSystemModuleLoader (string baseDirectory, IModuleCompiler moduleCompiler) {
            BaseDirectory = baseDirectory;
            ModuleCompiler = moduleCompiler;
        }

        public AnyObject LoadModule (Namespace ns, string[] modulePath, IModuleScopeLoader moduleLoader) {
            var sourcePath = Path.Combine (BaseDirectory, String.Join ("\\", modulePath)) + ".tycho";

            if (!File.Exists (sourcePath)) {
                return null;
            }

            string source = File.ReadAllText (sourcePath);

            return ModuleCompiler.CompileModule (source, sourcePath, ns, moduleLoader);
        }
    }
}