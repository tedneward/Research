using System;
using Tycho.Grammar;
using Tycho.Parser.Peg;

namespace Tycho.Language {
    class GrammarParser : IGrammarParser {
        public ITerm LoadGrammarTerms (string source) {
            var grammarParser = GrammarLoader.CreateGrammar ();
            IProductionParser parser = new ProductionParser (grammarParser);
            return parser.Parse (source, null);
//            return grammarParser.ParseTerm (source, null);
        }
    }
}