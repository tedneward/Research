package org.crap4j.anttask;

import junit.framework.TestCase;

public class Crap4jAntTaskTest extends TestCase {
	public void testRun() throws Exception {
		
	}
}
