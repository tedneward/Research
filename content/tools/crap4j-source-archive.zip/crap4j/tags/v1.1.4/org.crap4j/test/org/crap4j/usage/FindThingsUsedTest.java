package org.crap4j.usage;

import junit.framework.TestCase;

public class FindThingsUsedTest extends TestCase {
  
  public void testClassUsesThings() throws Exception {
    
  }

}
