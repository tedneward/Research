package org.crap4j;

public interface CrapCalculator {

	public int computeCrap(int complexity, Crap crapValue);
}
