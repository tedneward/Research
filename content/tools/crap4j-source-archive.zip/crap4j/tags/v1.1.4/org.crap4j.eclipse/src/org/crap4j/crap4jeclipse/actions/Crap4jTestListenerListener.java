package org.crap4j.crap4jeclipse.actions;

public interface Crap4jTestListenerListener {
  
  public void finished();
  
  public void cancelled();

}
