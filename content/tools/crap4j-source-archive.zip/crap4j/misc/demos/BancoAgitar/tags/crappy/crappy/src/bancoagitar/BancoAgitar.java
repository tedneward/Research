package bancoagitar;

import java.util.HashMap;

public class BancoAgitar {
	
	public static final double MIN_BALANCE = 500.0;
	public static final double MAX_BALANCE = 1000000.00;
	private static final int BASE_ACCT_NUM = 1000;
	
	private HashMap<String, CheckingAccount>accountsList;
	
	private int accountNumberIndex;
	public static final int CHECK_DEPOSIT_TYPE = 2;
	public static final int CASH_DEPOSIT_TYPE = 1;
	public static final int TRANSFER_DEPOSIT_TYPE = 3;
	public static final int INTEREST_DEPOSIT_TYPE = 4;

	
	public BancoAgitar() {
		accountsList = new HashMap<String, CheckingAccount>();
		accountNumberIndex = 0;
	}
	
	public void addCheckingAccount(String name, String SSN, double openingBalance) {
		String acctNum = createNewAccountNumber();
		CheckingAccount newAcct = new CheckingAccount(acctNum, name, SSN, openingBalance);
		accountsList.put(acctNum, newAcct);
	} 
	
	public void deleteAccount(String acctNum) {
		if (accountsList.size() == 0 || !accountsList.containsKey(acctNum))
			throw new BancoAgitarException("There's no account for SSN: " + acctNum);
		accountsList.remove(acctNum);	
	}
	
	public void deposit(String acctNum, double depositAmount) {
		CheckingAccount acct = accountsList.get(acctNum);
		acct.deposit(depositAmount, 1);
	}
	
	public void withdraw(String acctNum, double witdrawAmount) {
		CheckingAccount acct = accountsList.get(acctNum);
		acct.withdraw(witdrawAmount);
	}
	
	public void transfer(String fromAcctNum, String toAcctNum, double transferAmount) {
		if (fromAcctNum == toAcctNum)
			throw new BancoAgitarException("Can't transfer to same account!");
		CheckingAccount fromAcct = getAccountByAccountNumber(fromAcctNum);
		CheckingAccount toAcct = getAccountByAccountNumber(toAcctNum);
		fromAcct.withdraw(transferAmount);
		toAcct.deposit(transferAmount, TRANSFER_DEPOSIT_TYPE);
	}
	
	public CheckingAccount getAccountByAccountNumber(String acctNumber) {
		if (!accountsList.containsKey(acctNumber))
			throw new BancoAgitarException("Invalid account number: " + acctNumber);
		return accountsList.get(acctNumber);
	}
	
	public CheckingAccount[] getAllAccounts() {
		CheckingAccount[] allAccounts = new CheckingAccount[accountsList.size()];
		int idx = 0;
		for (String acctNum : accountsList.keySet()) {
			allAccounts[idx++] = accountsList.get(acctNum);
		}
		return allAccounts;
	}
	
	private String createNewAccountNumber() {
		return "" + BASE_ACCT_NUM + ++accountNumberIndex;
	}
	
	public int getNumberOfAccounts() {
		return accountsList.size();
	}
	
	public double getTotalDeposits() {
		double totDeposits = 0.0;
		for (String ssn : accountsList.keySet()) {
			totDeposits += accountsList.get(ssn).getBalance();
		}
		return totDeposits;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		CheckingAccount[] allAccounts = getAllAccounts();
		for (CheckingAccount acct : allAccounts) {
			sb.append("[" + acct.getName() + ":" + acct.getSSN() + ":" + acct.getAccountNumber() + "=" + acct.getBalance() + "]");
		}
		return sb.toString();
	}

}