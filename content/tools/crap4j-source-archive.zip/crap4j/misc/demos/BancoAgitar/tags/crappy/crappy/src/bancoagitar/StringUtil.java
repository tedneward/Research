package bancoagitar;

public class StringUtil {
	
	public static boolean isNonEmpty(String s) {
		if (s == null || s.length() == 0)
			return true;
		return false;
	}

}
