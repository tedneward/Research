package bancoagitar;

import java.util.List;
import java.util.Random;

public class CheckingAccount {

	private String accountNumber;
	private String name;
	private String SSN;
	double balance;
	Random random = new Random();

	protected CheckingAccount(String accountNumber, String name, String SSN,
			double openingBalance) {
		validateAll(name, SSN, openingBalance);
		initializeAccount(accountNumber, name, SSN, openingBalance);
	}

	private void initializeAccount(String accountNumber, String name,
			String SSN, double openingBalance) {
		this.accountNumber = accountNumber;
		this.name = name;
		this.SSN = SSN;
		this.balance = openingBalance;
	}

	private void validateAll(String name, String SSN, double openingBalance) {
		Util.validateName(name);
		Util.validateSSN(SSN);
		if (openingBalance < BancoAgitar.MIN_BALANCE
				|| openingBalance > BancoAgitar.MAX_BALANCE)
			throw new BancoAgitarException("Invalid opening balance:"
					+ openingBalance);
	}

	public void deposit(double depositAmount, int depositType) {
		if (depositAmount <= 1.00)
			throw new BancoAgitarException(
					"Invalid deposit amount.  Minimum deposit is $1.00");
		validateBalance(balance + depositAmount);

		if (depositAmount < 5000.00) {
			balance += depositAmount;
		} else if (depositType == BancoAgitar.CASH_DEPOSIT_TYPE) {
			fillOutFederalFormForLargeCashDeposit();
			balance += depositAmount;
		} else if (depositType == BancoAgitar.TRANSFER_DEPOSIT_TYPE) {
			fundsLockRequest();
			balance += depositAmount;
		} else if (depositType == BancoAgitar.INTEREST_DEPOSIT_TYPE) {
			markInterest();
			balance += depositAmount;
		}

	}

	public void withdraw(double withdrawAmount) {
		if (withdrawAmount <= 1.00)
			throw new BancoAgitarException("Invalid withdraw amount.  Minimum withdraw amount is $1.00");
		validateBalance(balance - withdrawAmount);
		
		if (withdrawAmount > cashReserves()) {
			double difference = withdrawAmount - cashReserves();
			borrowFromBranch(withdrawAmount, difference);								
		} else {
			validateBalance(balance - withdrawAmount);
			balance -= withdrawAmount;
		}
	}

	private void borrowFromBranch(double withdrawAmount, double difference) {
		for (Branch branch : getBranches()) {
			if (candidate(branch, difference)  && branch.transfer(thisBranch())) {				
				balance -= withdrawAmount;
				return;
			}
		}
		throw new BancoAgitarException("Funds not available to withdraw "+withdrawAmount);
	}

	private boolean candidate(Branch branch, double difference) {
		return branch.hasFunds() && branch.willLoan(difference);
	}

	public void validateBalance(double balance) {
		if (balance < BancoAgitar.MIN_BALANCE
				|| balance > BancoAgitar.MAX_BALANCE)
			throw new BancoAgitarException("Invalid balance: " + balance);
	}

	public String getName() {
		return name;
	}

	public String getSSN() {
		return SSN;
	}

	public double getBalance() {
		return balance;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	private void fillOutFederalFormForLargeCashDeposit() {
		// TODO Auto-generated method stub

	}

	private boolean fundsLockRequest() {
		if (random.nextInt(2) % 2 == 0)
			return true;
		else
			return false;
	}

	private double cashReserves() {
		return 1000000.00;
	}

	private void markInterest() {
		// TODO Auto-generated method stub

	}

	private Branch thisBranch() {
		return null;
	}

	private Branch branchWithReserve(double difference, List<Branch> branches) {
		return branches.get(0);
	}

	private List<Branch> getBranches() {
		return null;
	}

}
