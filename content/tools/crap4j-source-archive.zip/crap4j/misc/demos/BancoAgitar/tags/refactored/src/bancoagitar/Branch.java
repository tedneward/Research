package bancoagitar;

public class Branch {

	public boolean willLoan(double difference) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean transfer(Branch thisBranch) {
		return true;
	}

	public boolean hasFunds() {
		// TODO Auto-generated method stub
		return false;
	}

}
