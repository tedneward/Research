package ssndatabase;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import bancoagitar.BancoAgitarException;

public class SSNChecks {
	
	public static boolean isValidSSN(String SSN) {
		String curDir = System.getProperty("user.dir");
		String fsep = File.separator;
		String validSSNFile = curDir + fsep + "resources" + fsep + "ValidSSN";
		try {
			BufferedReader in = new BufferedReader(new FileReader(validSSNFile));
			String str;
			while ((str = in.readLine()) != null) {
				if (str.equals(SSN))
					return true;
			}
			in.close();
		} catch (IOException e) {
			throw new BancoAgitarException("Cannot open validSSN file at: "
					+ validSSNFile);
		}
		return false;
	}

}
