package bancoagitar;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Util {

	private static String VALID_NAME_REGEX = "[a-zA-Z ]{2,40}";

	public static void validateName(String name) {
		if (!name.matches(VALID_NAME_REGEX))
			throw new BancoAgitarException("Invalid name:" + name);
	}

	 public static void validateSSN(String SSN) {
	 if (!SSN.matches("[0-9]{3}-[0-9]{2}-[0-9]{4}"))
		 throw new BancoAgitarException("Invalid SSN: " + SSN);
	 }

	public static void hardValidateSSN(String SSN) {
		if (ssndatabase.SSNChecks.isValidSSN(SSN) == false)
			throw new IllegalArgumentException("Invalid SSN");
	}

}
