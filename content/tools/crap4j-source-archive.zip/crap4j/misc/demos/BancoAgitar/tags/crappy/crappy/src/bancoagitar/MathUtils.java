package bancoagitar;

public class MathUtils {

	public static int max(int n1, int n2) {
		if (n1 >= n2)
			return n1;
		return n2;
	}
	
	public static int min(int n1, int n2) {
		if (n1 <= n2)
			return n1;
		return n2;
	}
}
