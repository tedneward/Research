package bancoagitar;

public class BancoAgitarException extends RuntimeException {
	
	public BancoAgitarException(String msg) {
		super(msg);
	}

}
