DropboxMQ 1.2

  INTRODUCTION
================

Welcome to Project DropboxMQ!  We hope you like what you see.  See docs/index.html for more information.
Any and all feedback is greatly appreciated.  Please contact us at dwayne@schultz.net or
dropboxmq-info@lists.sourceforge.net.


  INSTALLING
==============

For a detailed installation guide, go to:

    http://dropboxmq.sourceforge.net/quick.shtml

DropboxMQ can be built from the distribution but pre-built jars can be found in the lib directory.


  RELEASE NOTES
=================
    1.2
      * JCA compatibility with other (jboss) app servers

    1.1
      * Uniquely names processing files with client id to avoid NFS race condition in clustered environments
      * All property files and ra.xml String data can contain System property references
      * Changed deleteCompleteTransactions configuration default to true
      * Added clientId configuration for standalone JNDI clients

    1.0
      * Improved processing exception handling
      * IN selector works with numeric values
      * Improved shutdown logic for ConnectionConsumer and EndpointFactoryConsumer
      * Added preserveDeletedDropboxes and deleteCompleteTransactions, see configuration.html
      * Renamed build property delete.processed.messages to tests.delete.completed.artifacts
      * Refined FileSystem abstraction

    0.9
      * JCA and XA complete
      * Selector based routing (was defer mechanism based on JMSType in 0.8)
      * Read locks (both global and per destination) to stop consumers
      * Write locks to slow or stop producers
      * Message selector support for LIKE, message selector implementation complete
      * Consumer can delete expired messages with deleteExpiredMessages configuration
      * Consumer can bypass expired checking with consumeExpiredMessages configuration

    0.8
      * Added message defer mechanism (changed to routing in 0.9) based on JMSType
      * JMSType is preserved
            WARNING:  JMS message header may not be fully preserved when mixing 0.8 and beyond with 0.7 and before
      * JCA working with XA
      * More robust MessageTranscoder implementation
      * log4j INFO logging shows only file operations (read, writes, moves and deletes)
      * Moved to subversion

    0.7
      * JCA working in non-XA scenarios

    0.6
      * Fixed compliance regressions

    0.5
      * Message selectors 90% implemented
      * Implemented ConnectionConsumer
      * Started JCA and XA support
      * Added error and processing desitination to automate retries and check status

    0.4
      * Pub-sub (topic) support
      * MessageTranscoder uses cumulative, single-pass transcoding
      * Administrative tools

    0.3
      * Support for all message types
      * QueueBrowser implementation
      * Documentation!

    0.2
      * Compliance improvements
         * Better message property support
         * Unique client ID support
         * Session listener support
         * Message recovery support
         * Expired message support
      * Added JMS CTS test classes
      * More verbose logging
      * MessageTranscoder support allows custom filenames, encoding/decoding metadata, message prioritizing, etc.

    0.1
      * Initial release
      * Queue implementation only (no topics or pub-sub)


==============================================================================

=======
  END
=======

 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 Created: 21 Jun 2005
 @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 @version $Revision: 231 $, $Date: 2011-08-12 21:50:47 -0600 (Fri, 12 Aug 2011) $
