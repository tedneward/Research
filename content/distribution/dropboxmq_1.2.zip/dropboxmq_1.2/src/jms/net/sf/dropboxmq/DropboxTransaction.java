/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import javax.jms.IllegalStateException;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Session;
import net.sf.dropboxmq.dropboxsupport.DirectoryStructure;
import net.sf.dropboxmq.dropboxsupport.TransactionData;
import net.sf.dropboxmq.messages.MessageImpl;
import net.sf.dropboxmq.sessions.SessionImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 09 Oct 2005
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 231 $, $Date: 2011-08-12 21:50:47 -0600 (Fri, 12 Aug 2011) $
 */
public class DropboxTransaction
{
    private static final Log log = LogFactory.getLog(DropboxTransaction.class);

    private static final String XA_PREFIX = "xa-";

    private final String instanceId;
    private int sequence = 0;
    private boolean distributed = false;
    private boolean inTransaction = false;
    private boolean resumed = false;
    private final boolean transacted;
    private final int acknowledgeMode;
    private final Configuration configuration;
    private final FileSystem fileSystem;
    private final File associated;
    private final File unassociated;
    private final File prepared;
    private final File committing;
    private final File committed;
    private final File rollingBack;
    private final File rolledBack;
    private final Object lock = new Object();
    private MessageListener messageListener = null;
    private boolean closed = false;
    private final LogData logData = new LogData();
    private String transactionId = null;

    public static class TransactionException extends Exception
    {
        private static final long serialVersionUID = 932107190482912152L;

        public TransactionException(final String message)
        {
            super(message);
        }

        public TransactionException(final Throwable cause)
        {
            super(cause);
        }
    }

    public static class ProtocolException extends TransactionException
    {
        private static final long serialVersionUID = -5107980384376199438L;

        public ProtocolException(final String message)
        {
            super(message);
        }
    }

    public static class InLocalTransactionException extends TransactionException
    {
        private static final long serialVersionUID = -2099433195004649322L;

        public InLocalTransactionException(final String message)
        {
            super(message);
        }
    }

    public static class NotAnXIDException extends TransactionException
    {
        private static final long serialVersionUID = -729555807118292899L;

        public NotAnXIDException(final String message)
        {
            super(message);
        }
    }

    static class LogData
    {
        private final Collection sentMessages = new ArrayList();
        private final Collection sentMessagesSet = new HashSet();
        private final List receivedMessages = new ArrayList();
        private final Collection receivedMessagesSet = new HashSet();
    }

    public static void createTransactionDirs(final Configuration configuration) throws FileSystem.FileSystemException
    {
        final DropboxTransaction transaction
                = new DropboxTransaction(null, true, Session.SESSION_TRANSACTED, configuration);
        final FileSystem fileSystem = configuration.getFileSystem();
        fileSystem.mkdirs(transaction.associated);
        fileSystem.mkdirs(transaction.unassociated);
        fileSystem.mkdirs(transaction.prepared);
        fileSystem.mkdirs(transaction.committing);
        fileSystem.mkdirs(transaction.committed);
        fileSystem.mkdirs(transaction.rollingBack);
        fileSystem.mkdirs(transaction.rolledBack);
    }

    public DropboxTransaction(final String instanceId, final boolean transacted, final int acknowledgeMode,
            final Configuration configuration)
    {
        LogHelper.logMethod(log, toObjectString(), "DropboxTransaction(), instanceId = " + instanceId
                + ", transacted = " + transacted
                + ", acknowledgeMode = " + SessionImpl.getAcknowledgeModeString(acknowledgeMode)
                + ", configuration = " + configuration);
        this.instanceId = instanceId;
        this.transacted = transacted;
        this.acknowledgeMode = acknowledgeMode;
        this.configuration = configuration;
        fileSystem = configuration.getFileSystem();

        final File transactionDir = new File(
                configuration.getRootDir(), DirectoryStructure.DROPBOXMQ_SUB_DIR + File.separator + "transaction");
        associated = new File(transactionDir, "associated");
        unassociated = new File(transactionDir, "unassociated");
        prepared = new File(transactionDir, "prepared");
        committing = new File(transactionDir, "committing");
        committed = new File(transactionDir, "committed");
        rollingBack = new File(transactionDir, "rolling-back");
        rolledBack = new File(transactionDir, "rolled-back");
    }

    public LogData getLogData()
    {
        return logData;
    }

    public Configuration getConfiguration()
    {
        return configuration;
    }

    public boolean isTransacted()
    {
        return transacted;
    }

    public int getAcknowledgeMode()
    {
        return acknowledgeMode;
    }

    public MessageListener getMessageListener()
    {
        synchronized (lock)
        {
            LogHelper.logMethod(log, toObjectString(), "getMessageListener() = " + messageListener);
            return messageListener;
        }
    }

    public void setMessageListener(final MessageListener messageListener)
    {
        synchronized (lock)
        {
            LogHelper.logMethod(log, toObjectString(), "setMessageListener(), messageListener = " + messageListener);
            this.messageListener = messageListener;
        }
    }

    boolean isInTransaction()
    {
        return inTransaction;
    }

    boolean isDistributed()
    {
        return distributed;
    }

    boolean isAutoAcknowledge()
    {
        return acknowledgeMode == Session.AUTO_ACKNOWLEDGE || acknowledgeMode == Session.DUPS_OK_ACKNOWLEDGE;
    }

    private static String getPrefix(final boolean isDistributed)
    {
        return isDistributed ? XA_PREFIX : "local-";
    }

    public void startLocal() throws TransactionException
    {
        LogHelper.logMethod(log, toObjectString(), "startLocal()");
        synchronized (lock)
        {
            if (!transacted && !isAutoAcknowledge())
            {
                throw new TransactionException("Session is not transacted");
            }

            if (isInTransaction())
            {
                throw new TransactionException("Transaction already started");
            }

            startPassively();
        }
    }

    void startPassively() throws TransactionException
    {
        LogHelper.logMethod(log, toObjectString(),
                "startPassively(), transacted = " + transacted + ", inTransaction = " + inTransaction);
        if (!isInTransaction())
        {
            start(instanceId + "-" + sequence, false);
            sequence++;
        }
    }

    public void start(final String newTransactionId, final boolean isDistributed) throws TransactionException
    {
        LogHelper.logMethod(log, toObjectString(),
                "start(), newTransactionId = " + newTransactionId + ", isDistributed = " + isDistributed);
        synchronized (lock)
        {
            if (isInTransaction())
            {
                if (isDistributed())
                {
                    throw new ProtocolException("Transaction log already initialized");
                }
                else
                {
                    throw new InLocalTransactionException(
                            "Transaction log can't be initialized after messages have sent or received");
                }
            }

            transactionId = newTransactionId;
            distributed = isDistributed;
            inTransaction = true;
            resumed = false;
        }
    }

    public void end(final String currentTransactionId) throws TransactionException
    {
        LogHelper.logMethod(log, toObjectString(), "end(), currentTransactionId = " + currentTransactionId);
        synchronized (lock)
        {
            if (!isInTransaction())
            {
                throw new ProtocolException("Transaction log not initialized");
            }

            if (!isDistributed())
            {
                throw new ProtocolException(
                        "Attempting to end distributed transaction while not in a distributed transaction");
            }

            if (!transactionId.equals(currentTransactionId))
            {
                throw new ProtocolException(
                        "Attempting to end a transaction not matched with the current transaction");
            }

            try
            {
                final File associatedFile = writeTransactionLog();
                fileSystem.move(associatedFile, new File(unassociated, associatedFile.getName()));
            }
            catch (IOException e)
            {
                throw new TransactionException(e);
            }
            catch (FileSystem.FileSystemException e)
            {
                throw new TransactionException(e);
            }

            inTransaction = false;
            resumed = false;
            distributed = false;

            logData.sentMessages.clear();
            logData.sentMessagesSet.clear();
            logData.receivedMessages.clear();
            logData.receivedMessagesSet.clear();
        }
    }

    File writeTransactionLog() throws IOException, FileSystem.FileSystemException
    {
        LogHelper.logMethod(log, toObjectString(), "writeTransactionLog()");
        final String filename = getPrefix(isDistributed()) + transactionId;
        final File associatedFile = new File(associated, filename);
        final File newFile;
        if (resumed)
        {
            newFile = new File(associated, filename + ".new-" + System.currentTimeMillis());
        }
        else
        {
            newFile = associatedFile;
        }

        final BufferedWriter transactionLog = fileSystem.newBufferedWriter(newFile);
        log.debug("Created transaction log " + associatedFile);

        try
        {
            for (Iterator iterator = logData.sentMessages.iterator(); iterator.hasNext();)
            {
                final TransactionData transactionData = (TransactionData)iterator.next();
                logMessage(SENT_TYPE, transactionData, transactionLog);
            }
            for (Iterator iterator = logData.receivedMessages.iterator(); iterator.hasNext();)
            {
                final TransactionData transactionData = (TransactionData)iterator.next();
                logMessage(RECEIVED_TYPE, transactionData, transactionLog);
            }
        }
        finally
        {
            try
            {
                transactionLog.close();
            }
            catch (IOException e)
            {
                // ignore
                log.warn("IOException while closing transaction log", e);
            }
        }

        if (resumed)
        {
            fileSystem.move(newFile, new File(associated, filename));
        }
        return associatedFile;
    }

    private static final String OPTION_PREFIX = "--";
    private static final String TYPE_OPTION = OPTION_PREFIX + "type";
    private static final String MESSAGE_FILE_OPTION = OPTION_PREFIX + "message-file";
    private static final String ORIGINAL_FILE_OPTION = OPTION_PREFIX + "original-file";
    private static final String COMMIT_FILE_OPTION = OPTION_PREFIX + "commit-file";
    private static final String ROLLBACK_FILE_OPTION = OPTION_PREFIX + "rollback-file";
    private static final String CREATOR_VERSION_OPTION = OPTION_PREFIX + "creator-version";

    // Not necessarily the current version.  May be earlier than the current version if the current version is
    // backwards compatible.
    private static final String CURRENT_CREATOR_VERSION = "1.1";

    private static final String RECEIVED_TYPE = "received";
    private static final String SENT_TYPE = "sent";

    void logMessage(final String type, final TransactionData data, final BufferedWriter transactionLog)
            throws IOException
    {
        LogHelper.logMethod(log, toObjectString(), "logMessage(), type = " + type + ", data = " + data);

        final String line = "dropboxmq " + CREATOR_VERSION_OPTION + " " + CURRENT_CREATOR_VERSION
                + " " + TYPE_OPTION + " " + type
                + " " + MESSAGE_FILE_OPTION + " " + data.getMessageFile().getAbsolutePath()
                + (data.getOriginalFile() == null ? "" : " "
                    + ORIGINAL_FILE_OPTION + " " + data.getOriginalFile().getAbsolutePath())
                + (data.getCommitFile() == null ? "" : " "
                    + COMMIT_FILE_OPTION + " " + data.getCommitFile().getAbsolutePath())
                + (data.getRollbackFile() == null ? "" : " "
                    + ROLLBACK_FILE_OPTION + " " + data.getRollbackFile().getAbsolutePath());

        transactionLog.write(line);
        transactionLog.newLine();
    }

    public void resume(final String unassociatedTransactionId) throws TransactionException
    {
        LogHelper.logMethod(log, toObjectString(),
                "resume(), unassociatedTransactionId = " + unassociatedTransactionId);
        synchronized (lock)
        {
            if (isInTransaction())
            {
                if (isDistributed())
                {
                    throw new ProtocolException("Transaction log already initialized");
                }
                else
                {
                    throw new InLocalTransactionException(
                            "Transaction log can't be initialized after messages have sent or received");
                }
            }

            final String filename = getPrefix(true) + unassociatedTransactionId;
            try
            {
                fileSystem.move(new File(unassociated, filename), new File(associated, filename));
            }
            catch (FileSystem.SourceNotFoundException ignore)
            {
                throw new NotAnXIDException(
                        "Could not find unassocated transaction instanceId " + unassociatedTransactionId);
            }
            catch (FileSystem.FileSystemException e)
            {
                throw new TransactionException(e);
            }

            transactionId = unassociatedTransactionId;
            distributed = true;
            resumed = true;
            inTransaction = true;
            try
            {
                final File transactionFile = new File(associated, getPrefix(true) + transactionId);
                readTransactionLog(transactionFile, logData);
            }
            catch (IOException e)
            {
                throw new TransactionException(e);
            }
        }
    }

    void readTransactionLog(final File transactionFile, final LogData localLogData)
            throws IOException, TransactionException
    {
        final BufferedReader reader = fileSystem.newBufferedReader(transactionFile);
        try
        {
            int lineNo = 0;
            boolean done = false;
            while (!done)
            {
                final String line = reader.readLine();
                if (line == null)
                {
                    done = true;
                }
                else
                {
                    lineNo++;
                    parseLine(line, localLogData, lineNo, transactionFile);
                }
            }
        }
        finally
        {
            try
            {
                reader.close();
            }
            catch (IOException ignore)
            {
                // ignore
            }
        }
    }

    void parseLine(final String line, final LogData localLogData, final int lineNo, final File transactionFile)
            throws TransactionException
    {
        String type = null;
        File messageFile = null;
        File originalFile = null;
        File commitFile = null;
        File rollbackFile = null;
        // No version existed for 1.0 and earlier so it is the default
        String creatorVersion = "1.0";

        int lastEnd = 0;
        boolean done = false;
        while (!done)
        {
            final int nextDashes = line.indexOf(OPTION_PREFIX, lastEnd);
            if (nextDashes == -1)
            {
                done = true;
            }
            else
            {
                lastEnd = line.indexOf(OPTION_PREFIX, nextDashes + 1);
                if (lastEnd == -1)
                {
                    lastEnd = line.length();
                    done = true;
                }

                if (line.startsWith(TYPE_OPTION, nextDashes))
                {
                    type = line.substring(nextDashes + TYPE_OPTION.length(), lastEnd).trim();
                }
                else if (line.startsWith(MESSAGE_FILE_OPTION, nextDashes))
                {
                    messageFile = new File(line.substring(nextDashes + MESSAGE_FILE_OPTION.length(), lastEnd).trim());
                }
                else if (line.startsWith(ORIGINAL_FILE_OPTION, nextDashes))
                {
                    originalFile = new File(line.substring(nextDashes + ORIGINAL_FILE_OPTION.length(), lastEnd).trim());
                }
                else if (line.startsWith(COMMIT_FILE_OPTION, nextDashes))
                {
                    commitFile = new File(line.substring(nextDashes + COMMIT_FILE_OPTION.length(), lastEnd).trim());
                }
                else if (line.startsWith(ROLLBACK_FILE_OPTION, nextDashes))
                {
                    rollbackFile = new File(line.substring(nextDashes + ROLLBACK_FILE_OPTION.length(), lastEnd).trim());
                }
                else if (line.startsWith(CREATOR_VERSION_OPTION, nextDashes))
                {
                    creatorVersion = line.substring(nextDashes + CREATOR_VERSION_OPTION.length(), lastEnd).trim();
                }
                else
                {
                    throw new TransactionException("Invalid option on line " + lineNo + " of " + transactionFile);
                }
            }
        }

        if (!creatorVersion.equals(CURRENT_CREATOR_VERSION))
        {
            throw new TransactionException("Incompatible transaction file, " + transactionFile);
        }

        final TransactionData data = new TransactionData(messageFile, originalFile, commitFile, rollbackFile);
        addParsedLine(type, data, localLogData, lineNo, transactionFile);
    }

    void addParsedLine(final String type, final TransactionData data, final LogData localLogData, final int lineNo,
            final File transactionFile)
            throws TransactionException
    {
        final File messageFile = data.getMessageFile();
        if (messageFile == null)
        {
            throw new TransactionException("Undefined message file on line " + lineNo + " of " + transactionFile);
        }

        if (type != null && type.equals(SENT_TYPE))
        {
            if (!localLogData.sentMessagesSet.contains(messageFile))
            {
                localLogData.sentMessages.add(data);
                localLogData.sentMessagesSet.add(messageFile);
            }
        }
        else if (type != null && type.equals(RECEIVED_TYPE))
        {
            if (!localLogData.receivedMessagesSet.contains(messageFile))
            {
                localLogData.receivedMessages.add(data);
                localLogData.receivedMessagesSet.add(messageFile);
            }
        }
        else
        {
            throw new TransactionException("Invalid or undefined type on line " + lineNo + " of " + transactionFile);
        }
    }

    public void prepare(final String unassociatedTransactionId) throws TransactionException
    {
        LogHelper.logMethod(log, toObjectString(), "prepare()");

        // Note that this method does not disturb the transaction in progress and therefore
        // requires no synchronized block
        final String filename = getPrefix(true) + unassociatedTransactionId;
        try
        {
            fileSystem.move(new File(unassociated, filename), new File(prepared, filename));
        }
        catch (FileSystem.FileSystemException e)
        {
            throw new TransactionException(e);
        }
    }

    public void commit() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "commit()");
        synchronized (lock)
        {
            checkCommitOrRollback(false);

            if (isInTransaction())
            {
                try
                {
                    final File preCommittingFile = writeTransactionLog();
                    doCommit(preCommittingFile, logData);     // NB:  inflection point
                }
                catch (IOException e)
                {
                    throw new DropboxMQJMSException(e);
                }
                catch (FileSystem.FileSystemException e)
                {
                    throw new DropboxMQJMSException(e);
                }
                finally
                {
                    reset();
                }
            }
        }
    }

    public void commit(final String distributedTransactionId, final boolean onePhase) throws TransactionException
    {
        LogHelper.logMethod(log, toObjectString(),
                "commit(), distributedTransactionId = " + distributedTransactionId + ", onePhase = " + onePhase);
        synchronized (lock)
        {
            try
            {
                checkCommitOrRollback(true);
            }
            catch (JMSException e)
            {
                throw new TransactionException(e);
            }
        }

        final File preCommitDir = onePhase ? unassociated : prepared;

        final File preCommittingFile = new File(preCommitDir, getPrefix(true) + distributedTransactionId);
        final LogData localLogData = newLogData();

        try
        {
            readTransactionLog(preCommittingFile, localLogData);
            doCommit(preCommittingFile, localLogData);     // NB:  inflection point
        }
        catch (IOException e)
        {
            throw new TransactionException(e);
        }
        catch (FileSystem.FileSystemException e)
        {
            throw new TransactionException(e);
        }
    }

    LogData newLogData()
    {
        return new LogData();
    }

    void checkCommitOrRollback(final boolean distributedInvocation) throws JMSException
    {
        checkClosed();

        if (!transacted)
        {
            throw new IllegalStateException("Attempt to call commit() or rollback() on a non-transacted session");
        }

        if (isInTransaction())
        {
            if (isDistributed() && !distributedInvocation)
            {
                throw new JMSException("Attempting to locally commit or rollback a distributed transaction");
            }
        }
    }

    void checkClosed() throws IllegalStateException
    {
        if (closed)
        {
            throw new IllegalStateException("Connection is currently in a closed state");
        }
    }

    void doCommit(final File preCommittingFile, final LogData localLogData) throws FileSystem.FileSystemException
    {
        final File committingFile = new File(committing, preCommittingFile.getName());
        fileSystem.move(preCommittingFile, committingFile);     // NB:  inflection point

        for (Iterator iterator = localLogData.sentMessages.iterator(); iterator.hasNext();)
        {
            final TransactionData transactionData = (TransactionData)iterator.next();
            fileSystem.move(transactionData.getMessageFile(), transactionData.getCommitFile());
        }

        for (Iterator iterator = localLogData.receivedMessages.iterator(); iterator.hasNext();)
        {
            final TransactionData transactionData = (TransactionData)iterator.next();
            fileSystem.move(transactionData.getMessageFile(), transactionData.getCommitFile());
        }

        if (configuration.isDeleteCompleteTransactions())
        {
            fileSystem.delete(committingFile);
        }
        else
        {
            fileSystem.move(committingFile, new File(committed, preCommittingFile.getName()));
        }

        log.trace("doCommit() complete");
    }

    public void rollback() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "rollback()");
        synchronized (lock)
        {
            checkCommitOrRollback(false);

            if (isInTransaction())
            {
                try
                {
                    final File preRollbackFile = writeTransactionLog();
                    doRollback(preRollbackFile, logData);     // NB:  inflection point
                }
                catch (IOException e)
                {
                    throw new DropboxMQJMSException(e);
                }
                catch (FileSystem.FileSystemException e)
                {
                    throw new DropboxMQJMSException(e);
                }
                finally
                {
                    reset();
                }
            }
        }
    }

    public void rollback(final String distributedTransactionId) throws TransactionException
    {
        LogHelper.logMethod(log, toObjectString(),
                "rollback(), distributedTransactionId = " + distributedTransactionId);
        synchronized (lock)
        {
            try
            {
                checkCommitOrRollback(true);
            }
            catch (JMSException e)
            {
                throw new TransactionException(e);
            }
        }

        final String filename = getPrefix(true) + distributedTransactionId;
        final File unassociatedFile = new File(unassociated, filename);
        final File preparedFile = new File(prepared, filename);
        if (fileSystem.exists(unassociatedFile) && fileSystem.exists(preparedFile))
        {
            throw new TransactionException(
                    "Transaction " + distributedTransactionId + " found in both unassociated and prepared directories");
        }
        if (!fileSystem.exists(unassociatedFile) && !fileSystem.exists(preparedFile))
        {
            throw new TransactionException(
                    "Transaction " + distributedTransactionId + " not found in unassociated or prepared directories");
        }

        final File preRollbackFile = fileSystem.exists(unassociatedFile) ? unassociatedFile : preparedFile;
        final LogData localLogData = newLogData();

        try
        {
            readTransactionLog(preRollbackFile, localLogData);
            doRollback(preRollbackFile, localLogData);     // NB:  inflection point
        }
        catch (IOException e)
        {
            throw new TransactionException(e);
        }
        catch (FileSystem.FileSystemException e)
        {
            throw new TransactionException(e);
        }
    }

    void doRollback(final File preRollbackFile, final LogData localLogData)
            throws FileSystem.FileSystemException, IOException
    {
        final File rollingBackFile = new File(rollingBack, preRollbackFile.getName());
        fileSystem.move(preRollbackFile, rollingBackFile);     // NB:  inflection point

        for (Iterator iterator = localLogData.sentMessages.iterator(); iterator.hasNext();)
        {
            final TransactionData transactionData = (TransactionData)iterator.next();

            log.trace("Deleting non-committed sent messageFile " + transactionData.getMessageFile());
            fileSystem.delete(transactionData.getMessageFile());
        }

        doRecover(rollingBackFile, localLogData);

        log.trace("doRollback() complete");
    }

    public void recover() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "recover()");
        synchronized (lock)
        {
            if (transacted)
            {
                throw new IllegalStateException("Attempt to call recover() on a transacted session");
            }

            if (!logData.receivedMessages.isEmpty())
            {
                try
                {
                    final File transactionFile = writeTransactionLog();
                    final File rollingBackFile = new File(rollingBack, transactionFile.getName());
                    fileSystem.move(transactionFile, rollingBackFile);     // NB:  inflection point
                    doRecover(rollingBackFile, logData);
                }
                catch (FileSystem.FileSystemException e)
                {
                    throw new DropboxMQJMSException(e);
                }
                catch (IOException e)
                {
                    throw new DropboxMQJMSException(e);
                }
                finally
                {
                    reset();
                }
            }
        }
    }

    void doRecover(final File rollingBackFile, final LogData localLogData) throws FileSystem.FileSystemException
    {
        for (Iterator iterator = localLogData.receivedMessages.iterator(); iterator.hasNext();)
        {
            final TransactionData transactionData = (TransactionData)iterator.next();
            fileSystem.move(transactionData.getMessageFile(), transactionData.getRollbackFile());
        }

        if (configuration.isDeleteCompleteTransactions())
        {
            fileSystem.delete(rollingBackFile);
        }
        else
        {
            fileSystem.move(rollingBackFile, new File(rolledBack, rollingBackFile.getName()));
        }
    }

    private void reset()
    {
        logData.sentMessages.clear();
        logData.sentMessagesSet.clear();

        logData.receivedMessages.clear();
        logData.receivedMessagesSet.clear();

        distributed = false;
        inTransaction = false;
        resumed = false;
    }

    public void acknowledge(final File readMessageFile) throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "acknowledge(), readMessageFile = " + readMessageFile);
        synchronized (lock)
        {
            if (!transacted && !isAutoAcknowledge())
            {
                if (logData.receivedMessagesSet.contains(readMessageFile))
                {
                    boolean found = false;
                    for (final ListIterator iterator = logData.receivedMessages.listIterator();
                            iterator.hasNext() && !found;)
                    {
                        final TransactionData transactionData = (TransactionData)iterator.next();

                        try
                        {
                            fileSystem.move(transactionData.getMessageFile(), transactionData.getCommitFile());
                        }
                        catch (FileSystem.FileSystemException e)
                        {
                            throw new DropboxMQJMSException(e);
                        }

                        iterator.remove();
                        logData.receivedMessagesSet.remove(transactionData.getMessageFile());

                        if (transactionData.getMessageFile().equals(readMessageFile))
                        {
                            found = true;
                        }
                    }
                }
            }
        }
    }

    public List getPreparedTransactionIds()
    {
        LogHelper.logMethod(log, toObjectString(), "getPreparedTransactionIds()");
        final List ids = new ArrayList();
        final String[] preparedFilenames = prepared.list();
        for (int i = 0; i < preparedFilenames.length; i++)
        {
            final String preparedFilename = preparedFilenames[i];

            if (preparedFilename.startsWith(XA_PREFIX))
            {
                ids.add(preparedFilename.substring(XA_PREFIX.length()));
            }
        }

        return ids;
    }

    public void close() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "close()");
        synchronized (lock)
        {
            if (!isDistributed())
            {
                // temporarily set closed to false so rollback() or recover() don't throw an exception
                closed = false;
                if (acknowledgeMode == Session.CLIENT_ACKNOWLEDGE)
                {
                    recover();
                }
                else if (isInTransaction())
                {
                    rollback();
                }
            }

            closed = true;
        }
    }

    void addSentMessage(final File messageFile, final File commitFile) throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "addSentMessage(), messageFile = " + messageFile
                + ", commitFile = " + commitFile);
        synchronized (lock)
        {
            checkClosed();

            if (transacted)
            {
                if (logData.sentMessagesSet.contains(messageFile) || logData.receivedMessagesSet.contains
                        (messageFile))
                {
                    throw new JMSException(
                            "Message file added to transaction twice, messageFile = " + messageFile);
                }
                try
                {
                    startPassively();
                }
                catch (TransactionException e)
                {
                    throw new DropboxMQJMSException(e);
                }
                final TransactionData data = new TransactionData(messageFile, null, commitFile, null);
                logData.sentMessages.add(data);
                logData.sentMessagesSet.add(messageFile);
            }
            else
            {
                try
                {
                    fileSystem.move(messageFile, commitFile);
                }
                catch (FileSystem.FileSystemException e)
                {
                    throw new DropboxMQJMSException(e);
                }
            }
        }
    }

    void addReceivedMessage(
            final File messageFile, final File originalFile, final File commitFile, final File rollbackFile)
            throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "addReceivedMessage(), messageFile = " + messageFile
                + ", originalFile = " + originalFile + ", commitFile = " + commitFile
                + ", rollbackFile = " + rollbackFile);
        synchronized (lock)
        {
            checkClosed();

            if (transacted || !isAutoAcknowledge())
            {
                if (logData.sentMessagesSet.contains(messageFile) || logData.receivedMessagesSet.contains(messageFile))
                {
                    throw new JMSException("Message file added to transaction twice " + messageFile);
                }
                try
                {
                    startPassively();
                }
                catch (TransactionException e)
                {
                    throw new DropboxMQJMSException(e);
                }
                final TransactionData data = new TransactionData(messageFile, originalFile, commitFile, rollbackFile);
                logData.receivedMessages.add(data);
                logData.receivedMessagesSet.add(messageFile);
            }
            else
            {
                try
                {
                    fileSystem.move(messageFile, commitFile);
                }
                catch (FileSystem.FileSystemException e)
                {
                    throw new DropboxMQJMSException(e);
                }
            }
        }
    }

    void deliverMessage(final MessageListener receiversMessageListener, final Message message)
    {
        synchronized (lock)
        {
            // messageListener is the session's distinguished listener.  When it is set, all messages
            // will only be delivered to that listener.
            if (messageListener == null)
            {
                receiversMessageListener.onMessage(message);
            }
            else
            {
                messageListener.onMessage(message);
            }
        }
    }

    public void checkUnsubscribe(final File subscriptionDir) throws JMSException
    {
        for (Iterator iterator = logData.sentMessages.iterator(); iterator.hasNext();)
        {
            final TransactionData transactionData = (TransactionData)iterator.next();

            if (transactionData.getCommitFile() != null
                    && transactionData.getCommitFile().getParentFile().getParentFile().equals(subscriptionDir))
            {
                throw new JMSException("Attempting to unsubscribe while active message consumers exist for"
                        + " subscription " + subscriptionDir);
            }
        }

        for (Iterator iterator = logData.receivedMessages.iterator(); iterator.hasNext();)
        {
            final TransactionData transactionData = (TransactionData)iterator.next();

            if (transactionData.getCommitFile() != null
                    && transactionData.getCommitFile().getParentFile().getParentFile().equals(subscriptionDir))
            {
                throw new JMSException("Attempting to unsubscribe while active message consumers exist for"
                        + " subscription " + subscriptionDir);
            }
        }
    }

    public Object startReparentingMessageToChild(final MessageImpl message, final DropboxTransaction otherTransaction)
            throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "startReparentingMessageToChild(), message = " + message
                + ", otherTransaction = " + otherTransaction);
        if (otherTransaction.logData.receivedMessagesSet.size() != 1
                || !otherTransaction.logData.receivedMessagesSet.contains(message.getReadMessageFile()))
        {
            // Messages should be reparented one at a time
            throw new JMSException("Invalid ServerConsumer transaction state");
        }
        otherTransaction.logData.receivedMessagesSet.clear();
        return otherTransaction.logData.receivedMessages.remove(0);
    }

    public void completeReparentingMessageToChild(final Object messageDataObject)
    {
        LogHelper.logMethod(log, toObjectString(),
                "completeReparentingMessageToChild(), messageDataObject = " + messageDataObject);
        final TransactionData transactionData = (TransactionData)messageDataObject;
        try
        {
            addReceivedMessage(transactionData.getMessageFile(), transactionData.getOriginalFile(),
                    transactionData.getCommitFile(), transactionData.getRollbackFile());
        }
        catch (JMSException e)
        {
            Dropbox.throwRuntimeException(e);
        }
    }

    public void rollbackReparentingFromChild(final Object messageDataObject)
    {
        LogHelper.logMethod(log, toObjectString(),
                "rollbackReparentingFromChild(), messageDataObject = " + messageDataObject);
        final TransactionData transactionData = (TransactionData)messageDataObject;
        try
        {
            fileSystem.move(transactionData.getMessageFile(), transactionData.getOriginalFile());
        }
        catch (FileSystem.FileSystemException e)
        {
            Dropbox.throwRuntimeException(e);
        }
    }

    protected final String toObjectString()
    {
        return super.toString();
    }

}
