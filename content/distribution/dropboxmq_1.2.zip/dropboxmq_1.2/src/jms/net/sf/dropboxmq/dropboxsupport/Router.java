/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.dropboxsupport;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import javax.jms.InvalidSelectorException;
import javax.jms.JMSException;
import javax.jms.Message;
import net.sf.dropboxmq.FileSystem;
import net.sf.dropboxmq.messageselector.Expression;
import net.sf.dropboxmq.messageselector.Parser;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 15 Oct 2008
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 231 $, $Date: 2011-08-12 21:50:47 -0600 (Fri, 12 Aug 2011) $
 */
public class Router
{
    private static final Log log = LogFactory.getLog(Router.class);

    private static final String DO_NOT_ROUTE_PROPERTY_NAME = "JMS_dropboxmq_do_not_route";
    private static final String SELECTOR_PROPERTY_SUFFIX = ".selector";
    private static final String IN_USE_FILE_SUFFIX = ".in-use";

    private final File routingDir;
    private final FileSystem fileSystem;
    private final File routingPropertiesFile;
    private final Map routes = new HashMap();

    private long routingPropertiesLastModified = -1L;

    public Router(final DirectoryStructure structure, final FileSystem fileSystem)
    {
        final File incomingDir = structure.getIncomingDir();
        routingDir = new File(incomingDir, "routing");
        routingPropertiesFile = new File(incomingDir, "routing.properties");
        this.fileSystem = fileSystem;
    }

    public boolean checkRouting(final Message message, final File messageFile)
            throws JMSException, FileSystem.FileSystemException
    {
        boolean routingComplete = false;
        if (fileSystem.exists(routingPropertiesFile))
        {
            final long currentLastModified = routingPropertiesFile.lastModified();
            if (routingPropertiesLastModified != currentLastModified)
            {
                readRoutingProperties();
                routingPropertiesLastModified = currentLastModified;
            }

            final Object doNotRouteObject = message.getObjectProperty(DO_NOT_ROUTE_PROPERTY_NAME);
            final boolean doNotRoute
                    = doNotRouteObject != null && message.getBooleanProperty(DO_NOT_ROUTE_PROPERTY_NAME);
            if (!doNotRoute)
            {
                final String[] inUseFilenames = routingDir.list(new FilenameFilter()
                {
                    public boolean accept(final File dir, final String name)
                    {
                        return name.endsWith(IN_USE_FILE_SUFFIX);
                    }
                });
                if (inUseFilenames != null)
                {
                    Arrays.sort(inUseFilenames);

                    for (int i = 0; i < inUseFilenames.length && !routingComplete; i++)
                    {
                        final String inUseFilename = inUseFilenames[i];
                        final String routingSubDir
                                = inUseFilename.substring(0, inUseFilename.length() - IN_USE_FILE_SUFFIX.length());
                        routingComplete = checkRoute(message, messageFile, routingSubDir);
                    }
                }
            }
        }
        return routingComplete;
    }

    private boolean checkRoute(final Message message, final File messageFile, final String routingSubDir)
            throws FileSystem.FileSystemException
    {
        final Expression expression = (Expression)routes.get(routingSubDir);
        boolean routingComplete = false;
        if (expression != null && expression.evaluate(message))
        {
            final File directory = new File(routingDir, routingSubDir);
            fileSystem.move(messageFile, new File(directory, messageFile.getName()));
            routingComplete = true;
        }
        return routingComplete;
    }

    private void readRoutingProperties()
    {
        final Properties properties = new Properties();
        if (fileSystem.readPropertiesFile(routingPropertiesFile, properties))
        {
            routes.clear();

            for (Iterator iterator = properties.keySet().iterator(); iterator.hasNext();)
            {
                final String key = (String)iterator.next();
                if (key.endsWith(SELECTOR_PROPERTY_SUFFIX))
                {
                    final String selector = properties.getProperty(key);
                    final String routingSubDir = key.substring(0, key.length() - SELECTOR_PROPERTY_SUFFIX.length());
                    try
                    {
                        final Expression expression = Parser.parse(selector);
                        routes.put(routingSubDir, expression);
                    }
                    catch (InvalidSelectorException e)
                    {
                        log.warn("Invalid routing selector " + selector + " to " + routingSubDir
                                + ", route will be ignored", e);
                    }
                }
            }
        }
    }

}
