/*
 Copyright (c) 2010, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq;

import javax.transaction.xa.Xid;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 12 Aug 2006
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 211 $, $Date: 2010-11-14 14:21:24 -0700 (Sun, 14 Nov 2010) $
 */
class XidImpl implements Xid
{
    private static final Log log = LogFactory.getLog( XidImpl.class );

    private static final String SEPARATOR = ".";

    private final int formatId;
    private final byte[] globalTransactionId;
    private final byte[] branchQualifier;

    XidImpl( final String encodedXid ) throws DropboxTransaction.TransactionException
    {
        LogHelper.logMethod( log, toObjectString(), "XidImpl(), encodedXid = " + encodedXid );
        final int firstDot = encodedXid.indexOf( SEPARATOR );
        final int lastDot = encodedXid.lastIndexOf( SEPARATOR );
        if ( firstDot == -1 || lastDot == -1 || firstDot == lastDot )
        {
            throw new DropboxTransaction.TransactionException(
                    "Encoded Xid information is corrupt, encodedXid = " + encodedXid );
        }

        final String formatIdString = encodedXid.substring( 0, firstDot );
        final String globalTransactionString = encodedXid.substring( firstDot + 1, lastDot );
        final String branchQualifierString = encodedXid.substring( lastDot + 1 );

        try
        {
            formatId = Integer.parseInt( formatIdString );
        }
        catch ( NumberFormatException e )
        {
            throw new DropboxTransaction.TransactionException( e );
        }
        globalTransactionId = decodeBytes( globalTransactionString );
        branchQualifier = decodeBytes( branchQualifierString );
    }

    static byte[] decodeBytes( final String encodedBytes ) throws DropboxTransaction.TransactionException
    {
        if ( encodedBytes.length() % 2 != 0 )
        {
            throw new DropboxTransaction.TransactionException(
                    "Encoded Xid information is corrupt, encodedBytes = " + encodedBytes );
        }

        final byte[] bytes;
        try
        {
            bytes = new byte[ encodedBytes.length() >> 1 ];
            for ( int i = 0; i < bytes.length; i++ )
            {
                bytes[ i ] = Integer.valueOf( encodedBytes.substring( i << 1, ( i << 1 ) + 2 ), 16 ).byteValue();
            }
        }
        catch ( NumberFormatException e )
        {
            throw new DropboxTransaction.TransactionException( e );
        }

        return bytes;
    }

    public int getFormatId()
    {
        LogHelper.logMethod( log, toObjectString(), "getFormatId() = " + formatId );
        return formatId;
    }

    public byte[] getGlobalTransactionId()
    {
        LogHelper.logMethod( log, toObjectString(), "getGlobalTransactionId() = " + globalTransactionId );
        final byte[] globalTransactionIdCopy = new byte[ globalTransactionId.length ];
        System.arraycopy( globalTransactionId, 0, globalTransactionIdCopy, 0, globalTransactionId.length );
        return globalTransactionIdCopy;
    }

    public byte[] getBranchQualifier()
    {
        LogHelper.logMethod( log, toObjectString(), "getBranchQualifier() = " + branchQualifier );
        final byte[] branchQualifierCopy = new byte[ branchQualifier.length ];
        System.arraycopy( branchQualifier, 0, branchQualifierCopy, 0, branchQualifier.length );
        return branchQualifierCopy;
    }

    public static String encode( final Xid xid )
    {
        return xid.getFormatId()
                + SEPARATOR + encodeBytes( xid.getGlobalTransactionId() )
                + SEPARATOR + encodeBytes( xid.getBranchQualifier() );
    }

    static String encodeBytes( final byte[] bytes )
    {
        final StringBuffer buffer = new StringBuffer();

        for ( int i = 0; i < bytes.length; i++ )
        {
            final byte b = bytes[ i ];
            buffer.append( encodeNibble( b >> 4 ) ).append( encodeNibble( (int)b ) );
        }

        return buffer.toString();
    }

    static char encodeNibble( final int nibble )
    {
        final int modNibble = nibble % 16;
        final int shiftNibble = modNibble < 0 ? modNibble + 16 : modNibble;
        final char c;
        if ( shiftNibble < 10 )
        {
            c = (char)( (int)'0' + shiftNibble );
        }
        else
        {
            c = (char)( (int)'A' - 10 + shiftNibble );
        }

        return c;
    }

    protected final String toObjectString()
    {
        return super.toString();
    }
}
