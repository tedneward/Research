/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq;

import java.io.File;
import java.io.Serializable;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Iterator;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.naming.NamingException;
import javax.resource.spi.InvalidPropertyException;
import net.sf.dropboxmq.messagetranscoders.DefaultMessageTranscoderFactory;
import net.sf.dropboxmq.messagetranscoders.MessageTranscoderFactory;
import net.sf.dropboxmq.resource.spi.CommonBean;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 12 Mar 2006
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 226 $, $Date: 2011-03-05 20:51:47 -0700 (Sat, 05 Mar 2011) $
 */
public class Configuration implements Serializable
{
    private static final long serialVersionUID = -6524713483359305719L;

    private static final Log log = LogFactory.getLog( Configuration.class );

    public static final String PACKAGE = "net.sf.dropboxmq.";

    public static final String INITIAL_CONTEXT_FACTORY = PACKAGE + "jndi.InitialContextFactoryImpl";

    public static final String CONNECTION_FACTORIES_PROPERTY = PACKAGE + "connectionFactories";
    public static final String QUEUE_CONNECTION_FACTORIES_PROPERTY = PACKAGE + "queueConnectionFactories";
    public static final String TOPIC_CONNECTION_FACTORIES_PROPERTY = PACKAGE + "topicConnectionFactories";
    public static final String XA_CONNECTION_FACTORIES_PROPERTY = PACKAGE + "xaConnectionFactories";
    public static final String XA_QUEUE_CONNECTION_FACTORIES_PROPERTY = PACKAGE + "xaQueueConnectionFactories";
    public static final String XA_TOPIC_CONNECTION_FACTORIES_PROPERTY = PACKAGE + "xaTopicConnectionFactories";

    public static final String DEFAULT_CONNECTION_FACTORY_NAME = "ConnectionFactory";
    public static final String DEFAULT_QUEUE_CONNECTION_FACTORY_NAME = "QueueConnectionFactory";
    public static final String DEFAULT_TOPIC_CONNECTION_FACTORY_NAME = "TopicConnectionFactory";
    public static final String DEFAULT_XA_CONNECTION_FACTORY_NAME = "XAConnectionFactory";
    public static final String DEFAULT_XA_QUEUE_CONNECTION_FACTORY_NAME = "XAQueueConnectionFactory";
    public static final String DEFAULT_XA_TOPIC_CONNECTION_FACTORY_NAME = "XATopicConnectionFactory";

    public static final String ROOT_PROPERTY = PACKAGE + "root";
    public static final String CLIENT_ID_PROPERTY = PACKAGE + "clientId";
    public static final String POLLING_INTERVAL_PROPERTY = PACKAGE + "pollingInterval";
    public static final String TARGET_SCAN_TIMEOUT_PROPERTY = PACKAGE + "targetScanTimeout";
    public static final String MESSAGE_TRANSCODER_FACTORY_PROPERTY = PACKAGE + "messageTranscoderFactory";
    public static final String REDELIVERY_ATTEMPTS_PROPERTY = PACKAGE + "redeliveryAttempts";
    public static final String DELETE_PROCESSED_MESSAGES_PROPERTY = PACKAGE + "deleteProcessedMessages";
    public static final String DELETE_EXPIRED_MESSAGES_PROPERTY = PACKAGE + "deleteExpiredMessages";
    public static final String DELETE_COMPLETED_TRANSACTIONS_PROPERTY = PACKAGE + "deleteCompleteTransactions";
    public static final String PRESERVE_DELETED_DROPBOXES_PROPERTY = PACKAGE + "preserveDeletedDropboxes";
    public static final String CONSUME_EXPIRED_MESSAGES_PROPERTY = PACKAGE + "consumeExpiredMessages";

    public static final long POLLING_INTERVAL_DEFAULT = 300L;
    public static final long TARGET_SCAN_TIMEOUT_DEFAULT = 30L * 1000L;
    public static final int REDELIVERY_ATTEMPTS_DEFAULT = 0;
    public static final boolean DELETE_PROCESSED_MESSAGES_DEFAULT = false;
    public static final boolean DELETE_EXPIRED_MESSAGES_DEFAULT = false;
    public static final boolean DELETE_COMPLETE_TRANSACTIONS_DEFAULT = true;
    public static final boolean PRESERVE_DELETED_DROPBOXES_DEFAULT = true;
    public static final boolean CONSUME_EXPIRED_MESSAGES_DEFAULT = false;

    private final Set connectionFactories;
    private final Set queueConnectionFactories;
    private final Set topicConnectionFactories;
    private final Set xaConnectionFactories;
    private final Set xaQueueConnectionFactories;
    private final Set xaTopicConnectionFactories;
    private final File rootDir;
    private final String clientId;
    private final long pollingInterval;
    private final long targetScanTimeout;
    private final String messageTranscoderFactoryName;
    private final int redeliveryAttempts;
    private final boolean deleteProcessedMessages;
    private final boolean deleteExpiredMessages;
    private final boolean deleteCompleteTransactions;
    private final boolean preserveDeletedDropboxes;
    private final boolean consumeExpiredMessages;

    public Configuration( final Map environment ) throws NamingException
    {
        final Properties updatedEnvironment = lookupSubPropertiesForProperties( environment );

        connectionFactories = getConnectionFactories(
                CONNECTION_FACTORIES_PROPERTY, updatedEnvironment, DEFAULT_CONNECTION_FACTORY_NAME );
        queueConnectionFactories = getConnectionFactories(
                QUEUE_CONNECTION_FACTORIES_PROPERTY, updatedEnvironment, DEFAULT_QUEUE_CONNECTION_FACTORY_NAME );
        topicConnectionFactories = getConnectionFactories(
                TOPIC_CONNECTION_FACTORIES_PROPERTY, updatedEnvironment, DEFAULT_TOPIC_CONNECTION_FACTORY_NAME );
        xaConnectionFactories = getConnectionFactories(
                XA_CONNECTION_FACTORIES_PROPERTY, updatedEnvironment, DEFAULT_XA_CONNECTION_FACTORY_NAME );
        xaQueueConnectionFactories = getConnectionFactories(
                XA_QUEUE_CONNECTION_FACTORIES_PROPERTY, updatedEnvironment, DEFAULT_XA_QUEUE_CONNECTION_FACTORY_NAME );
        xaTopicConnectionFactories = getConnectionFactories(
                XA_TOPIC_CONNECTION_FACTORIES_PROPERTY, updatedEnvironment, DEFAULT_XA_TOPIC_CONNECTION_FACTORY_NAME );

        final String root = (String)updatedEnvironment.get( ROOT_PROPERTY );
        if ( root == null )
        {
            throw new NamingException( "Property " + ROOT_PROPERTY + " must be defined" );
        }

        rootDir = new File( root );

        clientId = getStringProperty( CLIENT_ID_PROPERTY, null, updatedEnvironment );

        pollingInterval = getLongProperty( POLLING_INTERVAL_PROPERTY, POLLING_INTERVAL_DEFAULT, updatedEnvironment );

        targetScanTimeout = getLongProperty(
                TARGET_SCAN_TIMEOUT_PROPERTY, TARGET_SCAN_TIMEOUT_DEFAULT, updatedEnvironment );

        messageTranscoderFactoryName = (String)updatedEnvironment.get( MESSAGE_TRANSCODER_FACTORY_PROPERTY );

        redeliveryAttempts = (int)getLongProperty(
                REDELIVERY_ATTEMPTS_PROPERTY, (long)REDELIVERY_ATTEMPTS_DEFAULT, updatedEnvironment );

        deleteProcessedMessages = getBooleanProperty(
                DELETE_PROCESSED_MESSAGES_PROPERTY, DELETE_PROCESSED_MESSAGES_DEFAULT, updatedEnvironment );

        deleteExpiredMessages = getBooleanProperty(
                DELETE_EXPIRED_MESSAGES_PROPERTY, DELETE_EXPIRED_MESSAGES_DEFAULT, updatedEnvironment );

        deleteCompleteTransactions = getBooleanProperty(
                DELETE_COMPLETED_TRANSACTIONS_PROPERTY, DELETE_COMPLETE_TRANSACTIONS_DEFAULT, updatedEnvironment );

        preserveDeletedDropboxes = getBooleanProperty(
                PRESERVE_DELETED_DROPBOXES_PROPERTY, PRESERVE_DELETED_DROPBOXES_DEFAULT, updatedEnvironment );

        consumeExpiredMessages = getBooleanProperty(
                CONSUME_EXPIRED_MESSAGES_PROPERTY, CONSUME_EXPIRED_MESSAGES_DEFAULT, updatedEnvironment );

        LogHelper.logMethod( log, toObjectString(), "Configuration(), environment = " + updatedEnvironment );
    }

    public Configuration( final CommonBean primaryBean, final CommonBean resourceAdapter )
            throws InvalidPropertyException
    {
        connectionFactories = Collections.EMPTY_SET;
        queueConnectionFactories = Collections.EMPTY_SET;
        topicConnectionFactories = Collections.EMPTY_SET;
        xaConnectionFactories = Collections.EMPTY_SET;
        xaQueueConnectionFactories = Collections.EMPTY_SET;
        xaTopicConnectionFactories = Collections.EMPTY_SET;

        final String rootDirString = (String)getValue( primaryBean.getRoot(), resourceAdapter.getRoot(), null );
        if ( rootDirString == null )
        {
            throw new InvalidPropertyException( "The root property is not set." );
        }
        rootDir = new File( rootDirString );

        clientId = null;

        pollingInterval = ( (Number)getValue( primaryBean.getPollingInterval(),
                resourceAdapter.getPollingInterval(), new Long( POLLING_INTERVAL_DEFAULT ) ) ).longValue();

        targetScanTimeout = ( (Number)getValue( primaryBean.getTargetScanTimeout(),
                resourceAdapter.getTargetScanTimeout(), new Long( TARGET_SCAN_TIMEOUT_DEFAULT ) ) ).longValue();

        messageTranscoderFactoryName = (String)getValue( primaryBean.getMessageTranscoderFactory(),
                resourceAdapter.getMessageTranscoderFactory(), null );

        redeliveryAttempts = ( (Number)getValue( primaryBean.getRedeliveryAttempts(),
                resourceAdapter.getRedeliveryAttempts(), new Integer( REDELIVERY_ATTEMPTS_DEFAULT ) ) ).intValue();

        deleteProcessedMessages = ( (Boolean)getValue( primaryBean.isDeleteProcessedMessages(),
                resourceAdapter.isDeleteProcessedMessages(),
                Boolean.valueOf( DELETE_PROCESSED_MESSAGES_DEFAULT ) ) ).booleanValue();

        deleteExpiredMessages = ( (Boolean)getValue( primaryBean.isDeleteExpiredMessages(),
                resourceAdapter.isDeleteExpiredMessages(),
                Boolean.valueOf( DELETE_EXPIRED_MESSAGES_DEFAULT ) ) ).booleanValue();

        deleteCompleteTransactions = ( (Boolean)getValue( primaryBean.isDeleteCompleteTransactions(),
                resourceAdapter.isDeleteCompleteTransactions(),
                Boolean.valueOf( DELETE_COMPLETE_TRANSACTIONS_DEFAULT ) ) ).booleanValue();

        preserveDeletedDropboxes = ( (Boolean)getValue( primaryBean.isPreserveDeletedDropboxes(),
                resourceAdapter.isPreserveDeletedDropboxes(),
                Boolean.valueOf( PRESERVE_DELETED_DROPBOXES_DEFAULT ) ) ).booleanValue();

        consumeExpiredMessages = ( (Boolean)getValue( primaryBean.isConsumeExpiredMessages(),
                resourceAdapter.isConsumeExpiredMessages(),
                Boolean.valueOf( CONSUME_EXPIRED_MESSAGES_DEFAULT ) ) ).booleanValue();

        LogHelper.logMethod( log, toObjectString(), "Configuration(), primaryBean = " + primaryBean
                + ", resourceAdapter = " + resourceAdapter );
    }

    public static Properties lookupSubPropertiesForProperties( final Map properties )
    {
        final Properties updatedProperties = new Properties();
        for ( Iterator iterator = properties.keySet().iterator(); iterator.hasNext(); )
        {
            String key = (String)iterator.next();
            updatedProperties.put( key, lookupSubProperties( (String)properties.get( key ) ) );
        }
        return updatedProperties;
    }

    private static final Pattern SUB_PROPERTY_PATTERN = Pattern.compile( "\\$\\{[^\\$\\{\\}]*\\}" );

    public static String lookupSubProperties( final String value )
    {
        String processedValue = value;
        final Set unknownKeys = new HashSet();
        boolean done = false;
        while ( !done )
        {
            final Matcher matcher = SUB_PROPERTY_PATTERN.matcher( processedValue );

            boolean innerFound = false;
            boolean innerDone = false;
            while ( !innerDone )
            {
                if ( matcher.find() )
                {
                    final String key = processedValue.substring( matcher.start() + 2, matcher.end() - 1 );
                    if ( !unknownKeys.contains( key ) )
                    {
                        innerFound = true;
                        final String systemValue = System.getProperty( key );
                        if ( systemValue == null )
                        {
                            unknownKeys.add( key );
                        }
                        else
                        {
                            processedValue = processedValue.substring( 0, matcher.start() ) + systemValue
                                    + processedValue.substring( matcher.end() );
                        }
                    }
                }
                else
                {
                    innerDone = true;
                }
            }

            if ( !innerFound )
            {
                done = true;
            }
        }
        return processedValue;
    }

    private static Object getValue(
            final Object primaryValue, final Object resourceAdapterValue, final Object defaultValue )
    {
        Object value = primaryValue;
        if ( value == null )
        {
            value = resourceAdapterValue;
            if ( value == null )
            {
                value = defaultValue;
            }
        }
        return value;
    }

    private static Set getConnectionFactories( final String connectionFactoriesProperty, final Map environment,
            final String defaultName )
    {
        final String connectionFactoriesString = (String)environment.get( connectionFactoriesProperty );
        return getConnectionFactoriesFromValue( connectionFactoriesString, defaultName );
    }

    private static Set getConnectionFactoriesFromValue( final String connectionFactoriesString,
            final String defaultName )
    {
        final Set foundConnectionFactories = new HashSet();

        if ( connectionFactoriesString == null )
        {
            foundConnectionFactories.add( defaultName );
        }
        else
        {
            final StringTokenizer tokenizer = new StringTokenizer( connectionFactoriesString, File.pathSeparator );
            while ( tokenizer.hasMoreTokens() )
            {
                final String connectionFactory = tokenizer.nextToken();
                foundConnectionFactories.add( connectionFactory );
            }
        }

        return Collections.unmodifiableSet( foundConnectionFactories );
    }

    private static String getStringProperty( final String name, final String defaultValue, final Map environment )
    {
        String value = (String)environment.get( name );
        log.debug( "name = " + name + ", value = " + value );
        if ( value == null || value.length() == 0 )
        {
            log.debug( "Using default value, defaultValue = " + defaultValue );
            value = defaultValue;
        }

        return value;
    }

    private static boolean getBooleanProperty( final String name, final boolean defaultValue, final Map environment )
    {
        final String stringValue = (String)environment.get( name );
        log.debug( "name = " + name + ", stringValue = " + stringValue + ", defaultValue = " + defaultValue );
        boolean value = defaultValue;
        if ( stringValue != null && stringValue.length() > 0 )
        {
            value = Boolean.valueOf( stringValue ).booleanValue();
            log.debug( "Using assigned value, value = " + value );
        }

        return value;
    }

    private static long getLongProperty( final String name, final long defaultValue, final Map environment )
    {
        final String stringValue = (String)environment.get( name );
        log.debug( "name = " + name + ", stringValue = " + stringValue + ", defaultValue = " + defaultValue );
        long value = defaultValue;
        if ( stringValue != null && stringValue.length() > 0 )
        {
            value = Long.parseLong( stringValue );
            log.debug( "Using assigned value, value = " + value );
        }

        return value;
    }

    public boolean doesConnectionFactoryExist( final String name )
    {
        return connectionFactories.contains( name );
    }

    public boolean doesQueueConnectionFactoryExist( final String name )
    {
        return queueConnectionFactories.contains( name );
    }

    public boolean doesTopicConnectionFactoryExist( final String name )
    {
        return topicConnectionFactories.contains( name );
    }

    public boolean doesXAConnectionFactoryExist( final String name )
    {
        return xaConnectionFactories.contains( name );
    }

    public boolean doesXAQueueConnectionFactoryExist( final String name )
    {
        return xaQueueConnectionFactories.contains( name );
    }

    public boolean doesXATopicConnectionFactoryExist( final String name )
    {
        return xaTopicConnectionFactories.contains( name );
    }

    public File getRootDir()
    {
        return rootDir;
    }

    public String getClientId()
    {
        return clientId;
    }

    public long getPollingInterval()
    {
        return pollingInterval;
    }

    public long getTargetScanTimeout()
    {
        return targetScanTimeout;
    }

    public int getRedeliveryAttempts()
    {
        return redeliveryAttempts;
    }

    public boolean isDeleteProcessedMessages()
    {
        return deleteProcessedMessages;
    }

    public boolean isDeleteExpiredMessages()
    {
        return deleteExpiredMessages;
    }

    public boolean isDeleteCompleteTransactions()
    {
        return deleteCompleteTransactions;
    }

    public boolean isPreserveDeletedDropboxes()
    {
        return preserveDeletedDropboxes;
    }

    public boolean isConsumeExpiredMessages()
    {
        return consumeExpiredMessages;
    }

    public MessageTranscoderFactory getMessageTranscoderFactory()
    {
        MessageTranscoderFactory factory = null;
        if ( messageTranscoderFactoryName != null && messageTranscoderFactoryName.length() > 0 )
        {
            try
            {
                final Class factoryClass
                        = Thread.currentThread().getContextClassLoader().loadClass( messageTranscoderFactoryName );
                factory = (MessageTranscoderFactory)factoryClass.newInstance();
            }
            catch ( ClassNotFoundException e )
            {
                log.warn( "Could not load message transcoder class specified by " + MESSAGE_TRANSCODER_FACTORY_PROPERTY
                        + " = " + messageTranscoderFactoryName, e );
            }
            catch ( IllegalAccessException e )
            {
                log.warn( "Could not load message transcoder class specified by " + MESSAGE_TRANSCODER_FACTORY_PROPERTY
                        + " = " + messageTranscoderFactoryName, e );
            }
            catch ( InstantiationException e )
            {
                log.warn( "Could not load message transcoder class specified by " + MESSAGE_TRANSCODER_FACTORY_PROPERTY
                        + " = " + messageTranscoderFactoryName, e );
            }
            catch ( ClassCastException e )
            {
                log.warn( "Could not load message transcoder class specified by " + MESSAGE_TRANSCODER_FACTORY_PROPERTY
                        + " = " + messageTranscoderFactoryName, e );
            }
        }

        if ( factory == null )
        {
            factory = new DefaultMessageTranscoderFactory();
        }

        return factory;
    }

    public FileSystem getFileSystem()
    {
        return new FileSystem();
    }

    public boolean equals( final Object obj )
    {
        if ( this == obj )
        {
            return true;
        }
        if ( obj == null || getClass() != obj.getClass() )
        {
            return false;
        }

        final Configuration that = (Configuration)obj;

        if ( deleteProcessedMessages != that.deleteProcessedMessages )
        {
            return false;
        }
        if ( deleteExpiredMessages != that.deleteExpiredMessages )
        {
            return false;
        }
        if ( deleteCompleteTransactions != that.deleteCompleteTransactions )
        {
            return false;
        }
        if ( preserveDeletedDropboxes != that.preserveDeletedDropboxes )
        {
            return false;
        }
        if ( consumeExpiredMessages != that.consumeExpiredMessages )
        {
            return false;
        }
        if ( redeliveryAttempts != that.redeliveryAttempts )
        {
            return false;
        }
        if ( pollingInterval != that.pollingInterval )
        {
            return false;
        }
        if ( targetScanTimeout != that.targetScanTimeout )
        {
            return false;
        }
        if ( !connectionFactories.equals( that.connectionFactories ) )
        {
            return false;
        }
        if ( messageTranscoderFactoryName != null
                ? !messageTranscoderFactoryName.equals( that.messageTranscoderFactoryName )
                : that.messageTranscoderFactoryName != null )
        {
            return false;
        }
        if ( !queueConnectionFactories.equals( that.queueConnectionFactories ) )
        {
            return false;
        }
        if ( !rootDir.equals( that.rootDir ) )
        {
            return false;
        }
        if ( !topicConnectionFactories.equals( that.topicConnectionFactories ) )
        {
            return false;
        }
        if ( !xaConnectionFactories.equals( that.xaConnectionFactories ) )
        {
            return false;
        }
        if ( !xaQueueConnectionFactories.equals( that.xaQueueConnectionFactories ) )
        {
            return false;
        }
        if ( !xaTopicConnectionFactories.equals( that.xaTopicConnectionFactories ) )
        {
            return false;
        }

        return true;
    }

    public int hashCode()
    {
        int result;
        result = connectionFactories.hashCode();
        result = 31 * result + queueConnectionFactories.hashCode();
        result = 31 * result + topicConnectionFactories.hashCode();
        result = 31 * result + xaConnectionFactories.hashCode();
        result = 31 * result + xaQueueConnectionFactories.hashCode();
        result = 31 * result + xaTopicConnectionFactories.hashCode();
        result = 31 * result + rootDir.hashCode();
        result = 31 * result + (int)( pollingInterval ^ pollingInterval >>> 32 );
        result = 31 * result + (int)( targetScanTimeout ^ targetScanTimeout >>> 32 );
        result = 31 * result + ( messageTranscoderFactoryName != null ? messageTranscoderFactoryName.hashCode() : 0 );
        result = 31 * result + redeliveryAttempts;
        result = 31 * result + ( deleteProcessedMessages ? 1 : 0 );
        result = 31 * result + ( deleteExpiredMessages ? 1 : 0 );
        result = 31 * result + ( deleteCompleteTransactions ? 1 : 0 );
        result = 31 * result + ( preserveDeletedDropboxes ? 1 : 0 );
        result = 31 * result + ( consumeExpiredMessages ? 1 : 0 );
        return result;
    }

    protected final String toObjectString()
    {
        return super.toString();
    }
}
