/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.messageconsumers;

import java.io.IOException;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import net.sf.dropboxmq.Dropbox;
import net.sf.dropboxmq.DropboxMQJMSException;
import net.sf.dropboxmq.MessageListenerRunnable;
import net.sf.dropboxmq.LogHelper;
import net.sf.dropboxmq.FileSystem;
import net.sf.dropboxmq.destinations.DestinationImpl;
import net.sf.dropboxmq.sessions.SessionImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 10 Mar 2006
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 231 $, $Date: 2011-08-12 21:50:47 -0600 (Fri, 12 Aug 2011) $
 */
public abstract class MessageConsumerImpl implements MessageConsumer
{
    private static final Log log = LogFactory.getLog(MessageConsumerImpl.class);

    private final boolean durable;
    private final Dropbox dropbox;
    private MessageListener messageListener = null;
    private MessageListenerRunnable messageListenerRunnable = null;
    private Thread messageListenerThread = null;
    private boolean started = false;
    private boolean closed = false;

    protected MessageConsumerImpl(final SessionImpl session, final DestinationImpl destination,
            final String messageSelector, final String subscriptionName, final boolean durable, final boolean noLocal)
            throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "MessageConsumerImpl(), session = " + session
                + ", destination = " + destination + ", messageSelector = " + messageSelector
                + ", subscriptionName = " + subscriptionName + ", durable = " + durable + ", noLocal = " + noLocal);
        this.durable = durable;
        dropbox = session.newDropbox(destination, messageSelector, subscriptionName, noLocal);
    }

    public String getMessageSelector() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "getMessageSelector()");
        return dropbox.getMessageSelector();
    }

    public MessageListener getMessageListener() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "getMessageListener() = " + messageListener);
        return messageListener;
    }

    public void setMessageListener(final MessageListener listener) throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "setMessageListener(), listener = " + listener);
        if (closed)
        {
            throw new JMSException("MessageConsumer must not be closed when setting the MessageListener");
        }

        final boolean wasStarted = started;
        if (wasStarted)
        {
            stop();
        }

        messageListener = listener;

        if (wasStarted)
        {
            start();
        }
    }

    public Message receive() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "receive()");
        try
        {
            return started ? dropbox.receive() : null;
        }
        catch (IOException e)
        {
            throw new DropboxMQJMSException(e);
        }
        catch (FileSystem.FileSystemException e)
        {
            throw new DropboxMQJMSException(e);
        }
    }

    public Message receive(final long timeout) throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "receive(), timeout = " + timeout);
        try
        {
            return started ? dropbox.receive(timeout) : null;
        }
        catch (IOException e)
        {
            throw new DropboxMQJMSException(e);
        }
        catch (FileSystem.FileSystemException e)
        {
            throw new DropboxMQJMSException(e);
        }
    }

    public Message receiveNoWait() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "receiveNoWait()");
        try
        {
            return started ? dropbox.receiveNoWait() : null;
        }
        catch (IOException e)
        {
            throw new DropboxMQJMSException(e);
        }
        catch (FileSystem.FileSystemException e)
        {
            throw new DropboxMQJMSException(e);
        }
    }

    public void close() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "close()");
        stop();

        dropbox.close();
        closed = true;
        dropbox.getSession().removeMessageConsumer(this);
    }

    public void start() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "start()");
        if (closed)
        {
            throw new JMSException("Attempt to start a closed resource");
        }

        if (messageListener != null)
        {
            messageListenerRunnable = new MessageListenerRunnable(messageListener,
                    dropbox.getSession().newDropbox(dropbox.getDestination(), dropbox.getMessageSelector(),
                            dropbox.getSubscriptionName(), dropbox.isNoLocal()),
                    dropbox.getSession().getDropboxTransaction());
            messageListenerThread = new Thread(messageListenerRunnable);
            messageListenerThread.setName(
                    "MessageConsumer-" + dropbox.getDestination().getName() + "-" + messageListenerThread.getName());

            messageListenerThread.start();
        }
        started = true;
    }

    public void stop() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "stop()");

        if (messageListenerRunnable != null)
        {
            stopMessageListener();
            try
            {
                messageListenerThread.join();
            }
            catch (InterruptedException ignore)
            {
                // Ignore
            }
        }
        messageListenerRunnable = null;
        messageListenerThread = null;

        started = false;
    }

    /**
     * Allows for quicker two phase shutdown.
     */
    public void stopMessageListener()
    {
        LogHelper.logMethod(log, toObjectString(), "stopMessageListener()");
        if (messageListenerRunnable != null)
        {
            messageListenerRunnable.close();
        }
    }

    public String getSubscriptionName()
    {
        return dropbox.getSubscriptionName();
    }

    public boolean isDurable()
    {
        return durable;
    }

    public Dropbox getDropbox()
    {
        return dropbox;
    }

    public String toString()
    {
        return "[" + super.toString() + ", dropbox = " + dropbox + "]";
    }

    protected final String toObjectString()
    {
        return super.toString();
    }

}
