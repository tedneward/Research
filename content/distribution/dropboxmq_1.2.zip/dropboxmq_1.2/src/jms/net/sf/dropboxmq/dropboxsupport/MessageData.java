/*
 Copyright (c) 2010, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.dropboxsupport;

import javax.jms.JMSException;
import net.sf.dropboxmq.messages.MessageImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 15 Nov 2008
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 211 $, $Date: 2010-11-14 14:21:24 -0700 (Sun, 14 Nov 2010) $
 */
public class MessageData implements Comparable
{
    private static final Log log = LogFactory.getLog( MessageData.class );

    private final String messageFilename;
    private final int priority;
    private final long timestamp;
    private final int sequence;

    public MessageData( final String messageFilename, final MessageImpl message ) throws JMSException
    {
        this.messageFilename = messageFilename;
        priority = message.getJMSPriority();
        timestamp = message.getJMSTimestamp();
        sequence = message.getSequence();
    }

    public boolean equals( final Object obj )
    {
        if ( this == obj )
        {
            return true;
        }
        if ( obj == null || getClass() != obj.getClass() )
        {
            return false;
        }

        final MessageData that = (MessageData)obj;

        if ( priority != that.priority )
        {
            return false;
        }
        if ( sequence != that.sequence )
        {
            return false;
        }
        if ( timestamp != that.timestamp )
        {
            return false;
        }
        if ( !messageFilename.equals( that.messageFilename ) )
        {
            return false;
        }

        return true;
    }

    public int hashCode()
    {
        int result;
        result = messageFilename.hashCode();
        result = 31 * result + priority;
        result = 31 * result + (int)( timestamp ^ timestamp >>> 32 );
        result = 31 * result + sequence;
        return result;
    }

    public int compareTo( final Object o )
    {
        final MessageData that = (MessageData)o;

        final int diff;
        if ( priority != that.priority )
        {
            diff = that.priority - priority;
        }
        else if ( timestamp != that.timestamp )
        {
            diff = (int)( timestamp - that.timestamp );
        }
        else if ( sequence != that.sequence )
        {
            diff = sequence - that.sequence;
        }
        else
        {
            diff = messageFilename.compareTo( that.messageFilename );
        }

        return diff;
    }

    public String getMessageFilename()
    {
        return messageFilename;
    }

    public int getPriority()
    {
        return priority;
    }

    public long getTimestamp()
    {
        return timestamp;
    }

    public int getSequence()
    {
        return sequence;
    }

}
