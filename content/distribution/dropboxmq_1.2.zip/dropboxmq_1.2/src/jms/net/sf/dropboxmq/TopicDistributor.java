/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import javax.jms.JMSException;
import javax.jms.Session;
import javax.naming.NamingException;
import net.sf.dropboxmq.connections.ConnectionImpl;
import net.sf.dropboxmq.destinations.TopicImpl;
import net.sf.dropboxmq.dropboxsupport.DirectoryStructure;
import net.sf.dropboxmq.messages.MessageImpl;
import net.sf.dropboxmq.sessions.SessionImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 20 Mar 2006
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 231 $, $Date: 2011-08-12 21:50:47 -0600 (Fri, 12 Aug 2011) $
 */
public class TopicDistributor
{
    private static final Log log = LogFactory.getLog(TopicDistributor.class);

    private final Configuration configuration;
    private final FileSystem fileSystem;
    private final long pollingInterval;
    private final File topicRootDir;
    private final boolean daemonMode;
    private Thread masterThread = null;
    private final Map distributorThreads = new HashMap();
    private volatile boolean done = false;

    public static void main(final String[] args) throws NamingException, InterruptedException
    {
        log.trace("main(), args = " + args);
        boolean daemonMode = false;
        final Properties properties = new Properties();
        for (int i = 0; i < args.length; i++)
        {
            final String arg = args[i];
            if (arg.equalsIgnoreCase("-d") || arg.equalsIgnoreCase("--daemon-mode"))
            {
                daemonMode = true;
            }
            else if (arg.equalsIgnoreCase("-p") || arg.equalsIgnoreCase("--properties"))
            {
                new FileSystem().readPropertiesFile(new File(args[i + 1]), properties);
            }
            else if (arg.equalsIgnoreCase("-?") || arg.equalsIgnoreCase("-h") || arg.equalsIgnoreCase("--help"))
            {
                usage();
                System.exit(0);
            }
        }

        final Configuration configuration = new Configuration(properties);

        final TopicDistributor topicDistributor = new TopicDistributor(configuration, daemonMode);

        log.info("Starting...");

        if (daemonMode)
        {
            topicDistributor.registerShutdownRunner();

            topicDistributor.start();
            topicDistributor.masterThread.join();
        }
        else
        {
            topicDistributor.findNewTopics(topicDistributor.topicRootDir, "");
        }

        log.info("Exiting.");
    }

    private static void usage()
    {
        System.out.println("Usage:  java net.sf.dropboxmq.TopicDistributor [ options ]");
        System.out.println("    -p | --properties {properties file}");
        System.out.println("        Required.  Defines the JNDI properties file to use.");
        System.out.println("    -d | --daemon-mode");
        System.out.println("        Causes the TopicDistributor to run indefinitely (normally runs once then quits).");
        System.out.println("    -h | -? | --help");
        System.out.println("        Displays this help output then quits.");
    }

    private void registerShutdownRunner()
    {
        LogHelper.logMethod(log, toObjectString(), "registerShutdownRunner()");
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable()
        {
            public void run()
            {
                log.debug("Shutting down...");
                stop();
            }
        }));
    }

    public TopicDistributor(final Configuration configuration, final boolean daemonMode)
    {
        LogHelper.logMethod(log, toObjectString(), "TopicDistributor(), configuration = " + configuration);
        this.configuration = configuration;
        fileSystem = configuration.getFileSystem();
        pollingInterval = configuration.getPollingInterval();
        topicRootDir = new File(configuration.getRootDir(), DirectoryStructure.TOPIC_ROOT_SUB_DIR);
        this.daemonMode = daemonMode;
    }

    public void start()
    {
        LogHelper.logMethod(log, toObjectString(), "start()");
        final Runnable runnable = new Runnable()
        {
            public void run()
            {
                while (!done)
                {
                    try
                    {
                        Thread.sleep(pollingInterval);
                    }
                    catch (InterruptedException ignore)
                    {
                        // Continue until done is signalled
                    }
                    findNewTopics(topicRootDir, "");
                }

                try
                {
                    waitForDistributorThreads();
                }
                catch (InterruptedException ignore)
                {
                    // Finishing anyway
                }

                log.info("Master thread exiting.");
            }
        };
        masterThread = new Thread(runnable);
        masterThread.setName("TopicDistributor-master");
        masterThread.start();
    }

    private void waitForDistributorThreads() throws InterruptedException
    {
        for (Iterator iterator = distributorThreads.values().iterator(); iterator.hasNext();)
        {
            final Thread distributerThread = (Thread)iterator.next();
            distributerThread.join();
        }
    }

    public void stop()
    {
        LogHelper.logMethod(log, toObjectString(), "stop()");
        done = true;
        try
        {
            if (masterThread != null)
            {
                masterThread.join();
            }
        }
        catch (InterruptedException ignore)
        {
            // Stopped
        }
    }

    private void findNewTopics(final File topicDir, final String baseTopicName)
    {
        final File[] subDirs = topicDir.listFiles();
        for (int i = 0; subDirs != null && i < subDirs.length; i++)
        {
            final File subDir = subDirs[i];

            if (subDir.isDirectory() && subDir.getName().indexOf(DirectoryStructure.DELETED_NAME_PREFIX) == -1)
            {
                if (subDir.getName().equals(DirectoryStructure.TOPIC_INCOMING_DIR_NAME))
                {
                    if (!distributorThreads.containsKey(topicDir)
                            && fileSystem.exists(new File(subDir, DirectoryStructure.TARGET_DIR_NAME)))
                    {
                        if (daemonMode)
                        {
                            addDistributor(subDir.getParentFile(), baseTopicName);
                        }
                        else
                        {
                            distributeMessages(baseTopicName);
                        }
                    }
                }
                else
                {
                    String childBaseTopicName = baseTopicName;
                    if (childBaseTopicName.length() > 0)
                    {
                        childBaseTopicName += ".";
                    }
                    childBaseTopicName += subDir.getName();

                    findNewTopics(subDir, childBaseTopicName);
                }
            }
        }
    }

    private void addDistributor(final File topicDir, final String topicName)
    {
        LogHelper.logMethod(log, toObjectString(), "addDistributor(), topicDir = " + topicDir
                + ", topicName = " + topicName);
        final Runnable distributorRunnable = new Runnable()
        {
            public void run()
            {
                distributeMessages(topicName);

                log.info("Distributor thread exiting.");
            }
        };

        final Thread distributorThread = new Thread(distributorRunnable);
        distributorThread.setName("TopicDistributor-" + topicName);
        distributorThread.start();

        distributorThreads.put(topicDir, distributorThread);

        log.info("Added distributer for topic " + topicName);
    }

    private void distributeMessages(final String topicName)
    {
        final File topicDir = DirectoryStructure.getDropboxDir(new TopicImpl(topicName), configuration);

        final ConnectionImpl connection;
        try
        {
            connection = new ConnectionImpl(null, configuration);
        }
        catch (JMSException e)
        {
            throw new RuntimeException("Couldn't create connection", e);
        }
        final TopicImpl topic = new TopicImpl(topicName);
        final SessionImpl session;
        final Dropbox dropbox;
        try
        {
            session = (SessionImpl)connection.createSession(true, Session.SESSION_TRANSACTED);
            dropbox = session.newDropbox(topic, null, null, false);
        }
        catch (JMSException e)
        {
            Dropbox.throwRuntimeException(e);
            throw new RuntimeException(e);
        }

        if (daemonMode)
        {
            distributeMessages(session, dropbox, topicDir);
        }
        else
        {
            distributeMessagesNoWait(session, dropbox, topicDir);
        }
    }

    private void distributeMessages(final SessionImpl session, final Dropbox dropbox, final File topicDir)
    {
        while (!done && fileSystem.exists(topicDir))
        {
            MessageImpl message = null;
            try
            {
                message = getMessage(dropbox);
                if (message != null)
                {
                    log.info("Distributing " + message.getReadMessageFile());
                    distributeMessage(message.getReadMessageFile(), topicDir);
                    session.commit();
                }
            }
            catch (Throwable t)
            {
                log.error("Problem distributing, message = " + message, t);
                try
                {
                    session.rollback();
                }
                catch (JMSException e)
                {
                    log.error("JMSException while rolling back session after error", e);
                }
            }
        }
    }

    private void distributeMessagesNoWait(final SessionImpl session, final Dropbox dropbox, final File topicDir)
    {
        boolean iterationDone = false;
        while (!iterationDone)
        {
            MessageImpl message = null;
            try
            {
                message = getMessage(dropbox);
                if (message == null)
                {
                    iterationDone = true;
                }
                else
                {
                    log.info("Distributing " + message.getReadMessageFile());
                    distributeMessage(message.getReadMessageFile(), topicDir);
                    session.commit();
                }
            }
            catch (Throwable t)
            {
                log.error("Problem distributing, message = " + message, t);
                try
                {
                    session.rollback();
                }
                catch (JMSException e)
                {
                    log.error("JMSException while rolling back session after error", e);
                }
            }
        }
    }

    private MessageImpl getMessage(final Dropbox dropbox)
    {
        MessageImpl message = null;
        try
        {
            message = (MessageImpl)dropbox.receive(pollingInterval);
        }
        catch (IOException e)
        {
            log.error("IOException while receiving message", e);
        }
        catch (JMSException e)
        {
            log.error("JMSException while receiving message", e);
        }
        catch (FileSystem.FileSystemException e)
        {
            log.error("FileSystem.FileSystemException while receiving message", e);
        }

        return message;
    }

    private void distributeMessage(final File messageFile, final File topicDir) throws JMSException
    {
        new SubscriptionIterator()
        {
            void onSubscriptionDir(final File subscriptionDir) throws FileSystem.FileSystemException
            {
                final String messageFileName = messageFile.getName();
                final File workingFile = new File(
                        subscriptionDir, DirectoryStructure.WORKING_DIR_NAME + File.separator + messageFileName);
                final File targetFile = new File(
                        subscriptionDir, DirectoryStructure.TARGET_DIR_NAME + File.separator + messageFileName);
                fileSystem.copy(messageFile, workingFile);
                try
                {
                    fileSystem.move(workingFile, targetFile);
                }
                catch (FileSystem.FileSystemException e)
                {
                    throw new RuntimeException(e);
                }
            }
        }.iterate(topicDir, topicRootDir, false);
    }

    abstract static class SubscriptionIterator
    {
        void iterate(final File topicDir, final File topicRootDir, final boolean stopOnError) throws JMSException
        {
            File iterationTopicDir = topicDir;
            while (iterationTopicDir != null && !topicRootDir.equals(iterationTopicDir))
            {
                final File subscriptionsDir = new File(iterationTopicDir, DirectoryStructure.SUBSCRIPTIONS_DIR_NAME);
                // TODO:  Should call FileSystem.exists()
                if (subscriptionsDir.exists() && subscriptionsDir.isDirectory())
                {
                    final File[] subscriptionDirs = subscriptionsDir.listFiles();
                    for (int i = 0; i < subscriptionDirs.length; i++)
                    {
                        final File subscriptionDir = subscriptionDirs[i];
                        if (subscriptionDir.isDirectory()
                                && subscriptionDir.getName().indexOf(DirectoryStructure.DELETED_NAME_PREFIX) == -1)
                        {
                            try
                            {
                                onSubscriptionDir(subscriptionDir);
                            }
                            catch (Throwable e)
                            {
                                if (stopOnError)
                                {
                                    throw new DropboxMQJMSException(e);
                                }
                                else
                                {
                                    log.error("Error while delivering topic message", e);
                                }
                            }
                        }
                    }
                }

                iterationTopicDir = iterationTopicDir.getParentFile();
            }
        }

        abstract void onSubscriptionDir(final File subscriptionDir)
                throws IOException, JMSException, FileSystem.FileSystemException;
    }

    protected final String toObjectString()
    {
        return super.toString();
    }

}
