/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.jndi;

import java.util.Hashtable;
import javax.jms.Queue;
import javax.jms.Topic;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NameNotFoundException;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.OperationNotSupportedException;
import javax.resource.ResourceException;
import net.sf.dropboxmq.Configuration;
import net.sf.dropboxmq.LogHelper;
import net.sf.dropboxmq.connectionfactories.ConnectionFactoryImpl;
import net.sf.dropboxmq.destinations.QueueImpl;
import net.sf.dropboxmq.destinations.TopicImpl;
import net.sf.dropboxmq.dropboxsupport.DirectoryStructure;
import net.sf.dropboxmq.resource.spi.factories.ManagedConnectionFactoryImpl;
import net.sf.dropboxmq.resource.spi.factories.QueueManagedConnectionFactoryImpl;
import net.sf.dropboxmq.resource.spi.factories.TopicManagedConnectionFactoryImpl;
import net.sf.dropboxmq.resource.spi.factories.XAManagedConnectionFactoryImpl;
import net.sf.dropboxmq.resource.spi.factories.XAQueueManagedConnectionFactoryImpl;
import net.sf.dropboxmq.resource.spi.factories.XATopicManagedConnectionFactoryImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 09 Oct 2005
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 231 $, $Date: 2011-08-12 21:50:47 -0600 (Fri, 12 Aug 2011) $
 * @noinspection OverloadedMethodsWithSameNumberOfParameters
 */
public class ContextImpl implements Context
{
    private static final Log log = LogFactory.getLog(ContextImpl.class);

    private final Configuration configuration;
    private static final NamingEnumeration EMPTY_NAMING_ENUMERATION = new NamingEnumeration()
    {
        public Object next()
        {
            LogHelper.logMethod(log, toObjectString(), "next()");
            throw new UnsupportedOperationException();
        }

        public boolean hasMore()
        {
            LogHelper.logMethod(log, toObjectString(), "hasMore() = false");
            return false;
        }

        public void close()
        {
            LogHelper.logMethod(log, toObjectString(), "close()");
        }

        public boolean hasMoreElements()
        {
            LogHelper.logMethod(log, toObjectString(), "hasMoreElements() = false");
            return false;
        }

        public Object nextElement()
        {
            LogHelper.logMethod(log, toObjectString(), "nextElement()");
            throw new UnsupportedOperationException();
        }

        String toObjectString()
        {
            return super.toString();
        }
    };

    public ContextImpl(final Configuration configuration)
    {
        LogHelper.logMethod(log, toObjectString(), "ContextImpl(), configuration = " + configuration);

        this.configuration = configuration;
    }

    public Object lookup(final Name name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "lookup(Name), name = " + name);

        if (name != null && name.size() != 1)
        {
            throw new NameNotFoundException("Name not found, name = " + name);
        }

        final String nameString;
        if (name == null || name.isEmpty())
        {
            nameString = null;
        }
        else
        {
            nameString = name.get(0);
        }

        return lookup(nameString);
    }

    public Object lookup(final String name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "lookup(String), name = " + name);

        final Object o;

        if (name == null || name.length() == 0)
        {
            o = this;
        }
        else
        {
            final ConnectionFactoryImpl factory;
            try
            {
                factory = lookupConnectionFactory(name);
            }
            catch (ResourceException e)
            {
                throw new NamingException(e.getMessage());
            }
            final Queue queue = new QueueImpl(name);
            final boolean queueExists = DirectoryStructure.doesDropboxExist(queue, configuration);
            final Topic topic = new TopicImpl(name);
            final boolean topicExists = DirectoryStructure.doesDropboxExist(topic, configuration);

            if (queueExists && topicExists)
            {
                throw new NamingException("Both queue and topic exist with name " + name);
            }

            if (factory != null)
            {
                if (queueExists)
                {
                    throw new NamingException("Both connection factory and queue exist with name " + name);
                }
                else if (topicExists)
                {
                    throw new NamingException("Both connection factory and topic exist with name " + name);
                }
                o = factory;
            }
            else if (queueExists)
            {
                o = queue;
            }
            else if (topicExists)
            {
                o = topic;
            }
            else
            {
                throw new NameNotFoundException("Name not found, name = " + name);
            }
        }

        log.trace("o = " + o);
        return o;
    }

    private ConnectionFactoryImpl lookupConnectionFactory(final String name) throws ResourceException
    {
        Object factory = null;
        if (configuration.doesConnectionFactoryExist(name))
        {
            factory = new ManagedConnectionFactoryImpl(configuration).createConnectionFactory();
        }
        else if (configuration.doesQueueConnectionFactoryExist(name))
        {
            factory = new QueueManagedConnectionFactoryImpl(configuration).createConnectionFactory();
        }
        else if (configuration.doesTopicConnectionFactoryExist(name))
        {
            factory = new TopicManagedConnectionFactoryImpl(configuration).createConnectionFactory();
        }
        else if (configuration.doesXAConnectionFactoryExist(name))
        {
            factory = new XAManagedConnectionFactoryImpl(configuration).createConnectionFactory();
        }
        else if (configuration.doesXAQueueConnectionFactoryExist(name))
        {
            factory = new XAQueueManagedConnectionFactoryImpl(configuration).createConnectionFactory();
        }
        else if (configuration.doesXATopicConnectionFactoryExist(name))
        {
            factory = new XATopicManagedConnectionFactoryImpl(configuration).createConnectionFactory();
        }
        return (ConnectionFactoryImpl)factory;
    }

    public void bind(final Name name, final Object obj) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "bind(Name, Object), name = " + name + ", obj = " + obj);
        throw new OperationNotSupportedException();
    }

    public void bind(final String name, final Object obj) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "bind(String, Object), name = " + name + ", obj = " + obj);
        throw new OperationNotSupportedException();
    }

    public void rebind(final Name name, final Object obj) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "rebind(Name, Object), name = " + name + ", obj = " + obj);
        throw new OperationNotSupportedException();
    }

    public void rebind(final String name, final Object obj) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "rebind(String, Object), name = " + name + ", obj = " + obj);
        throw new OperationNotSupportedException();
    }

    public void unbind(final Name name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "unbind(Name), name = " + name);
        throw new OperationNotSupportedException();
    }

    public void unbind(final String name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "unbind(String), name = " + name);
        throw new OperationNotSupportedException();
    }

    public void rename(final Name oldName, final Name newName) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "rename(Name, Name), oldName = " + oldName
                + ", newName = " + newName);
        throw new OperationNotSupportedException();
    }

    public void rename(final String oldName, final String newName) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "rename(String, String), oldName = " + oldName
                + ", newName = " + newName);
        throw new OperationNotSupportedException();
    }

    public NamingEnumeration list(final Name name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "list(Name), name = " + name);
        return EMPTY_NAMING_ENUMERATION;
    }

    public NamingEnumeration list(final String name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "list(String), name = " + name);
        return EMPTY_NAMING_ENUMERATION;
    }

    public NamingEnumeration listBindings(final Name name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "listBindings(Name), name = " + name);
        return EMPTY_NAMING_ENUMERATION;
    }

    public NamingEnumeration listBindings(final String name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "listBindings(String), name = " + name);
        return EMPTY_NAMING_ENUMERATION;
    }

    public void destroySubcontext(final Name name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "destroySubcontext(Name), name = " + name);
        throw new OperationNotSupportedException();
    }

    public void destroySubcontext(final String name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "destroySubcontext(String), name = " + name);
        throw new OperationNotSupportedException();
    }

    public Context createSubcontext(final Name name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "createSubcontext(Name), name = " + name);
        throw new OperationNotSupportedException();
    }

    public Context createSubcontext(final String name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "createSubcontext(String), name = " + name);
        throw new OperationNotSupportedException();
    }

    public Object lookupLink(final Name name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "lookupLink(Name), name = " + name);
        throw new OperationNotSupportedException();
    }

    public Object lookupLink(final String name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "lookupLink(String), name = " + name);
        throw new OperationNotSupportedException();
    }

    public NameParser getNameParser(final Name name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "getNameParser(Name), name = " + name);
        throw new OperationNotSupportedException();
    }

    public NameParser getNameParser(final String name) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "getNameParser(String), name = " + name);
        throw new OperationNotSupportedException();
    }

    public Name composeName(final Name name, final Name prefix) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "composeName(Name, Name), name = " + name
                + ", prefix = " + prefix);
        throw new OperationNotSupportedException();
    }

    public String composeName(final String name, final String prefix) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "composeName(String, String), name = " + name
                + ", prefix = " + prefix);
        throw new OperationNotSupportedException();
    }

    public Object addToEnvironment(final String propName, final Object propVal) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "addToEnvironment(), propName = " + propName
                + ", propVal = " + propVal);
        throw new OperationNotSupportedException();
    }

    public Object removeFromEnvironment(final String propName) throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "removeFromEnvironment(), propName = " + propName);
        throw new OperationNotSupportedException();
    }

    public Hashtable getEnvironment() throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "getEnvironment()");
        throw new OperationNotSupportedException();
    }

    public void close() throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "close()");
    }

    public String getNameInNamespace() throws NamingException
    {
        LogHelper.logMethod(log, toObjectString(), "getNameInNamespace()");
        throw new OperationNotSupportedException();
    }

    protected final String toObjectString()
    {
        return super.toString();
    }

}
