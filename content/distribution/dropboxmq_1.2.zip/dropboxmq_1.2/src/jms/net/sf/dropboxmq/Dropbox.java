/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import javax.jms.JMSException;
import javax.jms.Message;
import net.sf.dropboxmq.connections.ConnectionImpl;
import net.sf.dropboxmq.destinations.DestinationImpl;
import net.sf.dropboxmq.destinations.QueueImpl;
import net.sf.dropboxmq.dropboxsupport.DirectoryStructure;
import net.sf.dropboxmq.dropboxsupport.Locks;
import net.sf.dropboxmq.dropboxsupport.MessageData;
import net.sf.dropboxmq.dropboxsupport.Router;
import net.sf.dropboxmq.messages.MessageImpl;
import net.sf.dropboxmq.messageselector.Expression;
import net.sf.dropboxmq.messageselector.Parser;
import net.sf.dropboxmq.messagetranscoders.DefaultMessageTranscoder;
import net.sf.dropboxmq.messagetranscoders.MessageTranscoder;
import net.sf.dropboxmq.messagetranscoders.MessageTranscoderFactory;
import net.sf.dropboxmq.sessions.SessionImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 09 Oct 2005
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 231 $, $Date: 2011-08-12 21:50:47 -0600 (Fri, 12 Aug 2011) $
 */
public class Dropbox
{
    private static final Log log = LogFactory.getLog(Dropbox.class);

    private final SessionImpl session;
    private final DestinationImpl destination;
    private String messageSelector = null;
    private Expression messageSelectorExpression = null;
    private String subscriptionName = null;
    private boolean noLocal = false;
    private final Configuration configuration;
    private final FileSystem fileSystem;
    private final String encodedClientId;
    private final DirectoryStructure structure;
    private final Locks locks;
    private final Router router;
    private final SortedSet targetFiles = new TreeSet();
    private final Set targetFilenames = new HashSet();
    private long targetScanTime = 0L;
    private Set selectorFilteredFilenames = new HashSet();
    private volatile boolean closed = false;
    private final MessageTranscoderFactory messageTranscoderFactory;

    public Dropbox(final SessionImpl session, final DestinationImpl destination, final String messageSelector,
            final String subscriptionName, final boolean noLocal, final Configuration configuration)
            throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "Dropbox(), session = " + session + ", destination = " + destination
                + ", messageSelector = " + messageSelector + ", subscriptionName = " + subscriptionName
                + ", noLocal = " + noLocal + ", configuration = " + configuration);
        this.session = session;
        this.destination = destination;
        this.messageSelector = messageSelector;
        this.subscriptionName = subscriptionName;
        this.noLocal = noLocal;
        this.configuration = configuration;
        fileSystem = configuration.getFileSystem();

        final String clientId = session.getConnection().getLocalClientID();
        structure = new DirectoryStructure(clientId, destination, subscriptionName, noLocal, configuration);
        encodedClientId = DefaultMessageTranscoder.encode(clientId);

        locks = new Locks(structure, destination.getName(), configuration);
        router = new Router(structure, fileSystem);

        messageTranscoderFactory = configuration.getMessageTranscoderFactory();

        if (messageSelector != null && messageSelector.length() > 0)
        {
            messageSelectorExpression = Parser.parse(messageSelector);
        }
    }

    public SessionImpl getSession()
    {
        LogHelper.logMethod(log, toObjectString(), "getSession()");
        return session;
    }

    public DestinationImpl getDestination()
    {
        LogHelper.logMethod(log, toObjectString(), "getDestination() = " + destination);
        return destination;
    }

    public String getMessageSelector()
    {
        LogHelper.logMethod(log, toObjectString(), "getMessageSelector() = " + messageSelector);
        return messageSelector;
    }

    public String getSubscriptionName()
    {
        LogHelper.logMethod(log, toObjectString(), "getSubscriptionName() = " + subscriptionName);
        return subscriptionName;
    }

    public boolean isNoLocal()
    {
        LogHelper.logMethod(log, toObjectString(), "isNoLocal() = " + noLocal);
        return noLocal;
    }

    public DirectoryStructure getStructure()
    {
        return structure;
    }

    public FileSystem getFileSystem()
    {
        return fileSystem;
    }

    public void close()
    {
        LogHelper.logMethod(log, toObjectString(), "close()");
        closed = true;
    }

    public void send(final Message message, final int priority, final long timeToLive)
            throws IOException, JMSException, FileSystem.FileSystemException
    {
        LogHelper.logMethod(log, toObjectString(), "send(), message = " + message + ", priority = " + priority
                + ", timeToLive = " + timeToLive);

        if (structure.getWorkingDir() == null)
        {
            throw new JMSException("Cannot produce to destination, check suffix, " + destination.getName());
        }

        final long current = System.currentTimeMillis();
        message.setJMSPriority(priority);
        if (timeToLive == Message.DEFAULT_TIME_TO_LIVE)
        {
            message.setJMSExpiration(0L);
        }
        else
        {
            final long expiration = current + timeToLive;
            message.setJMSExpiration(expiration);
        }

        final String messageID = session.getNewID();
        message.setJMSMessageID(DefaultMessageTranscoder.MESSAGE_ID_PREFIX + messageID);

        message.setJMSTimestamp(current);

        final String filename = encodeMetadata(message, messageID);
        if (filename.length() > DirectoryStructure.FILENAME_MAX_LENGTH)
        {
            log.warn("Message filename " + filename + " will most likely cause error, too long ("
                    + filename.length() + ")");
        }

        locks.checkWriteLock(current);

        final File messageFile = new File(structure.getWorkingDir(), filename);
        fileSystem.createNewFile(messageFile, false);

        final MessageImpl messageImpl;
        if (message instanceof MessageImpl)
        {
            messageImpl = (MessageImpl)message;
        }
        else
        {
            messageImpl = MessageImpl.convertForeignMessage(message, session);
        }

        messageImpl.write(messageFile, fileSystem);

        log.info("Wrote message to file " + messageFile + ", " + messageFile.length() + " bytes");

        final File commitFile;
        if (destination instanceof QueueImpl)
        {
            commitFile = new File(structure.getTargetDir(), filename);
        }
        else
        {
            commitFile = configuration.isDeleteProcessedMessages()
                    ? null : new File(structure.getProcessedDir(), filename);
            distributeTopicMessage(filename, messageImpl);
        }

        session.getDropboxTransaction().addSentMessage(messageFile, commitFile);

        message.setJMSDestination(destination);
    }

    private void distributeTopicMessage(final String filename, final MessageImpl message) throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "distributeTopicMessage(), filename = " + filename
                + ", message = " + message);

        final File topicRootDir = new File(configuration.getRootDir(), DirectoryStructure.TOPIC_ROOT_SUB_DIR);

        new TopicDistributor.SubscriptionIterator()
        {
            void onSubscriptionDir(final File subscriptionDir)
                    throws IOException, JMSException, FileSystem.FileSystemException
            {
                LogHelper.logMethod(log, toObjectString(), "onSubscriptionDir(), subscriptionDir = " + subscriptionDir);

                final String subscriptionId = subscriptionDir.getName();
                if (!subscriptionId.endsWith("." + encodedClientId + ".no-local"))
                {
                    final File subscriptionWorkingDir = new File(subscriptionDir, DirectoryStructure.WORKING_DIR_NAME);
                    final File subscriptionTargetDir = new File(subscriptionDir, DirectoryStructure.TARGET_DIR_NAME);

                    final File messageFile = new File(subscriptionWorkingDir, filename);
                    fileSystem.createNewFile(messageFile, false);

                    message.write(messageFile, fileSystem);

                    final File commitFile = new File(subscriptionTargetDir, filename);

                    session.getDropboxTransaction().addSentMessage(messageFile, commitFile);
                }
            }
        }.iterate(DirectoryStructure.getDropboxDir(destination, configuration), topicRootDir, true);
    }

    private String encodeMetadata(final Message message, final String messageID) throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "encodeMetadata(), message = " + message);

        final MessageTranscoder messageTranscoder
                = messageTranscoderFactory.getMessageTranscoder(destination, configuration);

        String filename = messageTranscoder.encodeMetadata(message);

        if (filename == null)
        {
            filename = messageID;
        }

        return filename;
    }

    public Message receive() throws JMSException, IOException, FileSystem.FileSystemException
    {
        LogHelper.logMethod(log, toObjectString(), "receive()");
        return receive(Long.MAX_VALUE);
    }

    public Message receive(final long timeout) throws JMSException, IOException, FileSystem.FileSystemException
    {
        Message message = null;

        final long pollingInterval = configuration.getPollingInterval();
        long count = 0L;
        final long iterations = timeout == 0L ? Long.MAX_VALUE : timeout / pollingInterval;

        boolean done = false;
        while (!done && !closed)
        {
            message = receiveNoWait();

            if (count < iterations && message == null)
            {
                count++;
                try
                {
                    Thread.sleep(pollingInterval);
                }
                catch (InterruptedException ignore)
                {
                    done = true;
                }
            }
            else
            {
                done = true;
            }
        }

        return message;
    }

    public Message receiveNoWait() throws IOException, JMSException, FileSystem.FileSystemException
    {
        if (structure.getProcessingDir() == null)
        {
            throw new JMSException("Cannot consume from destination, check suffix, " + destination.getName());
        }

        MessageImpl message = null;
        if (!locks.isReadLocked())
        {
            updateTargetFiles();

            while (message == null && !targetFiles.isEmpty())
            {
                final MessageData messageData = (MessageData)targetFiles.first();
                targetFiles.remove(messageData);

                targetFilenames.remove(messageData.getMessageFilename());

                final String processingFilename = calculateClientFilename(messageData.getMessageFilename());

                final File originalFile = new File(structure.getTargetDir(), messageData.getMessageFilename());
                final File messageFile = new File(structure.getProcessingDir(), processingFilename);
                boolean movedToProcessing = false;
                try
                {
                    fileSystem.move(originalFile, messageFile);
                    movedToProcessing = true;
                }
                catch (FileSystem.FileSystemException ignore)
                {
                    // Race lost?
                }

                if (movedToProcessing)
                {
                    try
                    {
                        message = startProcessing(messageFile, originalFile);
                    }
                    catch (FileSystem.FileSystemException e)
                    {
                        handleProcessingError(messageFile);
                        throw new DropboxMQJMSException(
                                "An error occurred while processing a message, file = " + messageFile, e);
                    }
                    catch (IOException e)
                    {
                        handleProcessingError(messageFile);
                        throw new DropboxMQJMSException(
                                "An error occurred while processing a message, file = " + messageFile, e);
                    }
                    catch (JMSException e)
                    {
                        handleProcessingError(messageFile);
                        throw e;
                    }
                }
            }
        }

        return message;
    }

    private static final String CLIENT_ID_SEPARATOR = "~";

    private String calculateClientFilename(final String messageFilename)
    {
        String clientFilename = encodedClientId + CLIENT_ID_SEPARATOR + getOriginalFilename(messageFilename);
        if (clientFilename.length() > DirectoryStructure.FILENAME_MAX_LENGTH)
        {
            log.warn("Processing filename " + clientFilename + " too long (" + clientFilename.length() + "),"
                    + " reverting to original filename " + messageFilename + ".  Multiple consumers may exhibit a race"
                    + " condition on network file systems.");
            clientFilename = messageFilename;
        }

        return clientFilename;
    }

    private String getOriginalFilename(final String messageFilename)
    {
        final int separatorIndex = messageFilename.indexOf(CLIENT_ID_SEPARATOR);
        String orginalFilename = messageFilename;
        if (separatorIndex != -1)
        {
            orginalFilename = orginalFilename.substring(separatorIndex + 1);
        }
        return orginalFilename;
    }

    private MessageImpl startProcessing(final File messageFile, final File originalFile)
            throws JMSException, IOException, FileSystem.FileSystemException
    {
        MessageImpl message = null;
        final MessageImpl newMessage = createMessage(messageFile);
        final boolean checkExpired = !configuration.isConsumeExpiredMessages() && structure.getExpiredDir() != null;
        if (checkExpired && newMessage.isExpired())
        {
            log.info("Processing expired message file " + messageFile);
            if (configuration.isDeleteExpiredMessages())
            {
                fileSystem.delete(messageFile);
            }
            else
            {
                fileSystem.move(messageFile, new File(structure.getExpiredDir(), messageFile.getName()));
            }
        }
        else
        {
            final boolean wasRouted = router.checkRouting(newMessage, messageFile);
            if (!wasRouted)
            {
                message = newMessage;
                message.read(messageFile, fileSystem);

                log.info("Read message from file " + messageFile + ", " + messageFile.length() + " bytes");

                String resultFilename = calculateClientFilename(encodeMetadata(message, message.getJMSMessageID()));

                final File commitFile = configuration.isDeleteProcessedMessages() ? null :
                        new File(structure.getProcessedDir(), resultFilename);

                final File errorDir;
                if (message.getIntProperty(ConnectionImpl.JMSX_DELIVERY_COUNT) > configuration.getRedeliveryAttempts())
                {
                    errorDir = structure.getErrorDir();
                }
                else
                {
                    errorDir = structure.getTargetDir();
                }

                session.getDropboxTransaction().addReceivedMessage(messageFile, originalFile, commitFile,
                        new File(errorDir, resultFilename));
            }
        }
        return message;
    }

    public MessageImpl createMessage(final File messageFile) throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "createMessage(), messageFile = " + messageFile);
        final MessageImpl message = decodeMetadata(messageFile, false);
        message.setJMSDestination(destination);

        final Integer deliveryCount = (Integer)message.getObjectProperty(ConnectionImpl.JMSX_DELIVERY_COUNT);
        int deliveryCountInt = 1;
        if (deliveryCount != null)
        {
            deliveryCountInt = deliveryCount.intValue() + 1;
            message.setJMSRedelivered(true);
        }
        message.setIntProperty(ConnectionImpl.JMSX_DELIVERY_COUNT, deliveryCountInt);

        return message;
    }

    private MessageImpl decodeMetadata(final File messageFile, final boolean priorityAndSelectorOnly)
            throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "decodeMetadata(), messageFile = " + messageFile
                + ", priorityAndSelectorOnly = " + priorityAndSelectorOnly);

        final MessageTranscoder messageTranscoder
                = messageTranscoderFactory.getMessageTranscoder(destination, configuration);
        final String originalFilename = getOriginalFilename(messageFile.getName());

        final SessionImpl receivedMessageFactorySession = new SessionImpl(session);
        MessageImpl message = null;
        try
        {
            message = (MessageImpl)messageTranscoder.decodeMetadata(receivedMessageFactorySession, messageFile,
                    originalFilename, priorityAndSelectorOnly, messageSelector);
        }
        // Only log exception so messages can always be consumed regardless of metadata errors
        catch (IOException e)
        {
            // if priorityAndSelectorOnly == true, file may have been consumed by another application
            if (!priorityAndSelectorOnly)
            {
                log.error("Error decoding metadata", e);
            }
        }
        catch (Throwable t)
        {
            log.error("Error decoding metadata", new Exception(t));
        }

        if (!priorityAndSelectorOnly && message == null)
        {
            try
            {
                message = (MessageImpl)new DefaultMessageTranscoder(configuration).decodeMetadata(
                        receivedMessageFactorySession, messageFile, originalFilename, priorityAndSelectorOnly,
                        messageSelector);
            }
            catch (Throwable t)
            {
                log.error("Error decoding metadata", new Exception(t));
            }

            if (message == null)
            {
                message = (MessageImpl)receivedMessageFactorySession.createTextMessage();
                message.setJMSMessageID(DefaultMessageTranscoder.MESSAGE_ID_PREFIX + messageFile.getName());
            }
        }

        return message;
    }

    private void updateTargetFiles() throws JMSException
    {
        if (targetFiles.isEmpty() || System.currentTimeMillis() - targetScanTime > configuration.getTargetScanTimeout())
        {
            final String[] currentTargetFilenames = structure.getTargetDir().list();
            if (currentTargetFilenames != null && currentTargetFilenames.length > 0)
            {
                log.trace("found " + currentTargetFilenames.length + " files");
            }

            if (currentTargetFilenames != null && currentTargetFilenames.length > 0)
            {
                final Set newSelectorFilteredFilenames = new HashSet();

                for (int i = 0; i < currentTargetFilenames.length; i++)
                {
                    final String targetFilename = currentTargetFilenames[i];

                    if (selectorFilteredFilenames.contains(targetFilename))
                    {
                        newSelectorFilteredFilenames.add(targetFilename);
                    }
                    else if (!targetFilenames.contains(targetFilename))
                    {
                        final MessageImpl message
                                = decodeMetadata(new File(structure.getTargetDir(), targetFilename), true);
                        if (message != null && isMessageSelected(message))
                        {
                            targetFiles.add(new MessageData(targetFilename, message));
                            targetFilenames.add(targetFilename);
                            log.trace("    selected currentTargetFilenames[" + i + "] = " + targetFilename
                                    + ", size = " + targetFiles.size());
                        }
                        else
                        {
                            newSelectorFilteredFilenames.add(targetFilename);
                            log.trace("not selected currentTargetFilenames[" + i + "] = " + targetFilename
                                    + ", size = " + targetFiles.size());
                        }
                    }
                }

                selectorFilteredFilenames = newSelectorFilteredFilenames;

                if (log.isTraceEnabled() && !targetFiles.isEmpty())
                {
                    log.trace("Message order:");
                    for (Iterator iterator = targetFiles.iterator(); iterator.hasNext();)
                    {
                        final MessageData messageData = (MessageData)iterator.next();
                        log.trace("  " + messageData.getPriority() + " " + messageData.getTimestamp()
                                + " " + messageData.getMessageFilename());
                    }
                }
            }

            targetScanTime = System.currentTimeMillis();
        }
    }

    private boolean isMessageSelected(final Message message)
    {
        return messageSelectorExpression == null || messageSelectorExpression.evaluate(message);
    }

    public List getCurrentTargetFiles() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "getCurrentTargetFiles()");

        updateTargetFiles();

        final List currentFiles = new ArrayList();
        for (Iterator iterator = targetFiles.iterator(); iterator.hasNext();)
        {
            final MessageData messageData = (MessageData)iterator.next();
            currentFiles.add(new File(structure.getTargetDir(), messageData.getMessageFilename()));
        }

        return currentFiles;
    }

    private void handleProcessingError(final File messageFile)
    {
        log.warn("Could not process message " + messageFile + ", attempting to move to error");
        try
        {
            fileSystem.move(messageFile, new File(structure.getErrorDir(), messageFile.getName()));
        }
        catch (FileSystem.FileSystemException ignore)
        {
            log.error("Failed to move message " + messageFile + " to error, leaving in processing");
        }
    }

    public static void throwRuntimeException(final String message)
    {
        log.debug(message);
        throw new RuntimeException(message);
    }

    public static void throwRuntimeException(final Throwable t)
    {
        log.debug("RuntimeException", t);
        throw new RuntimeException(t);
    }

    public static void throwRuntimeException(final String message, final Throwable t)
    {
        log.debug(message, t);
        throw new RuntimeException(message, t);
    }

    public String toString()
    {
        return "[" + super.toString() + ", targetDir = " + structure.getTargetDir() + "]";
    }

    protected final String toObjectString()
    {
        return super.toString();
    }

}
