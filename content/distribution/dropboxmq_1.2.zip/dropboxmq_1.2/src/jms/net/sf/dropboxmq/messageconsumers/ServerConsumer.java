/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.messageconsumers;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.Topic;
import net.sf.dropboxmq.connections.ConnectionImpl;
import net.sf.dropboxmq.destinations.DestinationImpl;
import net.sf.dropboxmq.messages.MessageImpl;
import net.sf.dropboxmq.sessions.SessionImpl;
import net.sf.dropboxmq.LogHelper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 07 Feb 2007
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 221 $, $Date: 2011-01-30 22:07:27 -0700 (Sun, 30 Jan 2011) $
 */
public abstract class ServerConsumer
{
    private static final Log log = LogFactory.getLog( ServerConsumer.class );

    private final ConnectionImpl connection;
    private final SessionImpl session;
    private final MessageConsumer consumer;
    private final int maxMessages;
    private int messageCount = 0;
    private int nullMessageCount = 0;
    private volatile boolean closed = false;
    private final Thread thread;

    private class ConsumerRunnable implements Runnable
    {
        public void run()
        {
            LogHelper.logMethod( log, toObjectString(), "run()" );

            final long pollingInterval = session.getConfiguration().getPollingInterval();
            SessionImpl childSession = null;
            MessageImpl message = null;
            while ( !closed || messageCount > 0 )
            {
                try
                {
                    if ( childSession == null )
                    {
                        final long startMillis = System.currentTimeMillis();
                        childSession = newChildSession();
                        log.trace( "Server responded to request for new child session in "
                                + ( System.currentTimeMillis() - startMillis ) + " ms, value = " + childSession );
                    }

                    if ( childSession == null )
                    {
                        // Couldn't create child session, sleep and try again
                        Thread.sleep( pollingInterval );
                    }
                    else
                    {
                        if ( message == null )
                        {
                            message = (MessageImpl)consumer.receive( pollingInterval );
                            if ( message == null )
                            {
                                nullMessageCount++;
                            }
                            else
                            {
                                messageCount++;
                                nullMessageCount = 0;
                            }
                        }

                        if ( message != null )
                        {
                            childSession.startReparentingMessageToChild( message );
                            message = null;
                        }

                        if ( messageCount >= maxMessages || ( messageCount > 0 && nullMessageCount >= maxMessages ) )
                        {
                            childSession = null;
                            messageCount = 0;
                            log.debug( "Starting, messagesSent = " + messageCount + ", maxMessages = " + maxMessages
                                    + ", nullMessageCount = " + nullMessageCount );
                            startChildSession();
                        }
                    }
                }
                catch ( JMSException e )
                {
                    log.error( "JMSException during ServerConsumer run", e );
                    if ( message != null )
                    {
                        try
                        {
                            session.recover();
                        }
                        catch ( JMSException e1 )
                        {
                            log.error( "JMSException while attempting session recovery", e1 );
                        }
                    }
                }
                catch ( InterruptedException e )
                {
                    log.warn( "Interrupted, " + e.getMessage() );
                    closed = true;
                }
            }

            if ( childSession != null )
            {
                try
                {
                    startChildSession();
                }
                catch ( JMSException e )
                {
                    log.error( "JMSException while exiting ServerConsumer run", e );
                }
            }
        }

        protected final String toObjectString()
        {
            return super.toString();
        }
    }

    protected ServerConsumer( final ConnectionImpl connection, final Destination destination,
            final String subscriptionName, final String messageSelector, final int maxMessages ) throws JMSException
    {
        LogHelper.logMethod( log, toObjectString(), "ServerConsumer(), connection = " + connection
                + ", destination = " + destination + ", subscriptionName = " + subscriptionName
                + ", messageSelector = " + messageSelector + ", maxMessages = " + maxMessages );
        this.connection = connection;

        // Session is always non-XA and client-acknowledge because messages get reparented to another session before
        // delivery
        session = (SessionImpl)connection.createNonXASession( false, Session.CLIENT_ACKNOWLEDGE );
        if ( subscriptionName == null )
        {
            consumer = session.createConsumer( destination, messageSelector );
        }
        else
        {
            consumer = session.createDurableSubscriber( (Topic)destination, subscriptionName, messageSelector, false );
        }

        this.maxMessages = maxMessages;

        thread = new Thread( new ConsumerRunnable() );
        thread.setName( "ServerConsumer-" + ( (DestinationImpl)destination ).getName() + "-" + thread.getName() );
    }

    public ConnectionImpl getConnection()
    {
        return connection;
    }

    protected void startConsuming()
    {
        LogHelper.logMethod( log, toObjectString(), "startConsuming(), consumer = " + consumer.toString() );
        thread.start();
    }

    public void closeServerConsumer() throws JMSException
    {
        LogHelper.logMethod( log, toObjectString(), "closeServerConsumer(), consumer = " + consumer.toString() );
        closed = true;
        try
        {
            thread.join();
        }
        catch ( InterruptedException ignore )
        {
            // Ignore
        }

        session.getConnection().removeServerConsumer( this );
        session.close();
    }

    protected abstract SessionImpl newChildSession();

    protected abstract void startChildSession() throws JMSException;

    public String toString()
    {
        return "[" + super.toString() + ", session = " + session + "]";
    }

    protected final String toObjectString()
    {
        return super.toString();
    }
}
