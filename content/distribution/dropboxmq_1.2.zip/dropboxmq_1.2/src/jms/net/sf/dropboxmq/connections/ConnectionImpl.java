/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.connections;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.jms.Connection;
import javax.jms.ConnectionConsumer;
import javax.jms.ConnectionMetaData;
import javax.jms.Destination;
import javax.jms.ExceptionListener;
import javax.jms.IllegalStateException;
import javax.jms.InvalidClientIDException;
import javax.jms.JMSException;
import javax.jms.ServerSessionPool;
import javax.jms.Session;
import javax.jms.Topic;
import net.sf.dropboxmq.Configuration;
import net.sf.dropboxmq.DropboxMQJMSException;
import net.sf.dropboxmq.DropboxTransaction;
import net.sf.dropboxmq.FileSystem;
import net.sf.dropboxmq.IdGenerator;
import net.sf.dropboxmq.LogHelper;
import net.sf.dropboxmq.dropboxsupport.DirectoryStructure;
import net.sf.dropboxmq.messageconsumers.ConnectionConsumerImpl;
import net.sf.dropboxmq.messageconsumers.ServerConsumer;
import net.sf.dropboxmq.messagetranscoders.DefaultMessageTranscoder;
import net.sf.dropboxmq.resource.spi.ManagedConnectionImpl;
import net.sf.dropboxmq.sessions.SessionImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 09 Mar 2006
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 231 $, $Date: 2011-08-12 21:50:47 -0600 (Fri, 12 Aug 2011) $
 */
public class ConnectionImpl implements Connection
{
    private static final Log log = LogFactory.getLog(ConnectionImpl.class);

    private final ManagedConnectionImpl managedConnection;
    private final Configuration configuration;

    private final Object lock = new Object();

    private String clientID = null;
    private boolean clientIDSet = false;
    private boolean clientIDLocked = false;
    private boolean started = false;
    private volatile boolean closed = false;
    private volatile ExceptionListener exceptionListener = null;
    private final Set sessions = new HashSet();
    private final Set serverConsumers = new HashSet();
    private final Set durableSubscriptionNames = new HashSet();
    private final IdGenerator idGenerator = new IdGenerator();

    private static final int JMS_MAJOR_VERSION = 1;
    private static final int JMS_MINOR_VERSION = 1;
    private static final String JMS_VERSION = JMS_MAJOR_VERSION + "." + JMS_MINOR_VERSION;
    public static final String JMS_PROVIDER_NAME = "DropboxMQ";
    private static final int PROVIDER_MAJOR_VERSION = 1;
    private static final int PROVIDER_MINOR_VERSION = 2;
    public static final String PROVIDER_VERSION = PROVIDER_MAJOR_VERSION + "." + PROVIDER_MINOR_VERSION;

    public static final String JMSX_DELIVERY_COUNT = "JMSXDeliveryCount";
    public static final String JMSX_GROUP_ID = "JMSXGroupID";
    public static final String JMSX_GROUP_SEQ = "JMSXGroupSeq";

    private static final List jmsxPropertyNames = Collections.unmodifiableList(Arrays.asList(new String[]{
            JMSX_DELIVERY_COUNT, JMSX_GROUP_ID, JMSX_GROUP_SEQ}));

    private static class ConnectionMetaDataImpl implements ConnectionMetaData
    {
        private static final Log innerLog = LogFactory.getLog(ConnectionMetaDataImpl.class);

        public String getJMSVersion()
        {
            LogHelper.logMethod(innerLog, toObjectString(), "getJMSVersion() = " + JMS_VERSION);
            return JMS_VERSION;
        }

        public int getJMSMajorVersion()
        {
            LogHelper.logMethod(innerLog, toObjectString(), "getJMSMajorVersion() = " + JMS_MAJOR_VERSION);
            return JMS_MAJOR_VERSION;
        }

        public int getJMSMinorVersion()
        {
            LogHelper.logMethod(innerLog, toObjectString(), "getJMSMinorVersion() = " + JMS_MINOR_VERSION);
            return JMS_MINOR_VERSION;
        }

        public String getJMSProviderName()
        {
            LogHelper.logMethod(innerLog, toObjectString(), "getJMSProviderName() = " + JMS_PROVIDER_NAME);
            return JMS_PROVIDER_NAME;
        }

        public String getProviderVersion()
        {
            LogHelper.logMethod(innerLog, toObjectString(), "getProviderVersion() = " + PROVIDER_VERSION);
            return PROVIDER_VERSION;
        }

        public int getProviderMajorVersion()
        {
            LogHelper.logMethod(innerLog, toObjectString(), "getProviderMajorVersion() = " + PROVIDER_MAJOR_VERSION);
            return PROVIDER_MAJOR_VERSION;
        }

        public int getProviderMinorVersion()
        {
            LogHelper.logMethod(innerLog, toObjectString(), "getProviderMinorVersion() = " + PROVIDER_MINOR_VERSION);
            return PROVIDER_MINOR_VERSION;
        }

        public Enumeration getJMSXPropertyNames()
        {
            LogHelper.logMethod(innerLog, toObjectString(), "getJMSXPropertyNames()");
            return Collections.enumeration(jmsxPropertyNames);
        }

        protected final String toObjectString()
        {
            return super.toString();
        }
    }

    public ConnectionImpl(final ManagedConnectionImpl managedConnection, final Configuration configuration)
            throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(),
                "ConnectionImpl(), managedConnection = " + managedConnection + ", configuration = " + configuration);
        this.managedConnection = managedConnection;
        this.configuration = configuration;
        if (configuration.getClientId() != null)
        {
            setLocalClientID(configuration.getClientId());
        }
        else
        {
            clientID = idGenerator.getNewID();
        }
    }

    public Session createSession(final boolean transacted, final int acknowledgeMode) throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "createSession(), transacted = " + transacted
                + ", acknowledgeMode = " + SessionImpl.getAcknowledgeModeString(acknowledgeMode));
        return createNonXASession(transacted, acknowledgeMode);
    }

    public Session createNonXASession(final boolean transacted, final int acknowledgeMode) throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "createNonXASession(), transacted = " + transacted
                + ", acknowledgeMode = " + SessionImpl.getAcknowledgeModeString(acknowledgeMode));
        synchronized (lock)
        {
            checkClosed();

            final DropboxTransaction dropboxTransaction = newDropboxTransaction(transacted, acknowledgeMode);
            final SessionImpl session = new SessionImpl(dropboxTransaction, this, configuration);
            addSession(session);

            return session;
        }
    }

    public DropboxTransaction newDropboxTransaction(final boolean transacted, final int acknowledgeMode)
    {
        final DropboxTransaction dropboxTransaction;
        if (managedConnection == null)
        {
            dropboxTransaction = new DropboxTransaction(
                    idGenerator.getNewID(), transacted, acknowledgeMode, configuration);
        }
        else
        {
            dropboxTransaction = managedConnection.getDropboxTransaction();
        }
        return dropboxTransaction;
    }

    public String getClientID() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "getClientID() = " + clientID);
        synchronized (lock)
        {
            checkClosed();

            return clientID;
        }
    }

    public String getLocalClientID()
    {
        synchronized (lock)
        {
            return clientID;
        }
    }

    public void setClientID(final String clientID) throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "setClientID(), clientID = " + clientID);
        setLocalClientID(clientID);
    }

    private void setLocalClientID(final String clientID) throws JMSException
    {
        synchronized (lock)
        {
            checkClosed();

            if (clientIDSet)
            {
                throw new IllegalStateException("The client ID has already been set");
            }
            if (!sessions.isEmpty())
            {
                throw new IllegalStateException("The client ID cannot be set after a session has been created");
            }
            if (exceptionListener != null)
            {
                throw new IllegalStateException("The client ID cannot be set after an exception listener is set");
            }
            if (clientIDLocked)
            {
                throw new IllegalStateException("The client ID cannot be set after the connection is started");
            }

            final FileSystem fileSystem = configuration.getFileSystem();
            final File clientIDDir = new File(configuration.getRootDir(), DirectoryStructure.CLIENTS_SUB_DIR);
            final File clientIDFile = new File(clientIDDir, DefaultMessageTranscoder.encode(clientID));
            try
            {
                fileSystem.mkdirs(clientIDDir);
                if (!fileSystem.createNewFile(clientIDFile, true))
                {
                    throw new InvalidClientIDException("Client " + clientID + " is already connected");
                }
            }
            catch (FileSystem.FileSystemException e)
            {
                throw new DropboxMQJMSException("Could not set the client id for " + clientID, e);
            }

            this.clientID = clientID;
            clientIDSet = true;
        }
    }

    public ConnectionMetaData getMetaData() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "getMetaData()");
        checkClosed();

        return new ConnectionMetaDataImpl();
    }

    public ExceptionListener getExceptionListener() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "getExceptionListener() = " + exceptionListener);
        checkClosed();

        return exceptionListener;
    }

    public void setExceptionListener(final ExceptionListener listener) throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "setExceptionListener(), listener = " + listener);
        checkClosed();

        exceptionListener = listener;
    }

    public void start() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "start()");
        synchronized (lock)
        {
            checkClosed();

            for (Iterator iterator = sessions.iterator(); iterator.hasNext();)
            {
                final SessionImpl session = (SessionImpl)iterator.next();
                session.start();
            }

            clientIDLocked = true;
            started = true;
        }
    }

    public void stop() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "stop()");
        final Set sessionsCopy = new HashSet();
        synchronized (lock)
        {
            checkClosed();

            sessionsCopy.addAll(sessions);

            // TODO:  JMSCTS claims that the client id can't be modified after stop() is called
            clientIDLocked = true;
            started = false;
        }

        for (Iterator iterator = sessionsCopy.iterator(); iterator.hasNext();)
        {
            final SessionImpl session = (SessionImpl)iterator.next();
            session.stop();
        }
    }

    public void close() throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "close()");
        final Set sessionsCopy = new HashSet();
        synchronized (lock)
        {
            closed = true;

            for (final Iterator iterator = new ArrayList(serverConsumers).iterator(); iterator.hasNext();)
            {
                final ServerConsumer serverConsumer = (ServerConsumer)iterator.next();
                serverConsumer.closeServerConsumer();
            }

            sessionsCopy.addAll(sessions);

            if (clientIDSet)
            {
                clearClientID();
            }

            if (managedConnection != null)
            {
                managedConnection.closeConnection(this);
            }
        }

        for (final Iterator iterator = new ArrayList(sessionsCopy).iterator(); iterator.hasNext();)
        {
            final SessionImpl session = (SessionImpl)iterator.next();
            session.close();
        }
    }

    private void clearClientID() throws JMSException
    {
        log.trace("clearClientID(), clientID = " + clientID + ", configuration = " + configuration);
        synchronized (lock)
        {
            if (clientID != null)
            {
                final File clientIDDir = new File(configuration.getRootDir(), DirectoryStructure.CLIENTS_SUB_DIR);
                final File clientIDFile = new File(clientIDDir, DefaultMessageTranscoder.encode(clientID));
                try
                {
                    configuration.getFileSystem().delete(clientIDFile);
                }
                catch (FileSystem.FileSystemException e)
                {
                    throw new DropboxMQJMSException(
                            "Could not remove lock file for client " + clientID + ", " + clientIDFile, e);
                }
                log.info("Cleared client id file, " + clientIDFile);
            }
        }
    }

    public ConnectionConsumer createConnectionConsumer(final Destination destination, final String messageSelector,
            final ServerSessionPool sessionPool, final int maxMessages)
            throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "createConnectionConsumer(), destination = " + destination
                + ", messageSelector = " + messageSelector + ", sessionPool = " + sessionPool
                + ", maxMessages = " + maxMessages);
        return createConnectionConsumer(destination, null, messageSelector, sessionPool, maxMessages);
    }

    public ConnectionConsumer createDurableConnectionConsumer(final Topic topic, final String subscriptionName,
            final String messageSelector, final ServerSessionPool sessionPool, final int maxMessages)
            throws JMSException
    {
        LogHelper.logMethod(log, toObjectString(), "createDurableConnectionConsumer(), topic = " + topic
                + ", messageSelector = " + messageSelector + ", sessionPool = " + sessionPool
                + ", maxMessages = " + maxMessages);
        return createConnectionConsumer(topic, subscriptionName, messageSelector, sessionPool, maxMessages);
    }

    private ConnectionConsumer createConnectionConsumer(final Destination destination, final String subscriptionName,
            final String messageSelector, final ServerSessionPool sessionPool, final int maxMessages)
            throws JMSException
    {
        final ConnectionConsumerImpl connectionConsumer;
        synchronized (lock)
        {
            checkClosed();

            connectionConsumer = new ConnectionConsumerImpl(
                    this, destination, subscriptionName, messageSelector, sessionPool, maxMessages);
            serverConsumers.add(connectionConsumer);
        }

        connectionConsumer.start();

        return connectionConsumer;
    }

    protected void addSession(final SessionImpl session) throws JMSException
    {
        synchronized (lock)
        {
            sessions.add(session);

            if (started)
            {
                session.start();
            }
        }
    }

    public void removeSession(final SessionImpl session)
    {
        synchronized (lock)
        {
            sessions.remove(session);
        }
    }

    public void removeServerConsumer(final ServerConsumer serverConsumer)
    {
        synchronized (lock)
        {
            serverConsumers.remove(serverConsumer);
        }
    }

    public void addDurableSubscriptionName(final String durableSubscriptionName) throws JMSException
    {
        synchronized (lock)
        {
            if (durableSubscriptionNames.contains(durableSubscriptionName))
            {
                throw new JMSException("Durable subscription name " + durableSubscriptionName
                        + " already exists for this connection.");
            }
            durableSubscriptionNames.add(durableSubscriptionName);
        }
    }

    public void removeDurableSubscriptionName(final String durableSubscriptionName)
    {
        synchronized (lock)
        {
            durableSubscriptionNames.remove(durableSubscriptionName);
        }
    }

    protected void checkClosed() throws IllegalStateException
    {
        synchronized (lock)
        {
            if (closed)
            {
                throw new IllegalStateException("Connection is currently in a closed state");
            }
        }
    }

    public ManagedConnectionImpl getManagedConnection()
    {
        return managedConnection;
    }

    protected Configuration getConfiguration()
    {
        return configuration;
    }

    protected Object getLock()
    {
        return lock;
    }

    public String toString()
    {
        return "[" + super.toString() + ", clientID = " + clientID + "]";
    }

    protected final String toObjectString()
    {
        return super.toString();
    }

}
