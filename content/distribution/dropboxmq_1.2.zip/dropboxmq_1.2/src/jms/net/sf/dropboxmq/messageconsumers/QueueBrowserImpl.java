/*
 Copyright (c) 2010, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package net.sf.dropboxmq.messageconsumers;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import net.sf.dropboxmq.Dropbox;
import net.sf.dropboxmq.LogHelper;
import net.sf.dropboxmq.FileSystem;
import net.sf.dropboxmq.destinations.QueueImpl;
import net.sf.dropboxmq.messages.MessageImpl;
import net.sf.dropboxmq.sessions.SessionImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 14 Jan 2006
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 211 $, $Date: 2010-11-14 14:21:24 -0700 (Sun, 14 Nov 2010) $
 */
public class QueueBrowserImpl implements QueueBrowser
{
    private static final Log log = LogFactory.getLog( QueueBrowserImpl.class );

    private final Dropbox dropbox;
    private boolean closed = false;

    private static class QueueBrowserEnumeration implements Enumeration
    {
        private static final Log innerLog = LogFactory.getLog( QueueBrowserEnumeration.class );

        private final Iterator targetFilesIter;
        private final QueueBrowserImpl queueBrowser;
        private Message nextMessage = null;

        private QueueBrowserEnumeration( final List targetFiles, final QueueBrowserImpl queueBrowser )
        {
            LogHelper.logMethod( innerLog, toObjectString(), "QueueBrowserEnumeration(), targetFiles = " + targetFiles
                    + ", queueBrowser = " + queueBrowser );
            targetFilesIter = targetFiles.iterator();
            this.queueBrowser = queueBrowser;
        }

        public boolean hasMoreElements()
        {
            LogHelper.logMethod( innerLog, toObjectString(), "hasMoreElements()" );
            findNextTargetFile();

            return nextMessage != null;
        }

        public Object nextElement()
        {
            LogHelper.logMethod( innerLog, toObjectString(), "nextElement()" );
            findNextTargetFile();

            final Message currentMessage = nextMessage;
            nextMessage = null;
            return currentMessage;
        }

        private void findNextTargetFile()
        {
            LogHelper.logMethod( innerLog, toObjectString(), "findNextTargetFile()" );
            if ( queueBrowser.closed )
            {
                Dropbox.throwRuntimeException( "Attempting to use QueueBrowser after it has been closed" );
            }

            if ( nextMessage == null )
            {
                while ( nextMessage == null && targetFilesIter.hasNext() )
                {
                    final File targetFile = (File)targetFilesIter.next();

                    try
                    {
                        final MessageImpl possibleNextMessage = queueBrowser.dropbox.createMessage( targetFile );

                        if ( possibleNextMessage != null && !possibleNextMessage.isExpired() )
                        {
                            possibleNextMessage.read( targetFile, queueBrowser.dropbox.getFileSystem() );
                            nextMessage = possibleNextMessage;
                        }
                    }
                    catch ( JMSException ignore )
                    {
                        innerLog.warn( "Ignoring JMSException while browsing messages, " + ignore.getMessage() );
                    }
                    catch ( IOException ignore )
                    {
                        innerLog.warn( "Ignoring IOException while browsing messages, " + ignore.getMessage() );
                    }
                    catch ( FileSystem.FileSystemException ignore )
                    {
                        innerLog.warn( "Ignoring FileSystem.FileSystemException while browsing messages, "
                                + ignore.getMessage() );
                    }
                }
            }
        }

        protected final String toObjectString()
        {
            return super.toString();
        }
    }

    public QueueBrowserImpl( final SessionImpl session, final QueueImpl queue, final String messageSelector )
            throws JMSException
    {
        LogHelper.logMethod( log, toObjectString(), "QueueBrowserImpl(), session = " + session + ", queue = " + queue );
        dropbox = session.newDropbox( queue, messageSelector, null, false );
    }

    public Queue getQueue() throws JMSException
    {
        LogHelper.logMethod( log, toObjectString(), "getQueue() = " + dropbox.getDestination() );
        return (Queue)dropbox.getDestination();
    }

    public String getMessageSelector() throws JMSException
    {
        LogHelper.logMethod( log, toObjectString(), "getMessageSelector()" );
        return dropbox.getMessageSelector();
    }

    public Enumeration getEnumeration() throws JMSException
    {
        LogHelper.logMethod( log, toObjectString(), "getEnumeration()" );
        if ( closed )
        {
            throw new JMSException( "Attempting to use a closed QueueBrowser" );
        }

        final List targetFiles = dropbox.getCurrentTargetFiles();
        return new QueueBrowserEnumeration( targetFiles, this );
    }

    public void close() throws JMSException
    {
        LogHelper.logMethod( log, toObjectString(), "close()" );
        dropbox.close();
        closed = true;
    }

    protected final String toObjectString()
    {
        return super.toString();
    }
}
