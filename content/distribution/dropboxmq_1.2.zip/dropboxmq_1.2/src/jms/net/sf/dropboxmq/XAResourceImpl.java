/*
 Copyright (c) 2010, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq;

import java.util.List;
import java.util.Iterator;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import javax.transaction.xa.Xid;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 30 Jul 2006
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 211 $, $Date: 2010-11-14 14:21:24 -0700 (Sun, 14 Nov 2010) $
 */
public class XAResourceImpl implements XAResource
{
    private static final Log log = LogFactory.getLog( XAResourceImpl.class );

    private final DropboxTransaction dropboxTransaction;

    public XAResourceImpl( final DropboxTransaction dropboxTransaction )
    {
        LogHelper.logMethod( log, toObjectString(), "XAResourceImpl(), dropboxTransaction = " + dropboxTransaction );
        this.dropboxTransaction = dropboxTransaction;
    }

    public void start( final Xid xid, final int flags ) throws XAException
    {
        LogHelper.logMethod( log, toObjectString(), "start(), xid = " + xid + ", flags = " + flags );
        final String xidString = XidImpl.encode( xid );
        try
        {
            if ( flags == TMNOFLAGS )
            {
                dropboxTransaction.start( xidString, true );
            }
            else if ( ( flags & TMRESUME ) == TMRESUME )
            {
                dropboxTransaction.resume( xidString );
            }
        }
        catch ( DropboxTransaction.InLocalTransactionException e )
        {
            log.error( "DropboxTransaction.InLocalTransactionException while in start()", e );
            throw new XAException( XAException.XAER_OUTSIDE );
        }
        catch ( DropboxTransaction.ProtocolException e )
        {
            log.error( "DropboxTransaction.ProtocolException while in start()", e );
            throw new XAException( XAException.XAER_PROTO );
        }
        catch ( DropboxTransaction.NotAnXIDException e )
        {
            log.error( "DropboxTransaction.NotAnXIDException while in start()", e );
            throw new XAException( XAException.XAER_NOTA );
        }
        catch ( DropboxTransaction.TransactionException e )
        {
            log.error( "DropboxTransaction.TransactionException while in start()", e );
            throw new XAException( XAException.XAER_RMERR );
        }
    }

    public void end( final Xid xid, final int flags ) throws XAException
    {
        LogHelper.logMethod( log, toObjectString(), "end(), xid = " + xid + ", flags = " + flags );
        final String xidString = XidImpl.encode( xid );
        try
        {
            dropboxTransaction.end( xidString );
        }
        catch ( DropboxTransaction.ProtocolException e )
        {
            log.error( "DropboxTransaction.ProtocolException while in end()", e );
            throw new XAException( XAException.XAER_PROTO );
        }
        catch ( DropboxTransaction.TransactionException e )
        {
            log.error( "DropboxTransaction.TransactionException while in end()", e );
            throw new XAException( XAException.XAER_RMERR );
        }
    }

    public int prepare( final Xid xid ) throws XAException
    {
        LogHelper.logMethod( log, toObjectString(), "prepare(), xid = " + xid );
        final String xidString = XidImpl.encode( xid );
        try
        {
            dropboxTransaction.prepare( xidString );
        }
        catch ( DropboxTransaction.TransactionException e )
        {
            log.error( "DropboxTransaction.TransactionException while in prepare()", e );
            throw new XAException( XAException.XAER_RMERR );
        }
        return XA_OK;
    }

    public void commit( final Xid xid, final boolean onePhase ) throws XAException
    {
        LogHelper.logMethod( log, toObjectString(), "commit(), xid = " + xid + ", onePhase = " + onePhase );
        final String xidString = XidImpl.encode( xid );
        try
        {
            dropboxTransaction.commit( xidString, onePhase );
        }
        catch ( DropboxTransaction.TransactionException e )
        {
            log.error( "DropboxTransaction.TransactionException while in prepare()", e );
            throw new XAException( XAException.XAER_RMERR );
        }
    }

    public void rollback( final Xid xid ) throws XAException
    {
        LogHelper.logMethod( log, toObjectString(), "rollback(), xid = " + xid );
        final String xidString = XidImpl.encode( xid );
        try
        {
            dropboxTransaction.rollback( xidString );
        }
        catch ( DropboxTransaction.TransactionException e )
        {
            log.error( "DropboxTransaction.TransactionException while in rollback()", e );
            throw new XAException( XAException.XAER_RMERR );
        }
    }

    public void forget( final Xid xid ) throws XAException
    {
        LogHelper.logMethod( log, toObjectString(), "forget(), xid = " + xid );
        // TODO
    }

    public Xid[] recover( final int flag ) throws XAException
    {
        LogHelper.logMethod( log, toObjectString(), "recover(), flag = " + flag );
        final List ids = dropboxTransaction.getPreparedTransactionIds();
        final XidImpl[] xids = new XidImpl[ ids.size() ];
        try
        {
            int count = 0;
            for ( Iterator iterator = ids.iterator(); iterator.hasNext();  )
            {
                final String id = (String)iterator.next();
                xids[ count ] = new XidImpl( id );
                count++;
            }
        }
        catch ( DropboxTransaction.TransactionException e )
        {
            throw new RuntimeException( e );
        }
        return xids;
    }

    public int getTransactionTimeout() throws XAException
    {
        LogHelper.logMethod( log, toObjectString(), "getTransactionTimeout()" );
        return 0;
    }

    public boolean setTransactionTimeout( final int seconds ) throws XAException
    {
        LogHelper.logMethod( log, toObjectString(), "setTransactionTimeout(), seconds = " + seconds );
        return false;
    }

    public boolean isSameRM( final XAResource xares ) throws XAException
    {
        LogHelper.logMethod( log, toObjectString(), "isSameRM(), xares = " + xares );
        // By always returning false we should never get a start( xid, TMJOIN ).  We can implement this optimisation
        // later.
        return false;
    }

    protected final String toObjectString()
    {
        return super.toString();
    }
}
