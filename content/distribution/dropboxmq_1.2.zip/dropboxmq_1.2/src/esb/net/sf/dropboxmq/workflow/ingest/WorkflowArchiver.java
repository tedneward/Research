/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.ingest;

import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.sf.dropboxmq.workflow.data.DeferredEventType;
import net.sf.dropboxmq.workflow.data.EventType;
import net.sf.dropboxmq.workflow.data.Namespace;
import net.sf.dropboxmq.workflow.data.ProcessType;
import net.sf.dropboxmq.workflow.data.Processor;
import net.sf.dropboxmq.workflow.data.State;
import net.sf.dropboxmq.workflow.data.Transition;
import net.sf.dropboxmq.workflow.persistence.DeferredEventTypePersistence;
import net.sf.dropboxmq.workflow.persistence.EventTypePersistence;
import net.sf.dropboxmq.workflow.persistence.NamespacePersistence;
import net.sf.dropboxmq.workflow.persistence.PersistenceFactory;
import net.sf.dropboxmq.workflow.persistence.ProcessTypePersistence;
import net.sf.dropboxmq.workflow.persistence.ProcessorPersistence;
import net.sf.dropboxmq.workflow.persistence.TransitionPersistence;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 15 Aug 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class WorkflowArchiver
{
    private static final Log log = LogFactory.getLog(WorkflowArchiver.class);

    private final boolean checkTransformerExists;
    private final Map<String, Map<String, Namespace>> namespacesByPrefixByProcessor
            = new HashMap<String, Map<String, Namespace>>();
    private final Map<String, Map<String, ProcessType>> processTypesByNameByProcessor
            = new HashMap<String, Map<String, ProcessType>>();
    private final Map<Integer, Map<String, EventType>> eventTypesByNameByProcessType
            = new HashMap<Integer, Map<String, EventType>>();

    public WorkflowArchiver(final boolean checkTransformerExists)
    {
        this.checkTransformerExists = checkTransformerExists;
    }

    public void archiveWorkflow(final Collection<IngestedProcessor> ingestedProcessors, final String[] workflowDirs,
            final PersistenceFactory factory)
    {
        namespacesByPrefixByProcessor.clear();
        processTypesByNameByProcessor.clear();

        for (final IngestedProcessor ingestedProcessor : ingestedProcessors)
        {
            archiveProcessor(ingestedProcessor, workflowDirs, factory);
        }

        // TODO:  Disable event types for process types that are no longer defined?

        log.info("Updating event types");
        for (final IngestedProcessor ingestedProcessor : ingestedProcessors)
        {
            for (final IngestedProcessor.IngestedProcessType ingestedProcessType
                    : ingestedProcessor.getProcessTypes())
            {
                // Event types are archived later because we now know all of the process type ids
                // and event types cross reference process types
                archiveEventTypes(ingestedProcessType, ingestedProcessor.getProcessor(), factory);
            }
        }

        log.info("Updating deferred event types");
        for (final IngestedProcessor ingestedProcessor : ingestedProcessors)
        {
            for (final IngestedProcessor.IngestedProcessType ingestedProcessType
                    : ingestedProcessor.getProcessTypes())
            {
                log.info("  Creating deferred event types for process type "
                        + ingestedProcessType.getProcessType().getName());
                for (final IngestedProcessor.IngestedState ingestedState : ingestedProcessType.getStates())
                {
                    // Deferred event types are archived last because now all the event types exist
                    archiveDeferredEventTypes(ingestedState, ingestedProcessType.getProcessType().getId(), factory);
                }
            }
        }
    }

    private void archiveProcessor(
            final IngestedProcessor ingestedProcessor, final String[] workflowDirs, final PersistenceFactory factory)
    {
        final ProcessorPersistence persistence = factory.getProcessorPersistence();
        final Processor newProcessor = ingestedProcessor.getProcessor();
        Processor processor = persistence.getProcessorByName(newProcessor.getName());
        if (processor == null)
        {
            log.info("Creating processor " + newProcessor.getName());
            persistence.storeProcessor(newProcessor);
            processor = newProcessor;
        }

        for (final Namespace namespace : ingestedProcessor.getNamespaces())
        {
            archiveNamespace(namespace, processor, factory);
        }

        for (final IngestedProcessor.IngestedProcessType ingestedProcessType : ingestedProcessor.getProcessTypes())
        {
            archiveProcessType(ingestedProcessType, processor, workflowDirs, factory);
        }
    }

    private void archiveNamespace(
            final Namespace namespace, final Processor processor, final PersistenceFactory factory)
    {
        final NamespacePersistence persistence = factory.getNamespacePersistence();
        Map<String, Namespace> namespacesByPrefix = namespacesByPrefixByProcessor.get(processor.getName());
        if (namespacesByPrefix == null)
        {
            namespacesByPrefix = new HashMap<String, Namespace>();
            namespacesByPrefixByProcessor.put(processor.getName(), namespacesByPrefix);

            // First time we've seen this processor, so clear the namespaces
            log.info("Deleting namespaces from processor " + processor.getName());
            persistence.deleteNamespaces(processor.getId());
        }

        final Namespace previousNamespace = namespacesByPrefix.get(namespace.getPrefix());
        if (previousNamespace == null)
        {
            namespacesByPrefix.put(namespace.getPrefix(), namespace.clone());

            log.info("Creating namespace " + namespace.getPrefix());
            namespace.setProcessorId(processor.getId());
            persistence.storeNamespace(namespace);
        }
        else
        {
            if (!previousNamespace.getURI().equals(namespace.getURI()))
            {
                throw new RuntimeException("Namespace URIs don't match between multiple definitions.  First URI was "
                        + previousNamespace.getURI() + ", second was " + namespace.getURI());
            }
        }
    }

    private void archiveProcessType(final IngestedProcessor.IngestedProcessType ingestedProcessType,
            final Processor processor, final String[] workflowDirs, final PersistenceFactory factory)
    {
        final ProcessType processType = ingestedProcessType.getProcessType();
        processType.setProcessorId(processor.getId());

        // Previous as in we've already seen this process type in another processor file
        checkPreviousProcessTypes(processType, processor);

        final ProcessTypePersistence processTypePersistence = factory.getProcessTypePersistence();
        final ProcessType existingProcessType
                = processTypePersistence.getProcessTypeByName(processType.getName(), processor.getName());
        if (existingProcessType == null)
        {
            log.info("Creating process type " + processType.getName());
            processTypePersistence.storeProcessType(processType);
        }
        else
        {
            log.info("Updating process type " + processType.getName());
            processType.setId(existingProcessType.getId());
        }

        archiveStates(ingestedProcessType, workflowDirs, factory);
    }

    private void checkPreviousProcessTypes(final ProcessType processType, final Processor processor)
    {
        Map<String, ProcessType> processTypesByName = processTypesByNameByProcessor.get(processor.getName());
        if (processTypesByName == null)
        {
            processTypesByName = new HashMap<String, ProcessType>();
            processTypesByNameByProcessor.put(processor.getName(), processTypesByName);
        }

        if (processTypesByName.containsKey(processType.getName()))
        {
            throw new RuntimeException("Process type defined in more than one file for the same processor,"
                    + " process type = " + processType.getName() + ", processor = " + processor.getName());
        }
        else
        {
            processTypesByName.put(processType.getName(), processType);
        }
    }

    private void archiveStates(final IngestedProcessor.IngestedProcessType ingestedProcessType,
            final String[] workflowDirs, final PersistenceFactory factory)
    {
        final ProcessType processType = ingestedProcessType.getProcessType();
        final Map<String, State> existingStates = catalogStates(processType.getId(), factory);
        final Set<String> existingStateNames = new HashSet<String>();
        existingStateNames.addAll(existingStates.keySet());
        for (final IngestedProcessor.IngestedState ingestedState : ingestedProcessType.getStates())
        {
            archiveState(ingestedState, existingStates, existingStateNames, processType, factory);
        }

        // These states no longer exist in the workflow
        for (final String removedStateName : existingStateNames)
        {
            log.info("  Deleting transitions to orphaned state + " + removedStateName);
            final State removedState = existingStates.remove(removedStateName);
            factory.getTransitionPersistence().deleteTransitionsToState(removedState.getId());
        }

        for (final IngestedProcessor.IngestedState ingestedState : ingestedProcessType.getStates())
        {
            archiveTransitions(ingestedState, existingStates, workflowDirs, factory);
        }
    }

    private static Map<String, State> catalogStates(final int processTypeId, final PersistenceFactory factory)
    {
        final Map<String, State> statesByName = new HashMap<String, State>();
        final Collection<State> states = factory.getStatePersistence().getStatesByProcessType(processTypeId);
        for (final State state : states)
        {
            statesByName.put(state.getName(), state);
        }

        return statesByName;
    }

    private static void archiveState(final IngestedProcessor.IngestedState ingestedState,
            final Map<String, State> existingStates, final Set<String> existingStateNames,
            final ProcessType processType, final PersistenceFactory factory)
    {
        final State state = ingestedState.getState();
        final String stateName = state.getName();
        state.setProcessTypeId(processType.getId());

        if (existingStateNames.contains(stateName))
        {
            log.info("  Updating state " + stateName);
            final State existingState = existingStates.get(stateName);
            state.setId(existingState.getId());
            existingStateNames.remove(stateName);
        }
        else if (stateName != null)
        {
            log.info("  Creating state " + stateName);
            factory.getStatePersistence().storeState(state);
            existingStates.put(stateName, state);
        }
    }

    private void archiveTransitions(final IngestedProcessor.IngestedState ingestedFromState,
            final Map<String, State> existingStates, final String[] workflowDirs, final PersistenceFactory factory)
    {
        log.info("  Updating transitions from state " + ingestedFromState.getState().getName()
                + (ingestedFromState.getState().getName() == null ? " (initial)" : ""));
        final TransitionPersistence transitionPersistence = factory.getTransitionPersistence();
        transitionPersistence.deleteTransitionsFromState(
                ingestedFromState.getState().getId(), ingestedFromState.getState().getProcessTypeId());

        for (final IngestedProcessor.IngestedTransition ingestedTransition : ingestedFromState.getTransitions())
        {
            Integer toStateId = null;
            if (ingestedTransition.getToStateName() != null)
            {
                final State toState = existingStates.get(ingestedTransition.getToStateName());
                if (toState == null)
                {
                    throw new RuntimeException("Could not find to-state, name = " + ingestedTransition.getToStateName());
                }
                toStateId = toState.getId();
            }

            final Transition transition = ingestedTransition.getTransition();
            transition.setFromStateId(ingestedFromState.isInitial() ? null : ingestedFromState.getState().getId());
            transition.setToStateId(toStateId);
            transition.setProcessTypeId(ingestedFromState.getState().getProcessTypeId());

            if (transition.getTransformerFilePath() != null && checkTransformerExists)
            {
                boolean foundTransformer = false;
                for (final String workflowDir : workflowDirs)
                {
                    if (new File(workflowDir + File.separator + transition.getTransformerFilePath()).exists())
                    {
                        foundTransformer = true;
                    }
                }

                if (!foundTransformer)
                {
                    throw new RuntimeException("Could not find transformer file in workflow paths, "
                            + transition.getTransformerFilePath());
                }
            }

            log.info("    Creating transition " + (transition.getName() == null ? "" : transition.getName()) +
                    " to state " + ingestedTransition.getToStateName());
            transitionPersistence.storeTransition(transition);
        }
    }

    private void archiveEventTypes(final IngestedProcessor.IngestedProcessType ingestedProcessType,
            final Processor processor, final PersistenceFactory factory)
    {
        final Map<String, EventType> eventTypesByName = new HashMap<String, EventType>();
        eventTypesByNameByProcessType.put(ingestedProcessType.getProcessType().getId(), eventTypesByName);

        final EventTypePersistence eventTypePersistence = factory.getEventTypePersistence();
        final Collection<EventType> existingEventTypes
                = eventTypePersistence.getEventTypesByProcessTypeId(ingestedProcessType.getProcessType().getId());
        final Map<String, EventType> existingEventTypesByName = new HashMap<String, EventType>();
        for (final EventType existingEventType : existingEventTypes)
        {
            existingEventTypesByName.put(existingEventType.getName(), existingEventType);
        }

        log.info("  Creating event types for process type " + ingestedProcessType.getProcessType().getName());
        for (final IngestedProcessor.IngestedEventType ingestedEventType : ingestedProcessType.getEventTypes())
        {
            archiveEventType(ingestedEventType, existingEventTypesByName,
                    ingestedProcessType.getProcessType(), processor, factory);
            eventTypesByName.put(ingestedEventType.getEventType().getName(), ingestedEventType.getEventType());
        }

        for (final EventType disabledEventType : existingEventTypesByName.values())
        {
            log.info("    Disabling no longer used event type " + disabledEventType.getName());
            eventTypePersistence.disableEventType(disabledEventType.getId());
        }
    }

    private void archiveEventType(final IngestedProcessor.IngestedEventType ingestedEventType,
            final Map<String, EventType> existingEventTypesByName, final ProcessType processType,
            final Processor processor, final PersistenceFactory factory)
    {
        Integer parentProcessTypeId = null;
        if (ingestedEventType.getParentProcessTypeName() != null)
        {
            final Map<String, ProcessType> processTypesByName
                    = processTypesByNameByProcessor.get(processor.getName());
            final ProcessType parentProcessType
                    = processTypesByName.get(ingestedEventType.getParentProcessTypeName());
            if (parentProcessType == null)
            {
                log.warn("Unknown parent process type name, process type = "
                        + ingestedEventType.getParentProcessTypeName());
            }
            else
            {
                parentProcessTypeId = parentProcessType.getId();
            }
        }

        final EventType eventType = ingestedEventType.getEventType();
        eventType.setEnabled(true);
        eventType.setProcessTypeId(processType.getId());
        eventType.setParentProcessTypeId(parentProcessTypeId);

        final EventTypePersistence eventTypePersistence = factory.getEventTypePersistence();
        final EventType existingEventType = existingEventTypesByName.get(ingestedEventType.getEventType().getName());
        if (existingEventType != null)
        {
            log.info("    Updating event type " + ingestedEventType.getEventType().getName());
            ingestedEventType.getEventType().setId(existingEventType.getId());
            eventTypePersistence.updateEventType(existingEventType.getId(), ingestedEventType.getEventType());
        }
        else
        {
            log.info("    Creating event type " + ingestedEventType.getEventType().getName());
            eventTypePersistence.storeEventType(ingestedEventType.getEventType());
        }

        existingEventTypesByName.remove(eventType.getName());
    }

    private void archiveDeferredEventTypes(final IngestedProcessor.IngestedState ingestedState,
            final int processTypeId, final PersistenceFactory factory)
    {
        if (!ingestedState.isInitial())
        {
            final Map<String, EventType> eventTypesByName = eventTypesByNameByProcessType.get(processTypeId);

            log.info("    Deleting deferred event types from state " + ingestedState.getState().getName());
            final DeferredEventTypePersistence deferredEventTypePersistence = factory.getDeferredEventTypePersistence();
            final int stateId = ingestedState.getState().getId();
            deferredEventTypePersistence.deleteDeferredEventTypes(stateId);

            for (final String deferredEventTypeName : ingestedState.getDeferredEventTypeNames())
            {
                final EventType eventType = eventTypesByName.get(deferredEventTypeName);
                if (eventType == null)
                {
                    throw new RuntimeException("Deferred event type is undefined, name = " + deferredEventTypeName);
                }

                final DeferredEventType deferredEventType = new DeferredEventType();
                deferredEventType.setStateId(stateId);
                deferredEventType.setEventTypeId(eventType.getId());

                log.info("      Creating deferred event type " + deferredEventTypeName);
                deferredEventTypePersistence.storeDeferredEventType(deferredEventType);
            }
        }
    }

}
