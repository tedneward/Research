/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.data;

import java.io.Serializable;
import java.util.Date;

/**
 * Created: 28 Jul 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class Event implements Serializable, Cloneable
{
    private static final long serialVersionUID = -7892362001464799510L;

    private Integer id = null;
    private String protocol = null;
    private String content = null;
    private Date storedOn = null;
    private Date processedOn = null;
    private Boolean isDeferred = null;
    private Integer runId = null;
    private Integer eventTypeId = null;
    private String transitionName = null;
    private Integer fromStateId = null;
    private Integer toStateId = null;

    // Join data -- not used at archive time
    private String eventTypeName = null;
    private String fromStateName = null;
    private String toStateName = null;

    public Integer getId()
    {
        return id;
    }

    public void setId(final Integer id)
    {
        this.id = id;
    }

    public String getProtocol()
    {
        return protocol;
    }

    public void setProtocol(final String protocol)
    {
        this.protocol = protocol;
    }

    public String getContent()
    {
        return content;
    }

    public void setContent(final String content)
    {
        this.content = content;
    }

    public Date getStoredOn()
    {
        return storedOn;
    }

    public void setStoredOn(final Date storedOn)
    {
        this.storedOn = storedOn;
    }

    public Date getProcessedOn()
    {
        return processedOn;
    }

    public void setProcessedOn(final Date processedOn)
    {
        this.processedOn = processedOn;
    }

    public Boolean isDeferred()
    {
        return isDeferred;
    }

    public void setDeferred(final Boolean isDeferred)
    {
        this.isDeferred = isDeferred;
    }

    public Integer getRunId()
    {
        return runId;
    }

    public void setRunId(final Integer runId)
    {
        this.runId = runId;
    }

    public Integer getEventTypeId()
    {
        return eventTypeId;
    }

    public void setEventTypeId(final Integer eventTypeId)
    {
        this.eventTypeId = eventTypeId;
    }

    public String getTransitionName()
    {
        return transitionName;
    }

    public void setTransitionName(final String transitionName)
    {
        this.transitionName = transitionName;
    }

    public Integer getFromStateId()
    {
        return fromStateId;
    }

    public void setFromStateId(final Integer fromStateId)
    {
        this.fromStateId = fromStateId;
    }

    public Integer getToStateId()
    {
        return toStateId;
    }

    public void setToStateId(final Integer toStateId)
    {
        this.toStateId = toStateId;
    }

    public String getEventTypeName()
    {
        return eventTypeName;
    }

    public void setEventTypeName(final String eventTypeName)
    {
        this.eventTypeName = eventTypeName;
    }

    public String getFromStateName()
    {
        return fromStateName;
    }

    public void setFromStateName(final String fromStateName)
    {
        this.fromStateName = fromStateName;
    }

    public String getToStateName()
    {
        return toStateName;
    }

    public void setToStateName(final String toStateName)
    {
        this.toStateName = toStateName;
    }

    @Override
    public final Event clone()
    {
        try
        {
            return (Event)super.clone();
        }
        catch (CloneNotSupportedException e)
        {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean equals(final Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null || getClass() != obj.getClass())
        {
            return false;
        }

        final Event that = (Event)obj;

        if (content != null ? !content.equals(that.content) : that.content != null)
        {
            return false;
        }
        if (eventTypeId != null ? !eventTypeId.equals(that.eventTypeId) : that.eventTypeId != null)
        {
            return false;
        }
        if (eventTypeName != null ? !eventTypeName.equals(that.eventTypeName) : that.eventTypeName != null)
        {
            return false;
        }
        if (fromStateId != null ? !fromStateId.equals(that.fromStateId) : that.fromStateId != null)
        {
            return false;
        }
        if (fromStateName != null ? !fromStateName.equals(that.fromStateName) : that.fromStateName != null)
        {
            return false;
        }
        if (id != null ? !id.equals(that.id) : that.id != null)
        {
            return false;
        }
        if (isDeferred != null ? !isDeferred.equals(that.isDeferred) : that.isDeferred != null)
        {
            return false;
        }
        if (processedOn != null ? !processedOn.equals(that.processedOn) : that.processedOn != null)
        {
            return false;
        }
        if (protocol != null ? !protocol.equals(that.protocol) : that.protocol != null)
        {
            return false;
        }
        if (runId != null ? !runId.equals(that.runId) : that.runId != null)
        {
            return false;
        }
        if (storedOn != null ? !storedOn.equals(that.storedOn) : that.storedOn != null)
        {
            return false;
        }
        if (toStateId != null ? !toStateId.equals(that.toStateId) : that.toStateId != null)
        {
            return false;
        }
        if (toStateName != null ? !toStateName.equals(that.toStateName) : that.toStateName != null)
        {
            return false;
        }
        if (transitionName != null ? !transitionName.equals(that.transitionName) : that.transitionName != null)
        {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (protocol != null ? protocol.hashCode() : 0);
        result = 31 * result + (content != null ? content.hashCode() : 0);
        result = 31 * result + (storedOn != null ? storedOn.hashCode() : 0);
        result = 31 * result + (processedOn != null ? processedOn.hashCode() : 0);
        result = 31 * result + (isDeferred != null ? isDeferred.hashCode() : 0);
        result = 31 * result + (runId != null ? runId.hashCode() : 0);
        result = 31 * result + (eventTypeId != null ? eventTypeId.hashCode() : 0);
        result = 31 * result + (transitionName != null ? transitionName.hashCode() : 0);
        result = 31 * result + (fromStateId != null ? fromStateId.hashCode() : 0);
        result = 31 * result + (toStateId != null ? toStateId.hashCode() : 0);
        result = 31 * result + (eventTypeName != null ? eventTypeName.hashCode() : 0);
        result = 31 * result + (fromStateName != null ? fromStateName.hashCode() : 0);
        result = 31 * result + (toStateName != null ? toStateName.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "Event{"
                + "id=" + id
                + ", protocol='" + protocol + '\''
                + ", content='" + content + '\''
                + ", storedOn=" + storedOn
                + ", processedOn=" + processedOn
                + ", isDeferred=" + isDeferred
                + ", runId=" + runId
                + ", eventTypeId=" + eventTypeId
                + ", transitionName='" + transitionName + '\''
                + ", fromStateId=" + fromStateId
                + ", toStateId=" + toStateId
                + ", eventTypeName='" + eventTypeName + '\''
                + ", fromStateName='" + fromStateName + '\''
                + ", toStateName='" + toStateName + '\''
                + '}';
    }

}
