/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import net.sf.dropboxmq.workflow.adapters.CollectionAdapter;
import net.sf.dropboxmq.workflow.adapters.EventAdapter;
import net.sf.dropboxmq.workflow.data.Event;
import net.sf.dropboxmq.workflow.data.EventPackage;
import net.sf.dropboxmq.workflow.data.EventType;
import net.sf.dropboxmq.workflow.data.Namespace;
import net.sf.dropboxmq.workflow.data.Process;
import net.sf.dropboxmq.workflow.data.Run;
import net.sf.dropboxmq.workflow.data.Transition;
import net.sf.dropboxmq.workflow.persistence.EventPersistence;
import net.sf.dropboxmq.workflow.persistence.PersistenceFactory;
import net.sf.dropboxmq.workflow.persistence.ProcessPersistence;
import net.sf.dropboxmq.workflow.persistence.RunPersistence;
import net.sf.dropboxmq.workflow.persistence.TransitionPersistence;
import net.sf.dropboxmq.workflow.xml.DateFormatter;
import net.sf.dropboxmq.workflow.xml.PrettyPrinter;
import net.sf.dropboxmq.workflow.xml.SimpleNamespaceContext;
import net.sf.dropboxmq.workflow.xml.WorkflowTransformerFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Created: 08 Sep 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class WorkflowProcessor
{
    private static final Log log = LogFactory.getLog(WorkflowProcessor.class);

    private final String processorName;
    private final PersistenceFactory persistenceFactory;
    private final WorkflowTransformerFactory transformerFactory;

    private SimpleNamespaceContext namespaceContext = null;
    private final List<RuntimeEventType> eventTypes = new ArrayList<RuntimeEventType>();

    static class RuntimeEventType
    {
        private final EventType eventType;
        private final XPathExpression testXPath;
        private final XPathExpression keyXPath;
        private final XPathExpression contextXPath;
        private final XPathExpression parentKeyXPath;

        RuntimeEventType(final EventType eventType, final XPathExpression testXPath, final XPathExpression keyXPath,
                final XPathExpression contextXPath, final XPathExpression parentKeyXPath)
        {
            this.eventType = eventType;
            this.testXPath = testXPath;
            this.keyXPath = keyXPath;
            this.contextXPath = contextXPath;
            this.parentKeyXPath = parentKeyXPath;
        }

        EventType getEventType()
        {
            return eventType;
        }
    }

    public WorkflowProcessor(final String processorName, final PersistenceFactory persistenceFactory,
            final WorkflowTransformerFactory transformerFactory)
    {
        this.processorName = processorName;
        this.persistenceFactory = persistenceFactory;
        this.transformerFactory = transformerFactory;
    }

    public void initialize()
    {
        final Collection<Namespace> namespaces
                = persistenceFactory.getNamespacePersistence().getNamespacesByProcessor(processorName);
        namespaceContext = prepareNamespaceContext(namespaces);
        try
        {
            prepareEventTypes();
        }
        catch (XPathExpressionException e)
        {
            throw new RuntimeException(e);
        }
    }

    static SimpleNamespaceContext prepareNamespaceContext(final Collection<Namespace> namespaces)
    {
        final SimpleNamespaceContext namespaceContext = new SimpleNamespaceContext();
        for (final Namespace namespace : namespaces)
        {
            namespaceContext.addNamespace(namespace.getPrefix(), namespace.getURI());
        }
        return namespaceContext;
    }

    void prepareEventTypes() throws XPathExpressionException
    {
        final Collection<EventType> persistenceEventTypes
                = persistenceFactory.getEventTypePersistence().getEnabledEventTypesByProcessor(processorName);
        for (final EventType persistenceEventType : persistenceEventTypes)
        {
            eventTypes.add(prepareEventType(persistenceEventType, namespaceContext));
        }
    }

    static RuntimeEventType prepareEventType(
            final EventType persistenceEventType, final SimpleNamespaceContext namespaceContext)
            throws XPathExpressionException
    {
        final XPath xPathCompiler = XPathFactory.newInstance().newXPath();
        xPathCompiler.setNamespaceContext(namespaceContext);

        final XPathExpression testXPath = xPathCompiler.compile(persistenceEventType.getTestXPath());
        final XPathExpression keyXPath
                = compileOptionalXPath(persistenceEventType.getKeyXPath(), xPathCompiler);
        final XPathExpression contextXPath
                = compileOptionalXPath(persistenceEventType.getContextXPath(), xPathCompiler);
        final XPathExpression parentKeyXPath
                = compileOptionalXPath(persistenceEventType.getParentKeyXPath(), xPathCompiler);
        return new RuntimeEventType(persistenceEventType, testXPath, keyXPath, contextXPath, parentKeyXPath);
    }

    static XPathExpression compileOptionalXPath(final String xPath, final XPath xPathCompiler)
            throws XPathExpressionException
    {
        XPathExpression xPathExpression = null;
        if (xPath != null)
        {
            xPathExpression = xPathCompiler.compile(xPath);
        }
        return xPathExpression;
    }

    public void onEvent(final String protocol, final String content, final Map<String, String> properties,
            final EventAdapter eventAdapter)
    {
        final Collection<EventPackage> childEvents = new ArrayList<EventPackage>();
        Element runHistory = null;
        try
        {
            runHistory = newRunHistory();

            final Event event = new Event();
            event.setProtocol(protocol);
            event.setContent(content);

            final Node currentContent = addEvent(runHistory, event, properties, true, true, eventAdapter);

            final RuntimeEventType eventType = findEventType(currentContent);
            event.setEventTypeId(eventType.eventType.getId());
            event.setEventTypeName(eventType.eventType.getName());
            updateEventTypeAttribute(event, currentContent);
            if (eventType.eventType.isBroadcast())
            {
                final Collection<Run> runs = getBroadcastRuns(currentContent, eventType);
                for (final Run run : runs)
                {
                    final Document broadcastDocument = (Document)runHistory.getOwnerDocument().cloneNode(true);
                    final Node broadcastHistory = broadcastDocument.getDocumentElement();
                    childEvents.addAll(processEvent(event, properties, broadcastHistory, run, eventAdapter));
                }
            }
            else
            {
                final Run run = getRun(currentContent, eventType);
                childEvents.addAll(processEvent(event, properties, currentContent, run, eventAdapter));
            }
        }
        catch (XPathExpressionException e)
        {
            throw new RuntimeException(e);
        }
        catch (ParserConfigurationException e)
        {
            throw new RuntimeException(e);
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
        catch (SAXException e)
        {
            throw new RuntimeException(e);
        }
        catch (TransformerException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            if (runHistory != null)
            {
                log.info("Final run history document: " + PrettyPrinter.prettyPrint(runHistory.getOwnerDocument()));
            }
        }

        for (final EventPackage childEvent : childEvents)
        {
            onEvent(childEvent.getProtocol(), childEvent.getContent(), childEvent.getEventProperties(), eventAdapter);
        }
    }

    static Element newRunHistory() throws ParserConfigurationException
    {
        final Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        final Element runHistory = document.createElement("run");
        document.appendChild(runHistory);
        return runHistory;
    }

    static Node addEvent(final Node runHistory, final Event event, final Map<String, String> properties,
            final boolean current, final boolean append, final EventAdapter eventAdapter)
            throws IOException, SAXException, ParserConfigurationException
    {
        final Document parentDocument = runHistory.getOwnerDocument();
        final Element eventElement = parentDocument.createElement(event.getProtocol() + "-event");
        if (current)
        {
            eventElement.setAttribute("current", "true");
        }

        if (append)
        {
            runHistory.appendChild(eventElement);
        }
        else
        {
            runHistory.insertBefore(eventElement, runHistory.getFirstChild());
        }

        if (properties != null)
        {
            eventAdapter.renderProperties(properties, event.getProtocol(), eventElement);
        }

        final Element content = parentDocument.createElement(CollectionAdapter.CONTENT);
        final String contentString = event.getContent();
        if (contentString != null && contentString.length() > 0)
        {
            final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            final DocumentBuilder builder = factory.newDocumentBuilder();
            final Document contentDocument = builder.parse(new InputSource(new StringReader(event.getContent())));

            final Node context
                    = content.appendChild(parentDocument.importNode(contentDocument.getDocumentElement(), true));
            content.appendChild(context);
        }
        else
        {
            content.setAttribute("null", "true");
        }
        eventElement.appendChild(content);

        updateEventTypeAttribute(event, content);
        updateEventTimestampAttributes(event, content);
        updateEventTransitionAttributes(event, content);

        return content;
    }

    static void updateEventTypeAttribute(final Event event, final Node content)
    {
        final Element eventElement = (Element)content.getParentNode();
        if (event.getEventTypeName() != null)
        {
            eventElement.setAttribute("event-type", event.getEventTypeName());
        }
    }

    static void updateEventTimestampAttributes(final Event event, final Node content)
    {
        final Element eventElement = (Element)content.getParentNode();
        if (event.getStoredOn() != null)
        {
            eventElement.setAttribute("stored-on", DateFormatter.formatDate(event.getStoredOn()));
            eventElement.setAttribute("stored-on-millis", String.valueOf(event.getStoredOn().getTime()));
        }
        if (event.getProcessedOn() != null)
        {
            eventElement.setAttribute("processed-on", DateFormatter.formatDate(event.getProcessedOn()));
            eventElement.setAttribute("processed-on-millis", String.valueOf(event.getProcessedOn().getTime()));
        }
    }

    static void updateEventTransitionAttributes(final Event event, final Node content)
    {
        if (event.isDeferred() != null && !event.isDeferred())
        {
            final Element eventElement = (Element)content.getParentNode();
            eventElement.setAttribute("transition-name", event.getTransitionName());
            eventElement.setAttribute("from-state", event.getFromStateName());
            eventElement.setAttribute("to-state", event.getToStateName());
        }
    }

    RuntimeEventType findEventType(final Node currentContent) throws XPathExpressionException
    {
        RuntimeEventType foundEventType = null;
        for (final RuntimeEventType eventType : eventTypes)
        {
            final Boolean results = (Boolean)eventType.testXPath.evaluate(currentContent, XPathConstants.BOOLEAN);
            if (results != null && results)
            {
                if (foundEventType != null)
                {
                    throw new RuntimeException("Event matches more than one event type, first: "
                            + foundEventType.eventType.getName() + ", second: " + eventType.eventType.getName());
                }
                foundEventType = eventType;
            }
        }

        if (foundEventType == null)
        {
            throw new RuntimeException("Could not identify event type");
        }

        log.info("Identified event type: " + foundEventType.eventType.getName()
                + ", process type: " + foundEventType.eventType.getProcessTypeName());

        return foundEventType;
    }

    List<Run> getBroadcastRuns(final Node currentContent, final RuntimeEventType eventType)
            throws XPathExpressionException
    {
        final int processTypeId = eventType.eventType.getProcessTypeId();
        final RunPersistence persistence = persistenceFactory.getRunPersistence();
        final List<Run> runs;
        if (eventType.keyXPath == null)
        {
            runs = persistence.getActiveRunsByProcessType(processTypeId);
        }
        else
        {
            runs = new ArrayList<Run>();
            final NodeList keys = (NodeList)eventType.keyXPath.evaluate(currentContent, XPathConstants.NODESET);
            final Collection<String> sortedKeys = sortKeys(keys);
            for (final String key : sortedKeys)
            {
                Run run = persistence.getLastUpdatedRunByKeyAndProcessType(key, processTypeId);
                boolean addRun = true;
                if (run == null || run.getCurrentStateId() == null)
                {
                    addRun = false;
                    if (eventType.eventType.getStartingEnum() == EventType.EventTypeStarting.WillNotStartNewRun)
                    {
                        log.warn("DIRECTED BROADCAST LOST FOR KEY: " + key);
                    }
                    else
                    {
                        run = createNewRun(key, currentContent, eventType);
                        addRun = true;
                    }
                }

                if (addRun)
                {
                    runs.add(run);
                }
            }
        }
        return runs;
    }

    static Collection<String> sortKeys(final NodeList keys)
    {
        final Set<String> sortedKeys = new TreeSet<String>();
        if (keys != null)
        {
            for (int i = 0; i < keys.getLength(); i++)
            {
                final String key = keys.item(i).getTextContent();
                if (key != null && key.length() > 0)
                {
                    sortedKeys.add(key);
                }
            }
        }
        return sortedKeys;
    }

    Run createNewRun(final String key, final Node currentContent, final RuntimeEventType eventType)
            throws XPathExpressionException
    {
        final int processTypeId = eventType.eventType.getProcessTypeId();
        final ProcessPersistence processPersistence = persistenceFactory.getProcessPersistence();
        Process process = processPersistence.getProcessByKey(key, processTypeId);
        if (process == null)
        {
            process = new Process();
            process.setProcessKey(key);
            process.setProcessTypeId(processTypeId);
            processPersistence.storeProcess(process);
            log.info("Created process: " + process.getId() + ", key: " + key);
        }
        else
        {
            log.info("Found process: " + process.getId() + ", key: " + key);
        }

        final Run run = new Run();
        if (eventType.contextXPath != null)
        {
            final String context = eventType.contextXPath.evaluate(currentContent);
            if (context != null && context.length() > 0)
            {
                run.setContext(context);
            }
        }
        final Run parentRun = findParentRun(currentContent, eventType);
        if (parentRun != null)
        {
            run.setParentRunId(parentRun.getId());
            run.setParentProcessKey(parentRun.getProcessKey());
            run.setParentContext(parentRun.getContext());
            run.setParentProcessTypeName(parentRun.getProcessTypeName());
        }
        run.setProcessId(process.getId());
        run.setProcessTypeId(processTypeId);
        run.setProcessTypeName(eventType.eventType.getProcessTypeName());
        run.setProcessKey(key);
        persistenceFactory.getRunPersistence().storeRun(run);
        log.info("Created run: " + run.getId() + ", key: " + key + ", context: " + run.getContext()
                + ", process id: " + run.getId() + ", process type: " + run.getProcessTypeName());
        return run;
    }

    Run findParentRun(final Node currentContent, final RuntimeEventType eventType)
    {
        Run parentRun = null;
        final Integer parentProcessTypeId = eventType.eventType.getParentProcessTypeId();
        if (eventType.parentKeyXPath != null && parentProcessTypeId != null)
        {
            String parentKey = null;
            try
            {
                parentKey = eventType.parentKeyXPath.evaluate(currentContent);
            }
            catch (XPathExpressionException e)
            {
                log.warn("COULD NOT EVALUATE PARENT KEY XPATH: " + e.getMessage());
            }
            if (parentKey != null && parentKey.length() > 0)
            {
                final RunPersistence runPersistence = persistenceFactory.getRunPersistence();
                parentRun = runPersistence.getLastUpdatedRunByKeyAndProcessType(parentKey, parentProcessTypeId);
                if (parentRun == null)
                {
                    log.warn("COULD NOT FIND PARENT RUN, key: " + parentKey
                            + ", parent process type: " + eventType.eventType.getParentProcessTypeName());
                }
            }
        }
        return parentRun;
    }

    Run getRun(final Node currentContent, final RuntimeEventType eventType) throws XPathExpressionException
    {
        final RunPersistence persistence = persistenceFactory.getRunPersistence();
        final String key = eventType.keyXPath.evaluate(currentContent);
        if (key == null || key.length() == 0)
        {
            throw new RuntimeException("Key xpath evaluation did not return a valid key, event type: "
                    + eventType.getEventType().getName());
        }

        Run run = persistence.getLastUpdatedRunByKeyAndProcessType(key, eventType.eventType.getProcessTypeId());
        if (run == null || run.getCurrentStateId() == null)
        {
            if (eventType.eventType.getStartingEnum() == EventType.EventTypeStarting.WillNotStartNewRun)
            {
                throw new RuntimeException("No active run and event type specified WillNotStartNewRun,"
                        + " event type: " + eventType.eventType.getName());
            }
            run = createNewRun(key, currentContent, eventType);
        }
        else
        {
            if (eventType.eventType.getStartingEnum() == EventType.EventTypeStarting.MustStartNewRun)
            {
                throw new RuntimeException("Active run exists and event type specified MustStartNewRun,"
                        + " run id: " + run.getId() + ", event type: " + eventType.eventType.getName());
            }
            log.info("Found run: " + run.getId() + ", key: " + key + ", process id: " + run.getId());
        }

        return run;
    }

    Collection<EventPackage> processEvent(final Event event, final Map<String, String> properties,
            final Node currentContent, final Run run, final EventAdapter eventAdapter)
            throws IOException, SAXException, ParserConfigurationException, XPathExpressionException,
            TransformerException
    {
        boolean isDeferred = false;
        final Integer fromStateId = run.getCurrentStateId();
        if (fromStateId != null)
        {
            isDeferred = persistenceFactory.getDeferredEventTypePersistence().isEventTypeDeferred(
                    fromStateId, event.getEventTypeId());
        }

        final Element runHistory = currentContent.getOwnerDocument().getDocumentElement();
        updateRunHistory(runHistory, run);

        Map<Integer, Map<String, String>> eventProperties = null;
        if (!isDeferred)
        {
            eventProperties = persistenceFactory.getEventPropertyPersistence().getEventPropertiesByRun(run.getId());
            completeRunHistory(run, runHistory, eventProperties, eventAdapter);
        }

        event.setDeferred(isDeferred);
        event.setRunId(run.getId());

        final Collection<EventPackage> childEvents = new ArrayList<EventPackage>();
        if (!isDeferred)
        {
            executeTransition(event, eventProperties, run, currentContent, childEvents, eventAdapter);
            persistenceFactory.getRunPersistence().updateState(run.getId(), run.getCurrentStateId());
            updateCurrentStateAttribute(runHistory, run);
        }

        persistenceFactory.getEventPersistence().storeEvent(event);
        log.info("Stored event: " + event.getEventTypeName() + ", id: " + event.getId()
                + ", " + (event.isDeferred() ? "deferred" : "not deferred"));
        if (properties != null && !properties.isEmpty())
        {
            persistenceFactory.getEventPropertyPersistence().storeEventProperties(event.getId(), properties);
        }

        updateEventTimestampAttributes(event, currentContent);

        return childEvents;
    }

    static void updateRunHistory(final Element runHistory, final Run run)
    {
        runHistory.setAttribute("context", run.getContext());
        runHistory.setAttribute("process-type", run.getProcessTypeName());
        runHistory.setAttribute("process-key", run.getProcessKey());
        if (run.getParentProcessTypeName() != null)
        {
            runHistory.setAttribute("parent-process-type", run.getParentProcessTypeName());
            runHistory.setAttribute("parent-process-key", run.getParentProcessKey());
            runHistory.setAttribute("parent-context", run.getParentContext());
        }
        updateCurrentStateAttribute(runHistory, run);
    }

    static void updateCurrentStateAttribute(final Element runHistory, final Run run)
    {
        runHistory.setAttribute("current-state", run.getCurrentStateName());
    }

    void completeRunHistory(final Run run, final Node runHistory,
            final Map<Integer, Map<String, String>> eventProperties, final EventAdapter eventAdapter)
            throws IOException, SAXException, ParserConfigurationException
    {
        final EventPersistence persistence = persistenceFactory.getEventPersistence();
        final List<Event> events = persistence.getNonDeferredEventsByRun(run.getId());
        for (final Event event : events)
        {
            addEvent(runHistory, event, eventProperties.get(event.getId()), false, true, eventAdapter);
        }
    }

    void executeTransition(final Event event, final Map<Integer, Map<String, String>> eventProperties,
            final Run run, final Node currentContent, final Collection<EventPackage> childEvents,
            final EventAdapter eventAdapter)
            throws XPathExpressionException, TransformerException,
            ParserConfigurationException, IOException, SAXException
    {
        final Transition transition = selectTransition(currentContent.getOwnerDocument(), run);
        run.setCurrentStateId(transition.getToStateId());
        run.setCurrentStateName(transition.getToStateName());

        if (transition.getTransformerFilePath() != null)
        {
            final Collection<EventPackage> newChildEvents = executeTransformer(
                    currentContent.getOwnerDocument(), transition.getTransformerFilePath(), eventAdapter);
            if (newChildEvents != null)
            {
                log.info("Transformer added " + newChildEvents.size() + " child event(s)");
                childEvents.addAll(newChildEvents);
            }
        }

        event.setTransitionName(transition.getName());
        event.setFromStateId(transition.getFromStateId());
        event.setFromStateName(transition.getFromStateName());
        event.setToStateId(transition.getToStateId());
        event.setToStateName(transition.getToStateName());
        updateEventTransitionAttributes(event, currentContent);

        final EventPersistence eventPersistence = persistenceFactory.getEventPersistence();
        if (run.getCurrentStateId() != null)
        {
            final Event undeferredEvent = eventPersistence.getNextUndeferredEvent(run.getId(), run.getCurrentStateId());
            if (undeferredEvent != null)
            {
                log.info("Undeferring event: " + undeferredEvent.getEventTypeName()
                        + ", id: " + undeferredEvent.getId());
                undeferredEvent.setDeferred(false);
                ((Element)currentContent.getParentNode()).removeAttribute("current");
                final Node runHistory = currentContent.getOwnerDocument().getDocumentElement();
                final Node newCurrentContent = addEvent(runHistory, undeferredEvent,
                        eventProperties.get(undeferredEvent.getId()), true, false, eventAdapter);
                executeTransition(
                        undeferredEvent, eventProperties, run, newCurrentContent, childEvents, eventAdapter);
                eventPersistence.undeferEvent(undeferredEvent);
                updateEventTimestampAttributes(undeferredEvent, newCurrentContent);
            }
        }
    }

    Transition selectTransition(final Document runHistory, final Run run) throws XPathExpressionException
    {
        final TransitionPersistence persistence = persistenceFactory.getTransitionPersistence();
        final Collection<Transition> transitions
                = persistence.getTransitionsFromState(run.getCurrentStateId(), run.getProcessTypeId());

        final XPath xPath = XPathFactory.newInstance().newXPath();
        Transition selectedTransition = null;
        for (final Transition transition : transitions)
        {
            final Boolean selected = (Boolean)xPath.evaluate(
                    transition.getTestXPath(), runHistory.getDocumentElement(), XPathConstants.BOOLEAN);
            if (selected != null && selected)
            {
                if (selectedTransition != null)
                {
                    throw new RuntimeException("Multiple transitions selected, first: " + selectedTransition.getName()
                            + ", second: " + transition.getName());
                }
                selectedTransition = transition;
            }
        }

        if (selectedTransition == null)
        {
            throw new RuntimeException("No transitions selected");
        }

        log.info("Selected transition: " + selectedTransition.getName()
                + ", test: " + selectedTransition.getTestXPath());
        log.info("Transitioned from state: " + selectedTransition.getFromStateName()
                + (selectedTransition.getFromStateName() == null ? " (initial)" : "")
                + " to state: " + selectedTransition.getToStateName()
                + (selectedTransition.getToStateName() == null ? " (terminal)" : "")
                + ", executing transformer: " + selectedTransition.getTransformerFilePath());

        return selectedTransition;
    }

    Collection<EventPackage> executeTransformer(
            final Document runHistory, final String transformerFilePath, final EventAdapter eventAdapter)
            throws ParserConfigurationException, TransformerException
    {
        final Transformer transformer = transformerFactory.getTransformer(transformerFilePath);

        final Document resultDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        transformer.transform(new DOMSource(runHistory), new DOMResult(resultDocument));

        log.info("Transformer results: " + PrettyPrinter.prettyPrint(resultDocument));

        return eventAdapter.processResults(resultDocument.getDocumentElement());
    }

}
