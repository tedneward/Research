/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import net.sf.dropboxmq.workflow.persistence.EventPropertyPersistence;

/**
 * Created: 06 02 2011
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class EventPropertyPersistenceImpl implements EventPropertyPersistence
{
    private static final String INSERT = "insert into EVENT_PROPERTY (NAME, VALUE, EVENT_ID) values (?, ?, ?)";
    private static final String SELECT = "select ep.NAME, ep.VALUE, ep.EVENT_ID from EVENT_PROPERTY ep"
            + " join EVENT e on e.ID = ep.EVENT_ID"
            + " where e.RUN_ID = ?";

    private final PersistenceFactoryImpl persistenceFactory;

    public EventPropertyPersistenceImpl(final PersistenceFactoryImpl persistenceFactory)
    {
        this.persistenceFactory = persistenceFactory;
    }

    @Override
    public void storeEventProperties(final int eventId, final Map<String, String> properties)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(INSERT);
            for (final Map.Entry<String, String> entry : properties.entrySet())
            {
                statement.setString(1, entry.getKey());
                statement.setString(2, entry.getValue());
                statement.setInt(3, eventId);
                statement.addBatch();
            }

            final int[] insertCounts = statement.executeBatch();
            for (final int insertCount : insertCounts)
            {
                if (insertCount != 1)
                {
                    throw new RuntimeException("Insert statement execute did not return 1");
                }
            }
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    JDBCHelper newJDBCHelper()
    {
        return new JDBCHelper();
    }

    @Override
    public Map<Integer, Map<String, String>> getEventPropertiesByRun(final int runId)
    {
        final Map<Integer, Map<String, String>> propertiesByEvent = new HashMap<Integer, Map<String, String>>();
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(SELECT);
            statement.setInt(1, runId);
            final ResultSet results = statement.executeQuery();
            while (results.next())
            {
                final String name = results.getString("NAME");
                final String value = results.getString("VALUE");
                final int eventId = results.getInt("EVENT_ID");

                Map<String, String> properties = propertiesByEvent.get(eventId);
                if (properties == null)
                {
                    properties = new HashMap<String, String>();
                    propertiesByEvent.put(eventId, properties);
                }
                properties.put(name, value);
            }
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
        return propertiesByEvent;
    }
}
