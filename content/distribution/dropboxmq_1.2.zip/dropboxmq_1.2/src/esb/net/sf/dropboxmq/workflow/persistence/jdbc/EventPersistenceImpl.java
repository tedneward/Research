/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.jdbc;

import java.io.StringReader;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import net.sf.dropboxmq.workflow.data.Event;
import net.sf.dropboxmq.workflow.persistence.EventPersistence;

/**
 * Created: 08 Feb 2011
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class EventPersistenceImpl implements EventPersistence
{
    private static final String SUB_SELECT_PROTOCOL = "select ep.ID from EVENT_PROTOCOL ep where ep.NAME = ?";
    private static final String INSERT = "insert into EVENT (EVENT_PROTOCOL_ID, CONTENT, PROCESSED_ON, IS_DEFERRED,"
            + " RUN_ID, EVENT_TYPE_ID, TRANSITION_NAME_ID, FROM_STATE_ID, TO_STATE_ID)"
            + " values ((" + SUB_SELECT_PROTOCOL + "), ?, ";
    private static final String SUB_SELECT_TRANSITION_NAME = "select tn.ID from TRANSITION_NAME tn where tn.NAME = ?";
    private static final String INSERT_NOT_DEFERRED
            = INSERT + "current_timestamp, false, ?, ?, (" + SUB_SELECT_TRANSITION_NAME + "), ?, ?)";
    private static final String INSERT_DEFERRED
            = INSERT + "null, true, ?, ?, (" + SUB_SELECT_TRANSITION_NAME + "), ?, ?)";
    private static final String SELECT = "select e.ID, ep.NAME as PROTOCOL, e.CONTENT, e.STORED_ON, e.PROCESSED_ON,"
            + " e.IS_DEFERRED, e.RUN_ID, e.EVENT_TYPE_ID, tn.NAME as TRANSITION_NAME, e.FROM_STATE_ID, e.TO_STATE_ID,"
            + " et.NAME as EVENT_TYPE_NAME, s1.NAME as FROM_STATE_NAME, s2.NAME as TO_STATE_NAME from EVENT e"
            + " join EVENT_PROTOCOL ep on ep.ID = e.EVENT_PROTOCOL_ID"
            + " left outer join TRANSITION_NAME tn on tn.ID = e.TRANSITION_NAME_ID"
            + " join EVENT_TYPE et on et.ID = e.EVENT_TYPE_ID"
            + " left outer join STATE s1 on s1.ID = FROM_STATE_ID"
            + " left outer join STATE s2 on s2.ID = TO_STATE_ID";
    private static final String SELECT_ALL_NON_DEFERRED = SELECT
            + " where e.IS_DEFERRED = false and e.RUN_ID = ?"
            + " order by e.PROCESSED_ON desc, e.ID asc";
    private static final String UPDATE = "update EVENT e set"
            + " e.TRANSITION_NAME_ID = (" + SUB_SELECT_TRANSITION_NAME + "), e.FROM_STATE_ID = ?,"
            + " e.TO_STATE_ID = ?, e.PROCESSED_ON = current_timestamp, e.IS_DEFERRED = false"
            + " where e.ID = ?";
    private static final String SELECT_NEXT_UNDEFERRED = SELECT
            + " join RUN r on r.ID = e.RUN_ID"
            + " where e.RUN_ID = ? and e.IS_DEFERRED = true and e.EVENT_TYPE_ID not in"
            + " (select det.EVENT_TYPE_ID from DEFERRED_EVENT_TYPE det where det.STATE_ID = ?)"
            + " order by e.STORED_ON asc limit 1";
    private static final String SELECT_TIMESTAMPS = "select STORED_ON, PROCESSED_ON from EVENT where ID = ?";

    private final PersistenceFactoryImpl persistenceFactory;

    public EventPersistenceImpl(final PersistenceFactoryImpl persistenceFactory)
    {
        this.persistenceFactory = persistenceFactory;
    }

    @Override
    public void storeEvent(final Event event)
    {
        final JDBCHelper helper = newJDBCHelper();
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            String insert = INSERT_NOT_DEFERRED;
            if (event.isDeferred())
            {
                insert = INSERT_DEFERRED;
            }
            statement = connection.prepareStatement(insert);
            statement.setString(1, event.getProtocol());
            statement.setClob(2, new StringReader(event.getContent()));
            statement.setInt(3, event.getRunId());
            statement.setInt(4, event.getEventTypeId());
            statement.setString(5, event.getTransitionName());
            if (event.getFromStateId() == null)
            {
                statement.setNull(6, Types.BIGINT);
            }
            else
            {
                statement.setInt(6, event.getFromStateId());
            }
            if (event.getToStateId() == null)
            {
                statement.setNull(7, Types.BIGINT);
            }
            else
            {
                statement.setInt(7, event.getToStateId());
            }
            if (statement.executeUpdate() != 1)
            {
                throw new RuntimeException("PreparedStatement.executeUpdate() for insert statement did not return 1");
            }
            event.setId(helper.getLastInsertId(connection));

            updateTimestamps(event, connection);
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            helper.safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    JDBCHelper newJDBCHelper()
    {
        return new JDBCHelper();
    }

    private void updateTimestamps(final Event event, final Connection connection)
    {
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(SELECT_TIMESTAMPS);
            statement.setInt(1, event.getId());
            final ResultSet results = statement.executeQuery();
            if (results.next())
            {
                event.setStoredOn(results.getTimestamp("STORED_ON"));
                event.setProcessedOn(results.getTimestamp("PROCESSED_ON"));
            }

            if (results.next())
            {
                throw new RuntimeException("select by unique field returned multiple rows");
            }
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
        }
    }

    @Override
    public List<Event> getNonDeferredEventsByRun(final int runId)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(SELECT_ALL_NON_DEFERRED);
            statement.setInt(1, runId);
            final ResultSet results = statement.executeQuery();
            final List<Event> events = new ArrayList<Event>();
            while (results.next())
            {
                events.add(newEventFromResults(results));
            }

            return events;
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    Event newEventFromResults(final ResultSet results) throws SQLException
    {
        final Event event = new Event();
        event.setId(results.getInt("ID"));
        event.setProtocol(results.getString("PROTOCOL"));
        final Clob content = results.getClob("CONTENT");
        event.setContent(content.getSubString(1L, (int)content.length()));
        event.setStoredOn(results.getTimestamp("STORED_ON"));
        event.setProcessedOn(results.getTimestamp("PROCESSED_ON"));
        event.setDeferred(results.getBoolean("IS_DEFERRED"));
        event.setRunId(results.getInt("RUN_ID"));
        event.setEventTypeId(results.getInt("EVENT_TYPE_ID"));
        event.setTransitionName(results.getString("TRANSITION_NAME"));
        event.setFromStateId(results.getInt("FROM_STATE_ID"));
        event.setToStateId(results.getInt("TO_STATE_ID"));
        event.setEventTypeName(results.getString("EVENT_TYPE_NAME"));
        event.setFromStateName(results.getString("FROM_STATE_NAME"));
        event.setToStateName(results.getString("TO_STATE_NAME"));
        return event;
    }

    @Override
    public void undeferEvent(final Event event)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(UPDATE);
            statement.setString(1, event.getTransitionName());
            statement.setInt(2, event.getFromStateId());
            if (event.getToStateId() == null)
            {
                statement.setNull(3, Types.BIGINT);
            }
            else
            {
                statement.setInt(3, event.getToStateId());
            }
            statement.setInt(4, event.getId());
            if (statement.executeUpdate() != 1)
            {
                throw new RuntimeException("PreparedStatement.executeUpdate() for update statement did not return 1");
            }
            updateTimestamps(event, connection);
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    @Override
    public Event getNextUndeferredEvent(final int runId, final int currentStateId)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(SELECT_NEXT_UNDEFERRED);
            statement.setInt(1, runId);
            statement.setInt(2, currentStateId);
            final ResultSet results = statement.executeQuery();
            Event event = null;
            if (results.next())
            {
                event = newEventFromResults(results);
            }

            if (results.next())
            {
                throw new RuntimeException("select by unique field returned multiple rows");
            }

            return event;
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

}
