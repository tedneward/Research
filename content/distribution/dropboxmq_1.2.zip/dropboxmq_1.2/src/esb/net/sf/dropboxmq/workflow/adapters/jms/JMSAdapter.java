/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.adapters.jms;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJBContext;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.XAConnection;
import javax.jms.XAConnectionFactory;
import net.sf.dropboxmq.workflow.adapters.CollectionAdapter;
import net.sf.dropboxmq.workflow.adapters.EventAdapter;
import net.sf.dropboxmq.workflow.data.EventPackage;
import net.sf.dropboxmq.workflow.xml.DateFormatter;
import net.sf.dropboxmq.workflow.xml.PrettyPrinter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Created: 16 Feb 2011
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class JMSAdapter implements EventAdapter
{
    private static final Log log = LogFactory.getLog(JMSAdapter.class);

    public static final String JMS = "jms";

    private static final String JMS_MESSAGE_ID = "JMS_MESSAGE_ID";
    private static final String JMS_TIMESTAMP = "JMS_TIMESTAMP";
    private static final String JMS_CORRELATION_ID = "JMS_CORRELATION_ID";
    private static final String JMS_REPLY_TO = "JMS_REPLY_TO";
    private static final String JMS_DESTINATION = "JMS_DESTINATION";
    private static final String JMS_DELIVERY_MODE = "JMS_DELIVERY_MODE";
    private static final String JMS_REDELIVERED = "JMS_REDELIVERED";
    private static final String JMS_TYPE = "JMS_TYPE";
    private static final String JMS_EXPIRATION = "JMS_EXPIRATION";
    private static final String JMS_PRIORITY = "JMS_PRIORITY";

    private static final String DESTINATION = "destination";
    private static final String PRIORITY = "priority";
    private static final String DELIVERY_MODE = "delivery-mode";
    private static final String CORRELATION_ID = "correlation-id";
    private static final String REPLY_TO = "reply-to";
    private static final String TYPE = "type";

    private static final String PERSISTENT = "PERSISTENT";
    private static final String NON_PERSISTENT = "NON_PERSISTENT";

    private final String defaultConnectionFactory;
    private final EJBContext ejbContext;
    private final Map<String, Session> sessions = new HashMap<String, Session>();
    private final List<Connection> connections = new ArrayList<Connection>();

    public JMSAdapter(final String defaultConnectionFactory, final EJBContext ejbContext)
    {
        this.defaultConnectionFactory = defaultConnectionFactory;
        this.ejbContext = ejbContext;
    }

    public static EventPackage convertMessage(final Message message) throws JMSException
    {
        if (!(message instanceof TextMessage))
        {
            throw new RuntimeException("Only messages of type javax.jms.TextMessage are currently supported");
        }

        final EventPackage eventPackage = new EventPackage();
        eventPackage.setContent(((TextMessage)message).getText());

        final Map<String, String> properties = new HashMap<String, String>();
        eventPackage.setEventProperties(properties);
        properties.put(JMS_MESSAGE_ID, message.getJMSMessageID());
        properties.put(JMS_TIMESTAMP, String.valueOf(message.getJMSTimestamp()));
        if (message.getJMSCorrelationID() != null)
        {
            properties.put(JMS_CORRELATION_ID, message.getJMSCorrelationID());
        }
        if (message.getJMSReplyTo() != null)
        {
            properties.put(JMS_REPLY_TO, message.getJMSReplyTo().toString());
        }
        properties.put(JMS_DESTINATION, message.getJMSDestination().toString());
        properties.put(JMS_DELIVERY_MODE,
                message.getJMSDeliveryMode() == DeliveryMode.PERSISTENT ? PERSISTENT : NON_PERSISTENT);
        properties.put(JMS_REDELIVERED, String.valueOf(message.getJMSRedelivered()));
        if (message.getJMSType() != null)
        {
            properties.put(JMS_TYPE, message.getJMSType());
        }
        if (message.getJMSExpiration() != 0L)
        {
            properties.put(JMS_EXPIRATION, String.valueOf(message.getJMSExpiration()));
        }
        properties.put(JMS_PRIORITY, String.valueOf(message.getJMSPriority()));

        final Enumeration<?> names = message.getPropertyNames();
        while (names.hasMoreElements())
        {
            final String name = (String)names.nextElement();
            properties.put(name, message.getObjectProperty(name).toString());
        }

        return eventPackage;
    }

    @Override
    public void renderProperties(
            final Map<String, String> properties, final String protocol, final Element eventElement)
    {
        final Element headerElement = eventElement.getOwnerDocument().createElement(CollectionAdapter.HEADER);
        eventElement.appendChild(headerElement);

        for (final Map.Entry<String, String> propertyEntry : properties.entrySet())
        {
            final String name = propertyEntry.getKey();
            final String value = propertyEntry.getValue();

            if (name.equals(JMS_MESSAGE_ID))
            {
                headerElement.setAttribute("message-id", value);
            }
            else if (name.equals(JMS_TIMESTAMP))
            {
                headerElement.setAttribute("timestamp", DateFormatter.formatDate(new Date(Long.parseLong(value))));
                headerElement.setAttribute("timestamp-millis", value);
            }
            else if (name.equals(JMS_CORRELATION_ID))
            {
                headerElement.setAttribute(CORRELATION_ID, value);
            }
            else if (name.equals(JMS_REPLY_TO))
            {
                headerElement.setAttribute(REPLY_TO, value);
            }
            else if (name.equals(JMS_DESTINATION))
            {
                headerElement.setAttribute(DESTINATION, value);
            }
            else if (name.equals(JMS_DELIVERY_MODE))
            {
                headerElement.setAttribute(DELIVERY_MODE, value);
            }
            else if (name.equals(JMS_REDELIVERED))
            {
                headerElement.setAttribute("redelivered", value);
            }
            else if (name.equals(JMS_TYPE))
            {
                headerElement.setAttribute(TYPE, value);
            }
            else if (name.equals(JMS_EXPIRATION))
            {
                headerElement.setAttribute("expiration", DateFormatter.formatDate(new Date(Long.parseLong(value))));
                headerElement.setAttribute("expiration-millis", value);
            }
            else if (name.equals(JMS_PRIORITY))
            {
                headerElement.setAttribute(PRIORITY, value);
            }
            else
            {
                CollectionAdapter.renderSimpleProperty(name, value, "property", eventElement);
            }
        }
    }

    @Override
    public Collection<EventPackage> processResults(final Node results)
    {
        final Element header = CollectionAdapter.findSingleChild(CollectionAdapter.HEADER, results);
        final String destinationName = header.getAttribute(DESTINATION);
        if (destinationName == null)
        {
            throw new RuntimeException("Destination must be defined in header element of jms-event");
        }
        String connectionFactory = header.getAttribute("connection-factory");
        if (connectionFactory == null || connectionFactory.length() == 0)
        {
            connectionFactory = defaultConnectionFactory;
        }
        final NodeList contents = CollectionAdapter.findSingleChild(CollectionAdapter.CONTENT, results).getChildNodes();

        try
        {
            final Session session = getSession(connectionFactory);
            final TextMessage message = session.createTextMessage();
            setHeaderAttributes(message, header);
            setProperties(message, results);
            final MessageProducer producer = session.createProducer(lookupDestination(destinationName));

            for (int i = 0; i < contents.getLength(); i++)
            {
                final Node content = contents.item(i);
                message.setText(PrettyPrinter.prettyPrint(content));
                producer.send(message, getDeliveryMode(header), getPriority(header), getTimeToLiveMillis(header));
            }
        }
        catch (JMSException e)
        {
            throw new RuntimeException(e);
        }
        return Collections.emptyList();
    }

    private Session getSession(final String connectionFactory) throws JMSException
    {
        Session session = sessions.get(connectionFactory);
        if (session == null)
        {
            log.info("Looking up connection factory: " + connectionFactory);
            final Object factory = ejbContext.lookup(connectionFactory);
            if (factory == null || !(factory instanceof ConnectionFactory))
            {
                throw new RuntimeException("Did not find XAConnectionFactory on lookup, name: "
                        + connectionFactory + ", found " + factory);
            }
            if (factory instanceof XAConnectionFactory)
            {
                final XAConnection connection = ((XAConnectionFactory)factory).createXAConnection();
                connections.add(connection);
                session = connection.createXASession();
            }
            else
            {
                log.warn("Falling back to non-XA connection");
                final Connection connection = ((ConnectionFactory)factory).createConnection();
                connections.add(connection);
                session = connection.createSession(true, Session.SESSION_TRANSACTED);
            }
            sessions.put(connectionFactory, session);
        }
        return session;
    }

    private static void setProperties(final Message message, final Node results) throws JMSException
    {
        final NodeList properties = ((Element)results).getElementsByTagName("property");
        for (int i = 0; i < properties.getLength(); i++)
        {
            final Element property = (Element)properties.item(i);
            final String name = property.getAttribute("name");
            final String value = property.getAttribute("value");
            final String type = property.getAttribute("type");

            if (type == null || type.length() == 0 || type.equals("String"))
            {
                message.setStringProperty(name, value);
            }
            else if (type.equals("Boolean"))
            {
                message.setBooleanProperty(name, Boolean.parseBoolean(value));
            }
            else if (type.equals("Byte"))
            {
                message.setByteProperty(name, Byte.parseByte(value));
            }
            else if (type.equals("Double"))
            {
                message.setDoubleProperty(name, Double.parseDouble(value));
            }
            else if (type.equals("Float"))
            {
                message.setFloatProperty(name, Float.parseFloat(value));
            }
            else if (type.equals("Integer"))
            {
                message.setIntProperty(name, Integer.parseInt(value));
            }
            else if (type.equals("Long"))
            {
                message.setLongProperty(name, Long.parseLong(value));
            }
            else if (type.equals("Short"))
            {
                message.setShortProperty(name, Short.parseShort(value));
            }
            else
            {
                throw new RuntimeException("Unknown property type: " + type + ", name: " + name);
            }
        }
    }

    private Destination lookupDestination(final String name)
    {
        return (Destination)ejbContext.lookup(name);
    }

    private void setHeaderAttributes(final TextMessage message, final Element header) throws JMSException
    {
        final String correlationId = header.getAttribute(CORRELATION_ID);
        if (correlationId != null && correlationId.length() > 0)
        {
            message.setJMSCorrelationID(correlationId);
        }
        final String replyTo = header.getAttribute(REPLY_TO);
        if (replyTo != null && replyTo.length() > 0)
        {
            message.setJMSReplyTo(lookupDestination(replyTo));
        }
        final String type = header.getAttribute(TYPE);
        if (type != null && type.length() > 0)
        {
            message.setJMSType(type);
        }
    }

    private static int getDeliveryMode(final Element header)
    {
        final String deliveryModeString = header.getAttribute(DELIVERY_MODE);
        int deliveryMode = DeliveryMode.PERSISTENT;
        if (deliveryModeString != null && deliveryModeString.length() > 0 && !deliveryModeString.equals(PERSISTENT))
        {
            if (deliveryModeString.equals(NON_PERSISTENT))
            {
                deliveryMode = DeliveryMode.NON_PERSISTENT;
            }
            else
            {
                throw new RuntimeException(DELIVERY_MODE + " attribute must be set to"
                        + " '" + PERSISTENT + "' or '" + NON_PERSISTENT + "'");
            }
        }
        return deliveryMode;
    }

    private static int getPriority(final Element header)
    {
        final String priorityString = header.getAttribute(PRIORITY);
        int priority = Message.DEFAULT_PRIORITY;
        if (priorityString != null && priorityString.length() > 0)
        {
            priority = Integer.parseInt(priorityString);
        }
        return priority;
    }

    private static long getTimeToLiveMillis(final Element header)
    {
        final String timeToLiveMillisString = header.getAttribute("time-to-live-millis");
        long timeToLiveMillis = Message.DEFAULT_TIME_TO_LIVE;
        if (timeToLiveMillisString != null && timeToLiveMillisString.length() > 0)
        {
            timeToLiveMillis = Long.parseLong(timeToLiveMillisString);
        }
        return timeToLiveMillis;
    }

    @Override
    public void close()
    {
        for (final Connection connection : connections)
        {
            try
            {
                connection.close();
            }
            catch (JMSException e)
            {
                log.error("Unexpected JMSException while calling Connection.close()", e);
            }
        }
    }

}
