create table if not exists PROCESS_TYPE
(
    ID            bigint not null auto_increment,
    NAME          varchar(256) not null,
    PROCESSOR_ID  bigint not null,

    primary key (ID),
    constraint PROCESS_TYPE_PROCESSOR_ID_FK foreign key (PROCESSOR_ID) references PROCESSOR (ID),
    constraint PROCESS_TYPE_NAME_PROCESSOR_ID_UK unique (NAME, PROCESSOR_ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;
