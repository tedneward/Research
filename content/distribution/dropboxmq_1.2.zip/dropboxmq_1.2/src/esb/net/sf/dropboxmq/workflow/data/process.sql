create table if not exists PROCESS
(
    ID               bigint not null auto_increment,
    PROCESS_KEY      varchar(256) not null,
    PROCESS_TYPE_ID  bigint not null,

    primary key (ID),
    constraint PROCESS_PROCESS_TYPE_ID_FK foreign key (PROCESS_TYPE_ID) references PROCESS_TYPE (ID),
    constraint PROCESS_PROCESS_KEY_PROCESS_TYPE_ID_UK unique (PROCESS_KEY, PROCESS_TYPE_ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;
