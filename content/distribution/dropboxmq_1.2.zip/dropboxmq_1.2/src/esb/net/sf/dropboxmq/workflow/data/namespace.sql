create table if not exists NAMESPACE
(
    ID            bigint not null auto_increment,
    PREFIX        varchar(256) not null,
    URI           varchar(4000) not null,
    PROCESSOR_ID  bigint not null,

    primary key (ID),
    constraint NAMESPACE_PROCESSOR_ID_FK foreign key (PROCESSOR_ID) references PROCESSOR (ID),
    constraint NAMESPACE_PREFIX_PROCESSOR_ID_UK unique (PREFIX, PROCESSOR_ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;
