create table if not exists EVENT_TYPE_STARTING
(
    ID    bigint not null auto_increment,
    NAME  varchar(256) unique not null,

    primary key (ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;

insert into EVENT_TYPE_STARTING (NAME) value ('CanStartNewRun');
insert into EVENT_TYPE_STARTING (NAME) value ('MustStartNewRun');
insert into EVENT_TYPE_STARTING (NAME) value ('WillNotStartNewRun');
