create table if not exists EVENT
(
    ID                  bigint not null auto_increment,
    EVENT_PROTOCOL_ID   bigint,
    CONTENT             text,
    STORED_ON           timestamp not null default current_timestamp,
    PROCESSED_ON        timestamp null default null,
    IS_DEFERRED         boolean not null,
    RUN_ID              bigint not null,
    EVENT_TYPE_ID       bigint not null,
    TRANSITION_NAME_ID  bigint,
    FROM_STATE_ID       bigint,
    TO_STATE_ID         bigint,

    primary key (ID),
    constraint EVENT_PROTOCOL_ID_FK foreign key (EVENT_PROTOCOL_ID) references EVENT_PROTOCOL (ID),
    constraint EVENT_RUN_ID_FK foreign key (RUN_ID) references RUN (ID),
    constraint EVENT_EVENT_TYPE_ID_FK foreign key (EVENT_TYPE_ID) references EVENT_TYPE (ID),
    constraint EVENT_TRANSITION_NAME_ID_FK foreign key (TRANSITION_NAME_ID) references TRANSITION_NAME (ID),
    constraint EVENT_FROM_STATE_ID_FK foreign key (FROM_STATE_ID) references STATE (ID),
    constraint EVENT_TO_STATE_ID_FK foreign key (TO_STATE_ID) references STATE (ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;
