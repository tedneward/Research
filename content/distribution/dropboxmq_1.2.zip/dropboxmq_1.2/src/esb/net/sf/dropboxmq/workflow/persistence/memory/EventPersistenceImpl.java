/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.memory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import net.sf.dropboxmq.workflow.data.Event;
import net.sf.dropboxmq.workflow.data.EventType;
import net.sf.dropboxmq.workflow.data.State;
import net.sf.dropboxmq.workflow.persistence.EventPersistence;

/**
 * Created: 11 Oct 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class EventPersistenceImpl implements EventPersistence
{
    private final RunPersistenceImpl runPersistence;
    private final EventTypePersistenceImpl eventTypePersistence;
    private final StatePersistenceImpl statePersistence;
    private final DeferredEventTypePersistenceImpl deferredEventTypePersistence;
    private final Map<Integer, Event> eventsById = new HashMap<Integer, Event>();
    private final Map<Integer, Set<Event>> deferredEventsByRun = new HashMap<Integer, Set<Event>>();
    private final Map<Integer, Set<Event>> eventsByRun = new HashMap<Integer, Set<Event>>();
    private int nextEventId = 1000;

    public EventPersistenceImpl(final RunPersistenceImpl runPersistence,
            final EventTypePersistenceImpl eventTypePersistence, final StatePersistenceImpl statePersistence,
            final DeferredEventTypePersistenceImpl deferredEventTypePersistence)
    {
        this.runPersistence = runPersistence;
        this.eventTypePersistence = eventTypePersistence;
        this.statePersistence = statePersistence;
        this.deferredEventTypePersistence = deferredEventTypePersistence;
    }

    @Override
    public void storeEvent(final Event event)
    {
        final Event newEvent = event.clone();

        // Primary key
        if (eventsById.containsKey(nextEventId))
        {
            throw new RuntimeException("Event id already exists, id = " + nextEventId);
        }
        newEvent.setId(nextEventId);
        nextEventId++;
        eventsById.put(newEvent.getId(), newEvent);

        // Additional updates
        final Date currentDate = new Date();
        newEvent.setStoredOn(currentDate);
        if (!newEvent.isDeferred())
        {
            newEvent.setProcessedOn(currentDate);
        }

        // Verify all foreign keys exist
        runPersistence.getExistingRunById(newEvent.getRunId());
        updateStateNames(newEvent);
        final EventType eventType = eventTypePersistence.getExistingEventTypeById(newEvent.getEventTypeId());
        newEvent.setEventTypeName(eventType.getName());

        // Update indexes
        if (newEvent.isDeferred())
        {
            getEvents(newEvent.getRunId(), deferredEventsByRun).add(newEvent);
        }
        else
        {
            getEvents(newEvent.getRunId(), eventsByRun).add(newEvent);
        }

        // Return the primary key
        event.setId(newEvent.getId());
        event.setStoredOn(newEvent.getStoredOn());
        event.setProcessedOn(newEvent.getProcessedOn());
    }

    private void updateStateNames(final Event event)
    {
        if (event.getFromStateId() != null)
        {
            final State fromState = statePersistence.getExistingStateById(event.getFromStateId());
            event.setFromStateName(fromState.getName());
        }
        if (event.getToStateId() != null)
        {
            final State toState = statePersistence.getExistingStateById(event.getToStateId());
            event.setToStateName(toState.getName());
        }
    }

    private static Set<Event> getEvents(final int runId, final Map<Integer, Set<Event>> eventsByRun)
    {
        Set<Event> events = eventsByRun.get(runId);
        if (events == null)
        {
            events = new TreeSet<Event>(new Comparator<Event>()
            {
                @Override
                public int compare(final Event o1, final Event o2)
                {
                    return o1.getProcessedOn().compareTo(o2.getProcessedOn());
                }
            });
            eventsByRun.put(runId, events);
        }

        return events;
    }

    @Override
    public List<Event> getNonDeferredEventsByRun(final int runId)
    {
        final Set<Event> events = getEvents(runId, eventsByRun);
        final List<Event> eventList = new ArrayList<Event>();
        for (final Event event : events)
        {
            eventList.add(event.clone());
        }
        return eventList;
    }

    @Override
    public Event getNextUndeferredEvent(final int runId, final int currentStateId)
    {
        final Set<Integer> deferredEventTypeIds
                = deferredEventTypePersistence.getExistingDeferredEventTypesByStateId(currentStateId);
        final Set<Event> deferredEvents = getEvents(runId, deferredEventsByRun);
        Event nextUndeferredEvent = null;
        for (final Event deferredEvent : deferredEvents)
        {
            if (!deferredEventTypeIds.contains(deferredEvent.getEventTypeId()))
            {
                nextUndeferredEvent = deferredEvent;
                break;
            }
        }
        return nextUndeferredEvent == null ? null : nextUndeferredEvent.clone();
    }

    @Override
    public void undeferEvent(final Event event)
    {
        final Event existingEvent = getExistingEventById(event.getId());
        final Set<Event> deferredEvents = getEvents(existingEvent.getRunId(), deferredEventsByRun);
        final Set<Event> events = getEvents(existingEvent.getRunId(), eventsByRun);
        if (!deferredEvents.remove(existingEvent) || !events.add(existingEvent))
        {
            throw new RuntimeException("Event was not deferred");
        }

        existingEvent.setProcessedOn(new Date());
        existingEvent.setTransitionName(event.getTransitionName());
        existingEvent.setFromStateId(event.getFromStateId());
        existingEvent.setToStateId(event.getToStateId());
        updateStateNames(existingEvent);

        event.setProcessedOn(existingEvent.getProcessedOn());
    }

    /*package*/ Event getExistingEventById(final int id)
    {
        final Event existingEvent = eventsById.get(id);
        if (existingEvent == null)
        {
            throw new RuntimeException("Could not find event, id = " + id);
        }
        return existingEvent;
    }

}
