create table if not exists STATE
(
    ID               bigint not null auto_increment,
    NAME             varchar(256) not null,
    PROCESS_TYPE_ID  bigint not null,

    primary key (ID),
    constraint STATE_PROCESS_TYPE_ID_FK foreign key (PROCESS_TYPE_ID) references PROCESS_TYPE (ID),
    constraint STATE_NAME_PROCESS_TYPE_ID_UK unique (NAME, PROCESS_TYPE_ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;
