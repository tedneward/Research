create table if not exists EVENT_TYPE
(
    ID                                          bigint not null auto_increment,
    NAME                                        varchar(256) not null,
    IS_ENABLED                                  boolean not null,
    TEST_X_PATH                                 varchar(4000) not null,
    KEY_X_PATH                                  varchar(4000) not null,
    CONTEXT_X_PATH                              varchar(4000),
    EVENT_TYPE_STARTING_ID                      bigint not null,
    IS_BROADCAST                                boolean not null,
    WILL_KEEP_ONLY_LAST_BROADCAST               boolean not null,
    WILL_IGNORE_LATE_MESSAGE_TO_TERMINATED_RUN  boolean not null,
    ERROR_TRANSFORMER_FILE_PATH                 varchar(4000),
    PARENT_KEY_X_PATH                           varchar(4000),
    PARENT_PROCESS_TYPE_ID                      bigint,
    PROCESS_TYPE_ID                             bigint not null,

    primary key (ID),
    constraint EVENT_TYPE_EVENT_TYPE_STARTING_FK
        foreign key (EVENT_TYPE_STARTING_ID) references EVENT_TYPE_STARTING (ID),
    constraint EVENT_TYPE_PARENT_PROCESS_TYPE_ID_FK foreign key (PARENT_PROCESS_TYPE_ID) references PROCESS_TYPE (ID),
    constraint EVENT_TYPE_PROCESS_TYPE_ID_FK foreign key (PROCESS_TYPE_ID) references PROCESS_TYPE (ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;
