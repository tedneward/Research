/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.memory;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.sf.dropboxmq.workflow.data.ProcessType;
import net.sf.dropboxmq.workflow.data.Processor;
import net.sf.dropboxmq.workflow.persistence.ProcessTypePersistence;

/**
 * Created: 19 Aug 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class ProcessTypePersistenceImpl implements ProcessTypePersistence
{
    private final ProcessorPersistenceImpl processorPersistence;
    private final Map<Integer, ProcessType> processTypesById = new HashMap<Integer, ProcessType>();
    private final Map<String, Map<String, ProcessType>> processTypesByNameByProcessor
            = new HashMap<String, Map<String, ProcessType>>();
    private int nextProcessTypeId = 1000;

    public ProcessTypePersistenceImpl(final ProcessorPersistenceImpl processorPersistence)
    {
        this.processorPersistence = processorPersistence;
    }

    @Override
    public void storeProcessType(final ProcessType processType)
    {
        final ProcessType newProcessType = processType.clone();

        // Primary key
        if (processTypesById.containsKey(nextProcessTypeId))
        {
            throw new RuntimeException("Process type id exists already, id = " + nextProcessTypeId);
        }
        newProcessType.setId(nextProcessTypeId);
        nextProcessTypeId++;
        processTypesById.put(newProcessType.getId(), newProcessType);

        // Verify all foreign keys exist
        final Processor processor = processorPersistence.getExistingProcessorById(newProcessType.getProcessorId());

        // Update indexes
        final Map<String, ProcessType> processTypesByName = getProcessTypesByProcessorName(processor.getName());
        final ProcessType existingProcessType = processTypesByName.get(newProcessType.getName());
        if (existingProcessType != null)
        {
            throw new RuntimeException("Process type already exists in processor, processor = " + processor.getName()
                    + ", process type = " + newProcessType.getName());
        }
        processTypesByName.put(newProcessType.getName(), newProcessType);

        // Return the primary key
        processType.setId(newProcessType.getId());
    }

    private Map<String, ProcessType> getProcessTypesByProcessorName(final String processorName)
    {
        Map<String, ProcessType> processTypesByName = processTypesByNameByProcessor.get(processorName);
        if (processTypesByName == null)
        {
            processTypesByName = new HashMap<String, ProcessType>();
            processTypesByNameByProcessor.put(processorName, processTypesByName);
        }
        return processTypesByName;
    }

    @Override
    public ProcessType getProcessTypeByName(final String name, final String processorName)
    {
        final Map<String, ProcessType> processTypesByName = getProcessTypesByProcessorName(processorName);
        final ProcessType processType = processTypesByName.get(name);
        return processType == null ? null : processType.clone();
    }

    /*package*/ ProcessType getExistingProcessTypeById(final int id)
    {
        final ProcessType existingProcessType = processTypesById.get(id);
        if (existingProcessType == null)
        {
            throw new RuntimeException("Could not find process type, id = " + id);
        }
        return existingProcessType;
    }

    /*package*/ Collection<ProcessType> getExistingProcessTypesByProcessor(final String processorName)
    {
        final Map<String, ProcessType> processTypesByName = processTypesByNameByProcessor.get(processorName);
        return processTypesByName == null ? Collections.<ProcessType>emptySet() : processTypesByName.values();
    }

}
