/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.xml;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import javax.xml.transform.ErrorListener;
import javax.xml.transform.Source;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created: 13 Feb 2011
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class WorkflowTransformerFactoryImpl implements WorkflowTransformerFactory
{
    private static final Log log = LogFactory.getLog(WorkflowTransformerFactoryImpl.class);

    private final Map<String, Templates> templatesMap = new HashMap<String, Templates>();
    private final Object templatesLock = new Object();

    @Override
    public Transformer getTransformer(final String transformerFilePath)
    {
        Transformer transformer;
        synchronized (templatesLock)
        {
            transformer = getCachedTransformer(transformerFilePath);
        }

        if (transformer == null)
        {
            final Templates templates = parseStylesheet(transformerFilePath);
            synchronized (templatesLock)
            {
                templatesMap.put(transformerFilePath, templates);
                transformer = getCachedTransformer(transformerFilePath);
            }
        }

        transformer.setErrorListener(new ErrorListener()
        {
            @Override
            public void warning(final TransformerException exception)
            {
                log.warn(exception.getMessageAndLocation());
            }

            @Override
            public void error(final TransformerException exception) throws TransformerException
            {
                log.error(exception.getMessageAndLocation());
                throw exception;
            }

            @Override
            public void fatalError(final TransformerException exception) throws TransformerException
            {
                log.fatal(exception.getMessageAndLocation());
                throw exception;
            }
        });

        return transformer;
    }

    private Transformer getCachedTransformer(final String transformerFilePath)
    {
        final Templates templates = templatesMap.get(transformerFilePath);
        try
        {
            return templates == null ? null :templates.newTransformer();
        }
        catch (TransformerConfigurationException e)
        {
            throw new RuntimeException(e);
        }
    }

    private static Templates parseStylesheet(final String transformerFilePath)
    {
        log.info("Parsing stylesheet " + transformerFilePath);

        final TransformerFactory factory = TransformerFactory.newInstance();

        final InputStream stream
                = Thread.currentThread().getContextClassLoader().getResourceAsStream(transformerFilePath);
        final Source source = new StreamSource(stream);
        source.setSystemId("classpath://" + transformerFilePath);
        try
        {
            return factory.newTemplates(source);
        }
        catch (TransformerConfigurationException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            try
            {
                stream.close();
            }
            catch (IOException e)
            {
                log.warn("IOException while closing a the InputStream, " + e.getMessage());
            }
        }
    }

}
