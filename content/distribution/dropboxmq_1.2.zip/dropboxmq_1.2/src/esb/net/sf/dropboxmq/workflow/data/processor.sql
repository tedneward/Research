create table if not exists PROCESSOR
(
    ID    bigint not null auto_increment,
    NAME  varchar(256) unique not null,

    primary key (ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;
