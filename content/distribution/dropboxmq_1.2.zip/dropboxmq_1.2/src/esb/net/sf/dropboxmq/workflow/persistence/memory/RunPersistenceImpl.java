/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.memory;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.dropboxmq.workflow.data.Process;
import net.sf.dropboxmq.workflow.data.ProcessType;
import net.sf.dropboxmq.workflow.data.Run;
import net.sf.dropboxmq.workflow.persistence.RunPersistence;

/**
 * Created: 03 Oct 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class RunPersistenceImpl implements RunPersistence
{
    private final StatePersistenceImpl statePersistence;
    private final ProcessPersistenceImpl processPersistence;
    private final ProcessTypePersistenceImpl processTypePersistence;
    private final Map<Integer, Run> runsById = new HashMap<Integer, Run>();
    private final Map<Integer, Map<String, Run>> lastUpdatedRunByKeyByProcessTypeId
            = new HashMap<Integer, Map<String, Run>>();
    private int nextRunId = 1000;

    public RunPersistenceImpl(final StatePersistenceImpl statePersistence,
            final ProcessPersistenceImpl processPersistence, final ProcessTypePersistenceImpl processTypePersistence)
    {
        this.statePersistence = statePersistence;
        this.processPersistence = processPersistence;
        this.processTypePersistence = processTypePersistence;
    }

    @Override
    public void storeRun(final Run run)
    {
        final Run newRun = run.clone();

        // Primary key
        if (runsById.containsKey(nextRunId))
        {
            throw new RuntimeException("Run id already exists, id = " + nextRunId);
        }
        newRun.setId(nextRunId);
        nextRunId++;
        runsById.put(newRun.getId(), newRun);

        // Verify all foreign keys exist
        String currentStateName = null;
        if (newRun.getCurrentStateId() != null)
        {
            currentStateName = statePersistence.getExistingStateById(newRun.getCurrentStateId()).getName();
        }
        String parentProcessTypeName = null;
        String parentProcessKey = null;
        String parentContext = null;
        if (newRun.getParentRunId() != null)
        {
            final Run parentRun = getExistingRunById(newRun.getParentRunId());
            parentContext = parentRun.getContext();
            final Process parentProcess = processPersistence.getExistingProcessById(parentRun.getProcessId());
            parentProcessKey = parentProcess.getProcessKey();
            parentProcessTypeName = processTypePersistence.getExistingProcessTypeById(
                    parentProcess.getProcessTypeId()).getName();
        }
        final Process process = processPersistence.getExistingProcessById(newRun.getProcessId());
        final ProcessType processType = processTypePersistence.getExistingProcessTypeById(process.getProcessTypeId());

        // Additional updates
        final Date currentDate = new Date();
        newRun.setStartedOn(currentDate);
        newRun.setLastUpdate(currentDate);
        newRun.setProcessTypeId(process.getProcessTypeId());
        newRun.setProcessTypeName(processType.getName());
        newRun.setProcessKey(process.getProcessKey());
        newRun.setCurrentStateName(currentStateName);
        newRun.setParentProcessTypeName(parentProcessTypeName);
        newRun.setParentProcessKey(parentProcessKey);
        newRun.setParentContext(parentContext);

        // Update indexes
        final Map<String, Run> lastUpdatedRunByKey = getLastUpdatedRunsByProcessTypeId(process.getProcessTypeId());
        final Run currentLastUpdatedRun = lastUpdatedRunByKey.get(process.getProcessKey());
        if (currentLastUpdatedRun != null && currentLastUpdatedRun.getCurrentStateId() != null)
        {
            throw new RuntimeException("Attempting to store run while existing run is still active");
        }
        lastUpdatedRunByKey.put(process.getProcessKey(), newRun);

        // Return the primary key
        run.setId(newRun.getId());
    }

    private Map<String, Run> getLastUpdatedRunsByProcessTypeId(final int processTypeId)
    {
        Map<String, Run> lastUpdatedRunByKey = lastUpdatedRunByKeyByProcessTypeId.get(processTypeId);
        if (lastUpdatedRunByKey == null)
        {
            lastUpdatedRunByKey = new HashMap<String, Run>();
            lastUpdatedRunByKeyByProcessTypeId.put(processTypeId, lastUpdatedRunByKey);
        }
        return lastUpdatedRunByKey;
    }

    @Override
    public List<Run> getActiveRunsByProcessType(final int processTypeId)
    {
        final Map<String, Run> lastUpdatedRunByKey = getLastUpdatedRunsByProcessTypeId(processTypeId);
        final List<Run> runs = new ArrayList<Run>();
        for (final Run run : lastUpdatedRunByKey.values())
        {
            if (run.getCurrentStateId() != null)
            {
                runs.add(run.clone());
            }
        }
        return runs;
    }

    @Override
    public Run getLastUpdatedRunByKeyAndProcessType(final String key, final int processTypeId)
    {
        final Map<String, Run> lastUpdatedRunByKey = getLastUpdatedRunsByProcessTypeId(processTypeId);
        final Run run = lastUpdatedRunByKey.get(key);
        return run == null ? null : run.clone();
    }

    @Override
    public void updateState(final int runId, final Integer toStateId)
    {
        final Run run = getExistingRunById(runId);
        run.setCurrentStateId(toStateId);
        run.setLastUpdate(new Date());
    }

    /*package*/ Run getExistingRunById(final int id)
    {
        final Run existingRun = runsById.get(id);
        if (existingRun == null)
        {
            throw new RuntimeException("Could not find run, id = " + id);
        }
        return existingRun;
    }

}
