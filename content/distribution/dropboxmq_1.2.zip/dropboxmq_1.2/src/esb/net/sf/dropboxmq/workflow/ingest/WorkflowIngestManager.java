/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.ingest;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.xml.parsers.ParserConfigurationException;
import net.sf.dropboxmq.workflow.persistence.jdbc.PersistenceFactoryImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.SAXException;

/**
 * Created: 30 Jan 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class WorkflowIngestManager
{
    private static final Log log = LogFactory.getLog(WorkflowIngestManager.class);

    public static final String CONNECTION_OPTION = "--connection";
    public static final String WORKFLOW_PATH_OPTION = "--workflow-path";
    public static final String DRIVER_OPTION = "--driver";
    public static final String USER_OPTION = "--user";
    public static final String PASS_OPTION = "--password";

    public static final String SHORT_CONNECTION_OPTION = "-c";
    public static final String SHORT_WORKFLOW_PATH_OPTION = "-w";
    public static final String SHORT_DRIVER_OPTION = "-d";
    public static final String SHORT_USER_OPTION = "-u";
    public static final String SHORT_PASS_OPTION = "-p";

    private final List<IngestedProcessor> processors = new ArrayList<IngestedProcessor>();
    private Connection connection = null;

    public static void main(final String[] args)
    {
        String workflowPath = ".";
        String user = "";
        String password = "";
        String connectionURI = null;
        String driver = "com.mysql.jdbc.Driver";

        String nextToken = null;
        for (final String arg : args)
        {
            if (nextToken != null)
            {
                if (nextToken.equals(CONNECTION_OPTION))
                {
                    connectionURI = arg;
                }
                else if (nextToken.equals(WORKFLOW_PATH_OPTION))
                {
                    workflowPath = arg;
                }
                else if (nextToken.equals(DRIVER_OPTION))
                {
                    driver = arg;
                }
                else if (nextToken.equals(USER_OPTION))
                {
                    user = arg;
                }
                else if (nextToken.equals(PASS_OPTION))
                {
                    password = arg;
                }
                else
                {
                    throw new RuntimeException("Option-value mismatch for " + nextToken);
                }
                nextToken = null;
            }
            else if (arg.equals(CONNECTION_OPTION) || arg.equals(SHORT_CONNECTION_OPTION))
            {
                nextToken = CONNECTION_OPTION;
            }
            else if (arg.equals(WORKFLOW_PATH_OPTION) || arg.equals(SHORT_WORKFLOW_PATH_OPTION))
            {
                nextToken = WORKFLOW_PATH_OPTION;
            }
            else if (arg.equals(DRIVER_OPTION) || arg.equals(SHORT_DRIVER_OPTION))
            {
                nextToken = DRIVER_OPTION;
            }
            else if (arg.equals(USER_OPTION) || arg.equals(SHORT_USER_OPTION))
            {
                nextToken = USER_OPTION;
            }
            else if (arg.equals(PASS_OPTION) || arg.equals(SHORT_PASS_OPTION))
            {
                nextToken = PASS_OPTION;
            }
            else
            {
                throw new RuntimeException("Unknown option " + arg);
            }
        }

        final WorkflowIngestManager manager = new WorkflowIngestManager();

        final String[] workflowDirs = workflowPath.split(File.pathSeparator);
        for (final String workflowDir : workflowDirs)
        {
            log.info("Scanning " + workflowDir);
            manager.ingest(new File(workflowDir));
        }

        try
        {
            manager.connect(user, password, driver, connectionURI);

            manager.archive(workflowDirs);

            log.info("Committing.");
            manager.commit();
        }
        catch (Throwable t)
        {
            log.error("Unexpected error", t);
            manager.rollback();
        }
        finally
        {
            manager.close();
        }
    }

    public void ingest(final File directory)
    {
        for (final File childFile : directory.listFiles())
        {
            if (childFile.isDirectory())
            {
                ingest(childFile);
            }
            else
            {
                if (childFile.isFile() && childFile.getName().endsWith(".dwf"))
                {
                    log.info("  Parsing " + childFile);
                    try
                    {
                        processors.add(new WorkflowIngester().ingestWorkflowFile(childFile));
                    }
                    catch (IOException e)
                    {
                        throw new RuntimeException(e);
                    }
                    catch (SAXException e)
                    {
                        throw new RuntimeException(e);
                    }
                    catch (ParserConfigurationException e)
                    {
                        throw new RuntimeException(e);
                    }
                }
            }
        }
    }

    void connect(final String user, final String password, final String driverClassString, final String connectionURI)
    {
        try
        {
            log.info("Connecting to " + connectionURI);
            final Class<? extends Driver> driverClass = Class.forName(driverClassString).asSubclass(Driver.class);
            final Driver driver = driverClass.getConstructor().newInstance();
            final Properties properties = new Properties();
            properties.setProperty("user", user);
            properties.setProperty("password", password);
            connection = driver.connect(connectionURI, properties);
            connection.setAutoCommit(false);
            log.info("Connected to " + connectionURI);
        }
        catch (ClassNotFoundException e)
        {
            throw new RuntimeException(e);
        }
        catch (InstantiationException e)
        {
            throw new RuntimeException(e);
        }
        catch (IllegalAccessException e)
        {
            throw new RuntimeException(e);
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        catch (NoSuchMethodException e)
        {
            throw new RuntimeException(e);
        }
        catch (InvocationTargetException e)
        {
            throw new RuntimeException(e);
        }

        if (connection == null)
        {
            throw new RuntimeException("Connection failed, no connection returned from Driver.connect()");
        }
    }

    public void commit()
    {
        try
        {
            connection.commit();
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
    }

    public void rollback()
    {
        if (connection != null)
        {
            try
            {
                connection.rollback();
            }
            catch (SQLException e)
            {
                log.error("SQLException while calling Connection.rollback(), " + e.getMessage());
            }
        }
    }

    public void close()
    {
        if (connection != null)
        {
            try
            {
                connection.close();
            }
            catch (SQLException e)
            {
                log.warn("SQLException while calling Connection.close(), " + e.getMessage());
            }
        }
    }

    void archive(final String[] workflowDirs)
    {
        new WorkflowArchiver(true).archiveWorkflow(processors, workflowDirs, new PersistenceFactoryImpl(connection));
    }

    public Connection getConnection()
    {
        return connection;
    }

    public void setConnection(final Connection connection)
    {
        this.connection = connection;
    }

}
