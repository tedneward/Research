/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.adapters.jms;

import java.io.IOException;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.ejb.MessageDrivenContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.sql.DataSource;
import javax.xml.parsers.ParserConfigurationException;
import net.sf.dropboxmq.workflow.WorkflowProcessor;
import net.sf.dropboxmq.workflow.adapters.CollectionAdapter;
import net.sf.dropboxmq.workflow.data.EventPackage;
import net.sf.dropboxmq.workflow.persistence.jdbc.PersistenceFactoryImpl;
import net.sf.dropboxmq.workflow.xml.WorkflowTransformerFactoryImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.ejb3.annotation.ResourceAdapter;
import org.xml.sax.SAXException;

/**
 * Created: 14 Nov 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
@MessageDriven(name = "dropboxmq/WorkflowMDB", messageListenerInterface = MessageListener.class,
        activationConfig =
        {
            @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
            @ActivationConfigProperty(propertyName = "destination", propertyValue = "dropboxmq/queue/workflow")/*,
            @ActivationConfigProperty( propertyName = "maxPoolSize", propertyValue = "10" )*/
        })
/* NB:  Embedded rar support currently disabled
@ResourceAdapter( "dropboxmq_esb.ear#dropboxmq.rar" )
*/
@ResourceAdapter("dropboxmq.rar")
public class WorkflowMDB implements MessageListener
{
    private static final Log log = LogFactory.getLog(WorkflowMDB.class);

    private final PersistenceFactoryImpl persistenceFactory = new PersistenceFactoryImpl();
    private final WorkflowProcessor processor = new WorkflowProcessor(
            "main", persistenceFactory, new WorkflowTransformerFactoryImpl());
    private MessageDrivenContext messageDrivenContext = null;

    @Override
    public void onMessage(final Message message)
    {
        log.info("=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v=v= START");
        assert messageDrivenContext != null;
        final CollectionAdapter adapter = newCollectionAdapter();

        boolean completed = false;
        try
        {
            log.info("onMessage(), " + message.getJMSMessageID());

            final EventPackage eventPackage = JMSAdapter.convertMessage(message);

            processor.onEvent(JMSAdapter.JMS, eventPackage.getContent(), eventPackage.getEventProperties(), adapter);
            completed = true;
        }
        catch (JMSException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            adapter.close();

            if (!completed)
            {
                messageDrivenContext.setRollbackOnly();
            }
            log.info("=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=^=   END");
        }
    }

    private CollectionAdapter newCollectionAdapter()
    {
        final CollectionAdapter collectionAdapter = new CollectionAdapter();

        final JMSAdapter jmsAdapter = new JMSAdapter("java:/dropboxmq/XAConnectionFactory", messageDrivenContext);
        collectionAdapter.addAdapter(JMSAdapter.JMS, jmsAdapter);

        return collectionAdapter;
    }

    @PostConstruct
    public void postConstruct() throws IOException, SAXException, ParserConfigurationException
    {
        log.info("postConstruct()");
        persistenceFactory.setDataSource((DataSource)messageDrivenContext.lookup("java:/DropboxMQESBDS"));
        processor.initialize();
    }

    public MessageDrivenContext getMessageDrivenContext()
    {
        return messageDrivenContext;
    }

    @Resource
    public void setMessageDrivenContext(final MessageDrivenContext messageDrivenContext)
    {
        this.messageDrivenContext = messageDrivenContext;
    }
}
