/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.data;

import java.io.Serializable;

/**
 * Created: 28 Jul 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class EventType implements Serializable, Cloneable
{
    private static final long serialVersionUID = -1140750807744467717L;

    public enum EventTypeStarting
    {
        CanStartNewRun,
        MustStartNewRun,
        WillNotStartNewRun
    }

    private Integer id = null;
    private String name = null;
    private Boolean isEnabled = null;
    private String testXPath = null;
    private String keyXPath = null;
    private String contextXPath = null;
    private EventTypeStarting startingEnum = null;
    private Boolean isBroadcast = null;
    private Boolean willKeepOnlyLastBroadcast = null;
    private Boolean willIgnoreLateMessageToTerminatedRun = null;
    private String errorTransformerFilePath = null;
    private String parentKeyXPath = null;
    private Integer parentProcessTypeId = null;
    private Integer processTypeId = null;

    // Join data -- not used at archive time
    private String processTypeName = null;
    private String parentProcessTypeName = null;

    public Integer getId()
    {
        return id;
    }

    public void setId(final Integer id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(final String name)
    {
        this.name = name;
    }

    public Boolean isEnabled()
    {
        return isEnabled;
    }

    public void setEnabled(final Boolean isEnabled)
    {
        this.isEnabled = isEnabled;
    }

    public String getTestXPath()
    {
        return testXPath;
    }

    public void setTestXPath(final String testXPath)
    {
        this.testXPath = testXPath;
    }

    public String getKeyXPath()
    {
        return keyXPath;
    }

    public void setKeyXPath(final String keyXPath)
    {
        this.keyXPath = keyXPath;
    }

    public String getContextXPath()
    {
        return contextXPath;
    }

    public void setContextXPath(final String contextXPath)
    {
        this.contextXPath = contextXPath;
    }

    public EventTypeStarting getStartingEnum()
    {
        return startingEnum;
    }

    public void setStartingEnum(final EventTypeStarting startingEnum)
    {
        this.startingEnum = startingEnum;
    }

    public Boolean isBroadcast()
    {
        return isBroadcast;
    }

    public void setBroadcast(final Boolean isBroadcast)
    {
        this.isBroadcast = isBroadcast;
    }

    public Boolean willKeepOnlyLastBroadcast()
    {
        return willKeepOnlyLastBroadcast;
    }

    public void setWillKeepOnlyLastBroadcast(final Boolean willKeepOnlyLastBroadcast)
    {
        this.willKeepOnlyLastBroadcast = willKeepOnlyLastBroadcast;
    }

    public Boolean willIgnoreLateMessageToTerminatedRun()
    {
        return willIgnoreLateMessageToTerminatedRun;
    }

    public void setWillIgnoreLateMessageToTerminatedRun(final Boolean willIgnoreLateMessageToTerminatedRun)
    {
        this.willIgnoreLateMessageToTerminatedRun = willIgnoreLateMessageToTerminatedRun;
    }

    public String getErrorTransformerFilePath()
    {
        return errorTransformerFilePath;
    }

    public void setErrorTransformerFilePath(final String errorTransformerFilePath)
    {
        this.errorTransformerFilePath = errorTransformerFilePath;
    }

    public String getParentKeyXPath()
    {
        return parentKeyXPath;
    }

    public void setParentKeyXPath(final String parentKeyXPath)
    {
        this.parentKeyXPath = parentKeyXPath;
    }

    public Integer getParentProcessTypeId()
    {
        return parentProcessTypeId;
    }

    public void setParentProcessTypeId(final Integer parentProcessTypeId)
    {
        this.parentProcessTypeId = parentProcessTypeId;
    }

    public Integer getProcessTypeId()
    {
        return processTypeId;
    }

    public void setProcessTypeId(final Integer processTypeId)
    {
        this.processTypeId = processTypeId;
    }

    public String getProcessTypeName()
    {
        return processTypeName;
    }

    public void setProcessTypeName(final String processTypeName)
    {
        this.processTypeName = processTypeName;
    }

    public String getParentProcessTypeName()
    {
        return parentProcessTypeName;
    }

    public void setParentProcessTypeName(final String parentProcessTypeName)
    {
        this.parentProcessTypeName = parentProcessTypeName;
    }

    @Override
    public final EventType clone()
    {
        try
        {
            return (EventType)super.clone();
        }
        catch (CloneNotSupportedException e)
        {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean equals(final Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null || getClass() != obj.getClass())
        {
            return false;
        }

        final EventType that = (EventType)obj;

        if (contextXPath != null ? !contextXPath.equals(that.contextXPath) : that.contextXPath != null)
        {
            return false;
        }
        if (errorTransformerFilePath != null ? !errorTransformerFilePath.equals(that.errorTransformerFilePath)
                : that.errorTransformerFilePath != null)
        {
            return false;
        }
        if (id != null ? !id.equals(that.id) : that.id != null)
        {
            return false;
        }
        if (isBroadcast != null ? !isBroadcast.equals(that.isBroadcast) : that.isBroadcast != null)
        {
            return false;
        }
        if (isEnabled != null ? !isEnabled.equals(that.isEnabled) : that.isEnabled != null)
        {
            return false;
        }
        if (keyXPath != null ? !keyXPath.equals(that.keyXPath) : that.keyXPath != null)
        {
            return false;
        }
        if (name != null ? !name.equals(that.name) : that.name != null)
        {
            return false;
        }
        if (parentKeyXPath != null ? !parentKeyXPath.equals(that.parentKeyXPath)
                : that.parentKeyXPath != null)
        {
            return false;
        }
        if (parentProcessTypeId != null ? !parentProcessTypeId.equals(that.parentProcessTypeId)
                : that.parentProcessTypeId != null)
        {
            return false;
        }
        if (parentProcessTypeName != null ?
                !parentProcessTypeName.equals(that.parentProcessTypeName) : that.parentProcessTypeName != null)
        {
            return false;
        }
        if (processTypeId != null ? !processTypeId.equals(that.processTypeId) : that.processTypeId != null)
        {
            return false;
        }
        if (processTypeName != null ? !processTypeName.equals(that.processTypeName) : that.processTypeName != null)
        {
            return false;
        }
        if (startingEnum != that.startingEnum)
        {
            return false;
        }
        if (testXPath != null ? !testXPath.equals(that.testXPath) : that.testXPath != null)
        {
            return false;
        }
        if (willIgnoreLateMessageToTerminatedRun != null
                ? !willIgnoreLateMessageToTerminatedRun.equals(that.willIgnoreLateMessageToTerminatedRun)
                : that.willIgnoreLateMessageToTerminatedRun != null)
        {
            return false;
        }
        if (willKeepOnlyLastBroadcast != null ? !willKeepOnlyLastBroadcast.equals(that.willKeepOnlyLastBroadcast)
                : that.willKeepOnlyLastBroadcast != null)
        {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (isEnabled != null ? isEnabled.hashCode() : 0);
        result = 31 * result + (testXPath != null ? testXPath.hashCode() : 0);
        result = 31 * result + (keyXPath != null ? keyXPath.hashCode() : 0);
        result = 31 * result + (contextXPath != null ? contextXPath.hashCode() : 0);
        result = 31 * result + (startingEnum != null ? startingEnum.hashCode() : 0);
        result = 31 * result + (isBroadcast != null ? isBroadcast.hashCode() : 0);
        result = 31 * result + (willKeepOnlyLastBroadcast != null ? willKeepOnlyLastBroadcast.hashCode() : 0);
        result = 31 * result + (willIgnoreLateMessageToTerminatedRun != null
                ? willIgnoreLateMessageToTerminatedRun.hashCode() : 0);
        result = 31 * result + (errorTransformerFilePath != null ? errorTransformerFilePath.hashCode() : 0);
        result = 31 * result + (parentKeyXPath != null ? parentKeyXPath.hashCode() : 0);
        result = 31 * result + (parentProcessTypeId != null ? parentProcessTypeId.hashCode() : 0);
        result = 31 * result + (processTypeId != null ? processTypeId.hashCode() : 0);
        result = 31 * result + (processTypeName != null ? processTypeName.hashCode() : 0);
        result = 31 * result + (parentProcessTypeName != null ? parentProcessTypeName.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "EventType{"
                + "id=" + id
                + ", name='" + name + '\''
                + ", isEnabled=" + isEnabled
                + ", testXPath='" + testXPath + '\''
                + ", keyXPath='" + keyXPath + '\''
                + ", contextXPath='" + contextXPath + '\''
                + ", startingEnum=" + startingEnum
                + ", isBroadcast=" + isBroadcast
                + ", willKeepOnlyLastBroadcast=" + willKeepOnlyLastBroadcast
                + ", willIgnoreLateMessageToTerminatedRun=" + willIgnoreLateMessageToTerminatedRun
                + ", errorTransformerFilePath='" + errorTransformerFilePath + '\''
                + ", parentKeyXPath='" + parentKeyXPath + '\''
                + ", parentProcessTypeId=" +  parentProcessTypeId
                + ", processTypeId=" + processTypeId
                + ", processTypeName='" + processTypeName + '\''
                + ", parentProcessTypeName=\'" + parentProcessTypeName + '\''
                + '}';
    }

}
