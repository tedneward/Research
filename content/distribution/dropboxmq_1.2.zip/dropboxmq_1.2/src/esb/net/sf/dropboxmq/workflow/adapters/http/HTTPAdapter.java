/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.adapters.http;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import net.sf.dropboxmq.workflow.adapters.CollectionAdapter;
import net.sf.dropboxmq.workflow.adapters.EventAdapter;
import net.sf.dropboxmq.workflow.data.EventPackage;
import net.sf.dropboxmq.workflow.xml.PrettyPrinter;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Created: 20 Mar 2011
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class HTTPAdapter implements EventAdapter
{
    private static final String NEW_LINE = System.getProperty("line.separator");

    public static final String HTTP = "http";
    private static final String REQUEST = "request";
    private static final String REQUEST_PREFIX = REQUEST + "-";
    private static final int REQUEST_PREFIX_LENGTH = REQUEST_PREFIX.length();
    private static final String HEADER_PREFIX = CollectionAdapter.HEADER + "-";
    private static final int HEADER_PREFIX_LENGTH = HEADER_PREFIX.length();

    private EventPackage responseEvent = null;

    public static EventPackage convertRequest(final HttpServletRequest request) throws IOException
    {
        final EventPackage eventPackage = new EventPackage();
        eventPackage.setContent(getContent(request.getReader()));
        eventPackage.setEventProperties(getProperties(request));

        return eventPackage;
    }

    private static String getContent(final BufferedReader reader) throws IOException
    {
        final StringBuilder builder = new StringBuilder();
        boolean done = false;
        while (!done)
        {
            final String line = reader.readLine();
            if (line == null)
            {
                done = true;
            }
            else
            {
                builder.append(line).append(NEW_LINE);
            }
        }
        return builder.toString();
    }

    private static Map<String, String> getProperties(final HttpServletRequest request)
    {
        final Map<String, String> eventProperties = new HashMap<String, String>();

        setProperty(REQUEST_PREFIX + "auth-type", request.getAuthType(), eventProperties);
        setProperty(REQUEST_PREFIX + "content-length", request.getContentLength(), eventProperties);
        setProperty(REQUEST_PREFIX + "content-type", request.getContentType(), eventProperties);
        setProperty(REQUEST_PREFIX + "context-path", request.getContextPath(), eventProperties);
        setProperty(REQUEST_PREFIX + "local-addr", request.getLocalAddr(), eventProperties);
        setProperty(REQUEST_PREFIX + "locale", request.getLocale(), eventProperties);
        setProperty(REQUEST_PREFIX + "local-name", request.getLocalName(), eventProperties);
        setProperty(REQUEST_PREFIX + "local-port", request.getLocalPort(), eventProperties);
        setProperty(REQUEST_PREFIX + "method", request.getMethod(), eventProperties);
        setProperty(REQUEST_PREFIX + "path-info", request.getPathInfo(), eventProperties);
        setProperty(REQUEST_PREFIX + "path-translated", request.getPathTranslated(), eventProperties);
        setProperty(REQUEST_PREFIX + "protocol", request.getProtocol(), eventProperties);
        setProperty(REQUEST_PREFIX + "query-string", request.getQueryString(), eventProperties);
        setProperty(REQUEST_PREFIX + "remote-addr", request.getRemoteAddr(), eventProperties);
        setProperty(REQUEST_PREFIX + "remote-host", request.getRemoteHost(), eventProperties);
        setProperty(REQUEST_PREFIX + "remote-port", request.getRemotePort(), eventProperties);
        setProperty(REQUEST_PREFIX + "remote-user", request.getRemoteUser(), eventProperties);
        setProperty(REQUEST_PREFIX + "requested-session-id", request.getRequestedSessionId(), eventProperties);
        setProperty(REQUEST_PREFIX + "uri", request.getRequestURI(), eventProperties);
        setProperty(REQUEST_PREFIX + "scheme", request.getScheme(), eventProperties);
        setProperty(REQUEST_PREFIX + "server-name", request.getServerName(), eventProperties);
        setProperty(REQUEST_PREFIX + "server-port", request.getServerPort(), eventProperties);
        setProperty(REQUEST_PREFIX + "servlet-path", request.getServletPath(), eventProperties);

        // TODO: Cookies
        final Enumeration<?> headers = request.getHeaderNames();
        while (headers.hasMoreElements())
        {
            final String name = (String)headers.nextElement();
            final String value = request.getHeader(name);
            eventProperties.put(HEADER_PREFIX + name, value);
        }
        final Map<?, ?> parameterMap = request.getParameterMap();
        for (final Object parameterNameObject : parameterMap.keySet())
        {
            final String parameterName = (String)parameterNameObject;
            final String[] values = (String[])parameterMap.get(parameterName);
            for (int i = 0; i < values.length; i++)
            {
                eventProperties.put(parameterName + (values.length == 1 ? "" : "-" + i), values[i]);
            }
        }
        // TODO: Parts
        // TODO: Session

        return eventProperties;
    }

    private static void setProperty(final String name, final Object value, final Map<String, String> properties)
    {
        if (value != null)
        {
            final String stringValue = String.valueOf(value);
            if (stringValue.length() > 0)
            {
                properties.put(name, stringValue);
            }
        }
    }

    @Override
    public void renderProperties(
            final Map<String, String> properties, final String protocol, final Element eventElement)
    {
        final Element headerElement = eventElement.getOwnerDocument().createElement(CollectionAdapter.HEADER);
        eventElement.appendChild(headerElement);

        final Element requestElement = eventElement.getOwnerDocument().createElement(REQUEST);
        eventElement.appendChild(requestElement);

        for (final Map.Entry<String, String> propertyEntry : properties.entrySet())
        {
            final String name = propertyEntry.getKey();
            final String value = propertyEntry.getValue();

            if (name.startsWith(REQUEST_PREFIX))
            {
                final String shortName = name.substring(REQUEST_PREFIX_LENGTH);
                requestElement.setAttribute(shortName, value);
            }
            else if (name.startsWith(HEADER_PREFIX))
            {
                final String shortName = name.substring(HEADER_PREFIX_LENGTH);
                headerElement.setAttribute(shortName, value);
            }
            else
            {
                CollectionAdapter.renderSimpleProperty(name, value, "parameter", eventElement);
            }
        }
    }

    @Override
    public Collection<EventPackage> processResults(final Node results)
    {
        final StringBuilder builder = new StringBuilder();
        final NodeList contents = CollectionAdapter.findSingleChild(CollectionAdapter.CONTENT, results).getChildNodes();
        for (int i = 0; i < contents.getLength(); i++)
        {
            final Node content = contents.item(i);
            builder.append(PrettyPrinter.prettyPrint(content)).append(NEW_LINE);
        }
        responseEvent = new EventPackage();
        responseEvent.setProtocol(HTTP);
        responseEvent.setContent(builder.toString());

        return Collections.emptyList();
    }

    @Override
    public void close()
    {
    }

    public EventPackage getResponseEvent()
    {
        return responseEvent;
    }
}
