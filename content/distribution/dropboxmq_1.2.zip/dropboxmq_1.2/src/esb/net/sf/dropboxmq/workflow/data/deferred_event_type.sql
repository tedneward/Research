create table if not exists DEFERRED_EVENT_TYPE
(
    ID             bigint not null auto_increment,
    STATE_ID       bigint not null,
    EVENT_TYPE_ID  bigint not null,

    primary key (ID),
    constraint DEFERRED_EVENT_TYPE_STATE_ID_FK foreign key (STATE_ID) references STATE (ID),
    constraint DEFERRED_EVENT_TYPE_EVENT_TYPE_ID_FK foreign key (EVENT_TYPE_ID) references EVENT_TYPE (ID),
    constraint DEFERRED_EVENT_TYPE_STATE_ID_EVENT_TYPE_ID_UK unique (STATE_ID, EVENT_TYPE_ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;
