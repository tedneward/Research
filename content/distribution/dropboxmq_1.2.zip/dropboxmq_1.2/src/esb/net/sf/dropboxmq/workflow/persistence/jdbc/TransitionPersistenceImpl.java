/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.sf.dropboxmq.workflow.data.Transition;
import net.sf.dropboxmq.workflow.persistence.TransitionPersistence;

/**
 * Created: 04 Feb 2011
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class TransitionPersistenceImpl implements TransitionPersistence
{
    private static final String INSERT = "insert into TRANSITION (TRANSITION_NAME_ID, TEST_X_PATH, FROM_STATE_ID,"
            + " TO_STATE_ID, TRANSFORMER_FILE_PATH, PROCESS_TYPE_ID) values (?, ?, ?, ?, ?, ?)";
    private static final String SELECT = "select t.ID, t.TRANSITION_NAME_ID, t.TEST_X_PATH, t.FROM_STATE_ID,"
            + " t.TO_STATE_ID, t.TRANSFORMER_FILE_PATH, t.PROCESS_TYPE_ID, tn.NAME as TRANSITION_NAME,"
            + " s1.NAME as FROM_STATE_NAME, s2.NAME as TO_STATE_NAME"
            + " from TRANSITION t"
            + " left outer join TRANSITION_NAME tn on tn.ID = t.TRANSITION_NAME_ID"
            + " left outer join STATE s1 on s1.ID = t.FROM_STATE_ID"
            + " left outer join STATE s2 on s2.ID = t.TO_STATE_ID";
    private static final String SELECT_FROM_NULL_STATE = SELECT
            + " where t.FROM_STATE_ID is null and t.PROCESS_TYPE_ID = ?";
    private static final String SELECT_FROM_NOT_NULL_STATE = SELECT
            + " where t.FROM_STATE_ID = ? and t.PROCESS_TYPE_ID = ?";
    private static final String DELETE_TO_STATE = "delete from TRANSITION where TO_STATE_ID = ?";
    private static final String DELETE_FROM_STATE
            = "delete from TRANSITION where FROM_STATE_ID = ? and PROCESS_TYPE_ID = ?";
    private static final String DELETE_FROM_NULL_STATE
            = "delete from TRANSITION where FROM_STATE_ID is null and PROCESS_TYPE_ID = ?";
    private static final String INSERT_TRANSITION_NAME = "insert into TRANSITION_NAME (NAME) values (?)";
    private static final String SELECT_TRANSITION_NAME = "select ID from TRANSITION_NAME where NAME = ?";

    private final PersistenceFactoryImpl persistenceFactory;

    public TransitionPersistenceImpl(final PersistenceFactoryImpl persistenceFactory)
    {
        this.persistenceFactory = persistenceFactory;
    }

    @Override
    public void storeTransition(final Transition transition)
    {
        final JDBCHelper helper = newJDBCHelper();
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(INSERT);
            if (transition.getName() == null)
            {
                statement.setNull(1, Types.BIGINT);
            }
            else
            {
                statement.setInt(1, getTransitionNameId(transition.getName()));
            }
            statement.setString(2, transition.getTestXPath());
            if (transition.getFromStateId() == null)
            {
                statement.setNull(3, Types.BIGINT);
            }
            else
            {
                statement.setInt(3, transition.getFromStateId());
            }
            if (transition.getToStateId() == null)
            {
                statement.setNull(4, Types.BIGINT);
            }
            else
            {
                statement.setInt(4, transition.getToStateId());
            }
            statement.setString(5, transition.getTransformerFilePath());
            statement.setInt(6, transition.getProcessTypeId());
            if (statement.executeUpdate() != 1)
            {
                throw new RuntimeException("PreparedStatement.executeUpdate() for insert statement did not return 1");
            }
            transition.setId(helper.getLastInsertId(connection));
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            helper.safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    JDBCHelper newJDBCHelper()
    {
        return new JDBCHelper();
    }

    int getTransitionNameId(final String name)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(SELECT_TRANSITION_NAME);
            statement.setString(1, name);
            final ResultSet results = statement.executeQuery();
            final int id = results.next() ? results.getInt(1) : insertTransitionName(name, connection);

            if (results.next())
            {
                throw new RuntimeException("Select unique row returned multiple rows");
            }

            return id;
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    int insertTransitionName(final String name, final Connection connection)
    {
        final JDBCHelper helper = newJDBCHelper();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(INSERT_TRANSITION_NAME);
            statement.setString(1, name);
            if (statement.executeUpdate() != 1)
            {
                throw new RuntimeException("PreparedStatement.executeUpdate() for insert statement did not return 1");
            }
            return helper.getLastInsertId(connection);
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            helper.safeClose(statement);
        }
    }

    @Override
    public Collection<Transition> getTransitionsFromState(final Integer stateId, final int processTypeId)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            if (stateId == null)
            {
                statement = connection.prepareStatement(SELECT_FROM_NULL_STATE);
                statement.setInt(1, processTypeId);
            }
            else
            {
                statement = connection.prepareStatement(SELECT_FROM_NOT_NULL_STATE);
                statement.setInt(1, stateId);
                statement.setInt(2, processTypeId);
            }
            final ResultSet results = statement.executeQuery();
            final List<Transition> transitions = new ArrayList<Transition>();
            while (results.next())
            {
                final Transition transition = new Transition();
                transition.setId(results.getInt("ID"));
                transition.setName(results.getString("TRANSITION_NAME"));
                transition.setTestXPath(results.getString("TEST_X_PATH"));
                transition.setFromStateId(results.getInt("FROM_STATE_ID"));
                if (results.wasNull())
                {
                    transition.setFromStateId(null);
                }
                transition.setFromStateName(results.getString("FROM_STATE_NAME"));
                transition.setToStateId(results.getInt("TO_STATE_ID"));
                if (results.wasNull())
                {
                    transition.setToStateId(null);
                }
                transition.setToStateName(results.getString("TO_STATE_NAME"));
                transition.setTransformerFilePath(results.getString("TRANSFORMER_FILE_PATH"));
                transition.setProcessTypeId(results.getInt("PROCESS_TYPE_ID"));
                transitions.add(transition);
            }

            return transitions;
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    @Override
    public void deleteTransitionsToState(final int stateId)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(DELETE_TO_STATE);
            statement.setInt(1, stateId);
            statement.executeUpdate();
            statement.addBatch();
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    @Override
    public void deleteTransitionsFromState(final Integer stateId, final int processTypeId)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            if (stateId == null)
            {
                statement = connection.prepareStatement(DELETE_FROM_NULL_STATE);
                statement.setInt(1, processTypeId);
            }
            else
            {
                statement = connection.prepareStatement(DELETE_FROM_STATE);
                statement.setInt(1, stateId);
                statement.setInt(2, processTypeId);
            }
            statement.executeUpdate();
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

}
