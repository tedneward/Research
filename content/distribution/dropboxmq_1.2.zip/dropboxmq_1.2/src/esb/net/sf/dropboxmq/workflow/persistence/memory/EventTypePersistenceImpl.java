/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.memory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.dropboxmq.workflow.data.EventType;
import net.sf.dropboxmq.workflow.data.ProcessType;
import net.sf.dropboxmq.workflow.data.Processor;
import net.sf.dropboxmq.workflow.persistence.EventTypePersistence;

/**
 * Created: 22 Aug 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class EventTypePersistenceImpl implements EventTypePersistence
{
    private final ProcessorPersistenceImpl processorPersistence;
    private final ProcessTypePersistenceImpl processTypePersistence;
    private final Map<Integer, EventType> eventTypesById = new HashMap<Integer, EventType>();
    private final Map<Integer, Map<String, EventType>> eventTypesByNameByProcessTypeId
            = new HashMap<Integer, Map<String, EventType>>();
    private int nextEventTypeId = 1000;

    public EventTypePersistenceImpl(final ProcessorPersistenceImpl processorPersistence,
            final ProcessTypePersistenceImpl processTypePersistence)
    {
        this.processorPersistence = processorPersistence;
        this.processTypePersistence = processTypePersistence;
    }

    @Override
    public void storeEventType(final EventType eventType)
    {
        final EventType newEventType = eventType.clone();

        // Primary key
        if (eventTypesById.containsKey(nextEventTypeId))
        {
            throw new RuntimeException("Event type id already exists, id = " + nextEventTypeId);
        }
        newEventType.setId(nextEventTypeId);
        nextEventTypeId++;
        eventTypesById.put(newEventType.getId(), newEventType);

        // Verify all foreign keys exist
        checkProcessTypes(newEventType);
        processTypePersistence.getExistingProcessTypeById(newEventType.getProcessTypeId());

        // Update indexes
        final Map<String, EventType> eventTypesByName = getEventTypesByName(newEventType.getProcessTypeId());
        if (eventTypesByName.containsKey(newEventType.getName()))
        {
            throw new RuntimeException("Process type already contains event type of given name, use update,"
                    + " event type = " + newEventType.getName());
        }
        eventTypesByName.put(newEventType.getName(), newEventType);

        // Return the primary key
        eventType.setId(newEventType.getId());
    }

    private void checkProcessTypes(final EventType eventType)
    {
        final ProcessType processType
                = processTypePersistence.getExistingProcessTypeById(eventType.getProcessTypeId());
        eventType.setProcessTypeName(processType.getName());
        if (eventType.getParentProcessTypeId() != null)
        {
            final ProcessType parentProcessType
                    = processTypePersistence.getExistingProcessTypeById(eventType.getParentProcessTypeId());
            eventType.setParentProcessTypeName(parentProcessType.getName());
        }
    }

    private Map<String, EventType> getEventTypesByName(final Integer processTypeId)
    {
        Map<String, EventType> eventTypesByName = eventTypesByNameByProcessTypeId.get(processTypeId);
        if (eventTypesByName == null)
        {
            eventTypesByName = new HashMap<String, EventType>();
            eventTypesByNameByProcessTypeId.put(processTypeId, eventTypesByName);
        }

        return eventTypesByName;
    }

    @Override
    public void updateEventType(final int id, final EventType eventType)
    {
        final EventType newEventType = eventType.clone();
        newEventType.setId(id);

        // Will throw exception if event type does not exist
        getExistingEventTypeById(id);

        checkProcessTypes(newEventType);

        eventTypesById.put(id, newEventType);
        final Map<String, EventType> eventTypesByName = getEventTypesByName(newEventType.getProcessTypeId());
        eventTypesByName.put(newEventType.getName(), newEventType);

        eventType.setId(id);
    }

    @Override
    public void disableEventType(final int id)
    {
        getExistingEventTypeById(id).setEnabled(true);
    }

    @Override
    public Collection<EventType> getEventTypesByProcessTypeId(final int processTypeId)
    {
        final Map<String, EventType> eventTypes = getEventTypesByName(processTypeId);
        final List<EventType> eventTypeList = new ArrayList<EventType>();
        for (final EventType eventType : eventTypes.values())
        {
            eventTypeList.add(eventType.clone());
        }
        return eventTypeList;
    }

    @Override
    public Collection<EventType> getEnabledEventTypesByProcessor(final String processorName)
    {
        final List<EventType> enabledEventTypes = new ArrayList<EventType>();
        final Processor processor = processorPersistence.getProcessorByName(processorName);
        if (processor == null)
        {
            throw new RuntimeException("Could not find processor by name " + processorName);
        }

        for (final ProcessType processType
                : processTypePersistence.getExistingProcessTypesByProcessor(processor.getName()))
        {
            final Collection<EventType> existingEventTypes = getEventTypesByProcessTypeId(processType.getId());
            for (final EventType existingEventType : existingEventTypes)
            {
                if (existingEventType.isEnabled())
                {
                    enabledEventTypes.add(existingEventType.clone());
                }
            }
        }

        return enabledEventTypes;
    }

    /*package*/ EventType getExistingEventTypeById(final int id)
    {
        final EventType existingEventType = eventTypesById.get(id);
        if (existingEventType == null)
        {
            throw new RuntimeException("Could not find event type, id = " + id);
        }
        return existingEventType;
    }

}
