/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.memory;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import net.sf.dropboxmq.workflow.data.DeferredEventType;
import net.sf.dropboxmq.workflow.data.EventType;
import net.sf.dropboxmq.workflow.data.State;
import net.sf.dropboxmq.workflow.persistence.DeferredEventTypePersistence;

/**
 * Created: 31 Aug 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class DeferredEventTypePersistenceImpl implements DeferredEventTypePersistence
{
    private final StatePersistenceImpl statePersistence;
    private final EventTypePersistenceImpl eventTypePersistence;
    private final Map<Integer, Map<Integer, DeferredEventType>> deferredEventTypesByEventTypeIdByStateId
            = new HashMap<Integer, Map<Integer, DeferredEventType>>();
    private int nextDeferredEventTypeId = 1000;

    public DeferredEventTypePersistenceImpl(
            final StatePersistenceImpl statePersistence, final EventTypePersistenceImpl eventTypePersistence)
    {
        this.statePersistence = statePersistence;
        this.eventTypePersistence = eventTypePersistence;
    }

    @Override
    public void storeDeferredEventType(final DeferredEventType deferredEventType)
    {
        final DeferredEventType newDeferredEventType = deferredEventType.clone();

        // Primary key
        newDeferredEventType.setId(nextDeferredEventTypeId);
        nextDeferredEventTypeId++;

        // Verify all foreign keys exist
        final State state = statePersistence.getExistingStateById(newDeferredEventType.getStateId());
        final EventType eventType
                = eventTypePersistence.getExistingEventTypeById(newDeferredEventType.getEventTypeId());

        // Update indexes
        final Map<Integer, DeferredEventType> deferredEventTypesByEventTypeId
                = getDeferredEventTypesForState(state.getId());
        if (deferredEventTypesByEventTypeId.containsKey(newDeferredEventType.getEventTypeId()))
        {
            throw new RuntimeException("Deferred event type already exists for state, state = "
                    + state.getName() + ", event type = " + eventType.getName());
        }
        deferredEventTypesByEventTypeId.put(newDeferredEventType.getEventTypeId(), newDeferredEventType);

        // Return the primary key
        deferredEventType.setId(newDeferredEventType.getId());
    }

    private Map<Integer, DeferredEventType> getDeferredEventTypesForState(final int stateId)
    {
        Map<Integer, DeferredEventType> deferredEventTypesByEventTypeId
                = deferredEventTypesByEventTypeIdByStateId.get(stateId);
        if (deferredEventTypesByEventTypeId == null)
        {
            deferredEventTypesByEventTypeId = new HashMap<Integer, DeferredEventType>();
            deferredEventTypesByEventTypeIdByStateId.put(stateId, deferredEventTypesByEventTypeId);
        }
        return deferredEventTypesByEventTypeId;
    }

    @Override
    public boolean isEventTypeDeferred(final int stateId, final int eventTypeId)
    {
        return getDeferredEventTypesForState(stateId).containsKey(eventTypeId);
    }

    @Override
    public void deleteDeferredEventTypes(final int stateId)
    {
        // Will throw exception if either state does not exist
        statePersistence.getExistingStateById(stateId);
        deferredEventTypesByEventTypeIdByStateId.remove(stateId);
    }

    /*package*/ Set<Integer> getExistingDeferredEventTypesByStateId(final int stateId)
    {
        return getDeferredEventTypesForState(stateId).keySet();
    }

}
