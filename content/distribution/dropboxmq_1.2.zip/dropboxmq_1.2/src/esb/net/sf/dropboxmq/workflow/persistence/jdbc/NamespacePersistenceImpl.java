/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.sf.dropboxmq.workflow.data.Namespace;
import net.sf.dropboxmq.workflow.persistence.NamespacePersistence;

/**
 * Created: 05 02 2011
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class NamespacePersistenceImpl implements NamespacePersistence
{
    private static final String INSERT = "insert into NAMESPACE (PREFIX, URI, PROCESSOR_ID) values (?, ?, ?)";
    private static final String SELECT = "select n.ID, n.PREFIX, n.URI, n.PROCESSOR_ID from NAMESPACE n"
            + " join PROCESSOR p on p.ID = n.PROCESSOR_ID"
            + " where p.NAME = ?";
    private static final String DELETE = "delete from NAMESPACE where PROCESSOR_ID = ?";

    private final PersistenceFactoryImpl persistenceFactory;

    public NamespacePersistenceImpl(final PersistenceFactoryImpl persistenceFactory)
    {
        this.persistenceFactory = persistenceFactory;
    }

    @Override
    public void storeNamespace(final Namespace namespace)
    {
        final JDBCHelper helper = newJDBCHelper();
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(INSERT);
            statement.setString(1, namespace.getPrefix());
            statement.setString(2, namespace.getURI());
            statement.setInt(3, namespace.getProcessorId());
            if (statement.executeUpdate() != 1)
            {
                throw new RuntimeException("PreparedStatement.executeUpdate() for insert statement did not return 1");
            }
            namespace.setId(helper.getLastInsertId(connection));
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            helper.safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    JDBCHelper newJDBCHelper()
    {
        return new JDBCHelper();
    }

    @Override
    public Collection<Namespace> getNamespacesByProcessor(final String processorName)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(SELECT);
            statement.setString(1, processorName);
            final ResultSet results = statement.executeQuery();
            final List<Namespace> namespaces = new ArrayList<Namespace>();
            while (results.next())
            {
                final Namespace namespace = new Namespace();
                namespace.setId(results.getInt("ID"));
                namespace.setPrefix(results.getString("PREFIX"));
                namespace.setURI(results.getString("URI"));
                namespace.setProcessorId(results.getInt("PROCESSOR_ID"));
                namespaces.add(namespace);
            }

            return namespaces;
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    @Override
    public void deleteNamespaces(final int processorId)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(DELETE);
            statement.setInt(1, processorId);
            statement.executeUpdate();
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }
}
