/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.sf.dropboxmq.workflow.data.EventType;
import net.sf.dropboxmq.workflow.persistence.EventTypePersistence;

/**
 * Created: 04 Feb 2011
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class EventTypePersistenceImpl implements EventTypePersistence
{
    private static final String SUB_SELECT_EVENT_TYPE_STARTING
            = "select ets.ID from EVENT_TYPE_STARTING ets where ets.NAME = ?";
    private static final String INSERT = "insert into EVENT_TYPE (NAME, IS_ENABLED, TEST_X_PATH, KEY_X_PATH,"
            + " CONTEXT_X_PATH, EVENT_TYPE_STARTING_ID, IS_BROADCAST, WILL_KEEP_ONLY_LAST_BROADCAST,"
            + " WILL_IGNORE_LATE_MESSAGE_TO_TERMINATED_RUN, ERROR_TRANSFORMER_FILE_PATH, PARENT_KEY_X_PATH,"
            + " PARENT_PROCESS_TYPE_ID, PROCESS_TYPE_ID)"
            + " values (?, ?, ?, ?, ?, (" + SUB_SELECT_EVENT_TYPE_STARTING + "), ?, ?, ?, ?, ?, ?, ?)";
    private static final String UPDATE = "update EVENT_TYPE et set et.NAME = ?, et.IS_ENABLED = ?, et.TEST_X_PATH = ?,"
            + " et.KEY_X_PATH = ?, et.CONTEXT_X_PATH = ?,"
            + " et.EVENT_TYPE_STARTING_ID = (" + SUB_SELECT_EVENT_TYPE_STARTING + "),"
            + " et.IS_BROADCAST = ?, et.WILL_KEEP_ONLY_LAST_BROADCAST = ?,"
            + " et.WILL_IGNORE_LATE_MESSAGE_TO_TERMINATED_RUN = ?, et.ERROR_TRANSFORMER_FILE_PATH = ?,"
            + " et.PARENT_KEY_X_PATH = ?, et.PARENT_PROCESS_TYPE_ID = ?, et.PROCESS_TYPE_ID = ?"
            + " where et.ID = ?";
    private static final String UPDATE_DISABLE = "update EVENT_TYPE et set et.IS_ENABLED = ? where et.ID = ?";
    private static final String SELECT = "select et.ID, et.NAME, et.IS_ENABLED, et.TEST_X_PATH,"
            + " et.KEY_X_PATH, et.CONTEXT_X_PATH, et.EVENT_TYPE_STARTING_ID, et.IS_BROADCAST,"
            + " et.WILL_KEEP_ONLY_LAST_BROADCAST, et.WILL_IGNORE_LATE_MESSAGE_TO_TERMINATED_RUN,"
            + " et.ERROR_TRANSFORMER_FILE_PATH, et.PARENT_KEY_X_PATH, et.PARENT_PROCESS_TYPE_ID, et.PROCESS_TYPE_ID,"
            + " ets.NAME as EVENT_TYPE_STARTING_NAME, pt.NAME as PROCESS_TYPE_NAME,"
            + " pt2.NAME as PARENT_PROCESS_TYPE_NAME"
            + " from EVENT_TYPE et"
            + " join EVENT_TYPE_STARTING ets on ets.ID = et.EVENT_TYPE_STARTING_ID"
            + " join PROCESS_TYPE pt on pt.ID = et.PROCESS_TYPE_ID"
            + " left outer join PROCESS_TYPE pt2 on pt2.ID = et.PARENT_PROCESS_TYPE_ID";
    private static final String SELECT_BY_PROCESS_TYPE = SELECT + " where et.PROCESS_TYPE_ID = ?";
    private static final String SELECT_BY_PROCESSOR = SELECT
            + " join PROCESSOR p on p.ID = pt.PROCESSOR_ID"
            + " where p.NAME = ?";

    private final PersistenceFactoryImpl persistenceFactory;

    public EventTypePersistenceImpl(final PersistenceFactoryImpl persistenceFactory)
    {
        this.persistenceFactory = persistenceFactory;
    }

    @Override
    public void storeEventType(final EventType eventType)
    {
        final JDBCHelper helper = newJDBCHelper();
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(INSERT);
            setParameters(statement, eventType);
            if (statement.executeUpdate() != 1)
            {
                throw new RuntimeException("PreparedStatement.executeUpdate() for insert statement did not return 1");
            }

            eventType.setId(helper.getLastInsertId(connection));
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            helper.safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    JDBCHelper newJDBCHelper()
    {
        return new JDBCHelper();
    }

    private void setParameters(final PreparedStatement statement, final EventType eventType) throws SQLException
    {
        statement.setString(1, eventType.getName());
        statement.setBoolean(2, eventType.isEnabled());
        statement.setString(3, eventType.getTestXPath());
        statement.setString(4, eventType.getKeyXPath());
        statement.setString(5, eventType.getContextXPath());
        statement.setString(6, eventType.getStartingEnum().name());
        statement.setBoolean(7, eventType.isBroadcast());
        statement.setBoolean(8, eventType.willKeepOnlyLastBroadcast());
        statement.setBoolean(9, eventType.willIgnoreLateMessageToTerminatedRun());
        statement.setString(10, eventType.getErrorTransformerFilePath());
        statement.setString(11, eventType.getParentKeyXPath());
        if (eventType.getParentProcessTypeId() == null)
        {
            statement.setNull(12, Types.BIGINT);
        }
        else
        {
            statement.setInt(12, eventType.getParentProcessTypeId());
        }
        statement.setInt(13, eventType.getProcessTypeId());
    }

    @Override
    public void updateEventType(final int id, final EventType eventType)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(UPDATE);
            setParameters(statement, eventType);
            statement.setInt(14, id);
            if (statement.executeUpdate() != 1)
            {
                throw new RuntimeException("PreparedStatement.executeUpdate() for update statement did not return 1");
            }
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    @Override
    public void disableEventType(final int id)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(UPDATE_DISABLE);
            statement.setBoolean(1, false);
            statement.setInt(2, id);
            if (statement.executeUpdate() != 1)
            {
                throw new RuntimeException("PreparedStatement.executeUpdate() for update statement did not return 1");
            }
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    @Override
    public Collection<EventType> getEventTypesByProcessTypeId(final int processTypeId)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(SELECT_BY_PROCESS_TYPE);
            statement.setInt(1, processTypeId);
            return getEventTypesFromResults(statement.executeQuery());
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    private static Collection<EventType> getEventTypesFromResults(final ResultSet results) throws SQLException
    {
        final List<EventType> eventTypes = new ArrayList<EventType>();
        while (results.next())
        {
            final EventType eventType = new EventType();
            eventType.setId(results.getInt("ID"));
            eventType.setName(results.getString("NAME"));
            eventType.setEnabled(results.getBoolean("IS_ENABLED"));
            eventType.setTestXPath(results.getString("TEST_X_PATH"));
            eventType.setKeyXPath(results.getString("KEY_X_PATH"));
            eventType.setContextXPath(results.getString("CONTEXT_X_PATH"));
            eventType.setStartingEnum(
                    EventType.EventTypeStarting.valueOf(results.getString("EVENT_TYPE_STARTING_NAME")));
            eventType.setBroadcast(results.getBoolean("IS_BROADCAST"));
            eventType.setWillKeepOnlyLastBroadcast(results.getBoolean("WILL_KEEP_ONLY_LAST_BROADCAST"));
            eventType.setWillIgnoreLateMessageToTerminatedRun(
                    results.getBoolean("WILL_IGNORE_LATE_MESSAGE_TO_TERMINATED_RUN"));
            eventType.setErrorTransformerFilePath(results.getString("ERROR_TRANSFORMER_FILE_PATH"));
            eventType.setParentKeyXPath(results.getString("PARENT_KEY_X_PATH"));
            eventType.setParentProcessTypeId(results.getInt("PARENT_PROCESS_TYPE_ID"));
            if (results.wasNull())
            {
                eventType.setParentProcessTypeId(null);
            }
            eventType.setProcessTypeId(results.getInt("PROCESS_TYPE_ID"));
            eventType.setProcessTypeName(results.getString("PROCESS_TYPE_NAME"));
            eventType.setParentProcessTypeName(results.getString("PARENT_PROCESS_TYPE_NAME"));
            eventTypes.add(eventType);
        }

        return eventTypes;
    }

    @Override
    public Collection<EventType> getEnabledEventTypesByProcessor(final String processorName)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(SELECT_BY_PROCESSOR);
            statement.setString(1, processorName);
            return getEventTypesFromResults(statement.executeQuery());
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

}
