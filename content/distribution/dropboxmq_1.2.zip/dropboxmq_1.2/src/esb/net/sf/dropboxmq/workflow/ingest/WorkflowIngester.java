/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.ingest;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import net.sf.dropboxmq.workflow.data.EventType;
import net.sf.dropboxmq.workflow.data.Namespace;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Created: 08 Aug 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class WorkflowIngester
{
    public IngestedProcessor ingestWorkflowFile(final File file)
            throws IOException, SAXException, ParserConfigurationException
    {
        return validateAndIngest(newDocumentBuilder().parse(file));
    }

    public IngestedProcessor ingestWorkflowXML(final String workflow)
            throws IOException, SAXException, ParserConfigurationException
    {
        final StringReader reader = new StringReader(workflow);
        return validateAndIngest(newDocumentBuilder().parse(new InputSource(reader)));
    }

    private static DocumentBuilder newDocumentBuilder() throws ParserConfigurationException
    {
        final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        return factory.newDocumentBuilder();
    }

    private static IngestedProcessor validateAndIngest(final Document document) throws IOException, SAXException
    {
        final SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        final String xsd = "net/sf/dropboxmq/workflow/dropboxmq-workflow.xsd";
        final InputStream stream = Thread.currentThread().getContextClassLoader().getResourceAsStream(xsd);
        if (stream == null)
        {
            throw new RuntimeException("Could not class load " + xsd);
        }
        final Schema schema = schemaFactory.newSchema(new StreamSource(stream));
        schema.newValidator().validate(new DOMSource(document));

        return ingestProcessor(document.getDocumentElement());
    }

    private static IngestedProcessor ingestProcessor(final Element processorElement)
    {
        if (!getName(processorElement).equals("processor"))
        {
            throw new RuntimeException("Ingested element is not a processor");
        }

        final IngestedProcessor processor = new IngestedProcessor();
        processor.getProcessor().setName(getAttribute(processorElement, "name"));

        for (final Element namespaceElement : getChildren(processorElement, "namespace"))
        {
            processor.getNamespaces().add(ingestNamespace(namespaceElement));
        }

        for (final Element processorTypeElement : getChildren(processorElement, "process-type"))
        {
            processor.getProcessTypes().add(ingestProcessType(processorTypeElement));
        }

        return processor;
    }

    private static Namespace ingestNamespace(final Element namespaceElement)
    {
        final Namespace namespace = new Namespace();
        namespace.setPrefix(getAttribute(namespaceElement, "prefix"));
        namespace.setURI(getAttribute(namespaceElement, "uri"));

        return namespace;
    }

    private static IngestedProcessor.IngestedProcessType ingestProcessType(final Element processTypeElement)
    {
        final IngestedProcessor.IngestedProcessType processType = new IngestedProcessor.IngestedProcessType();
        processType.getProcessType().setName(getAttribute(processTypeElement, "name"));

        for (final Element eventTypeElement : getChildren(processTypeElement, "event-type"))
        {
            processType.getEventTypes().add(ingestEventType(eventTypeElement));
        }

        processType.getStates().add(ingestState(getFirstChild(processTypeElement, "initial-state"), true));

        for (final Element stateElement : getChildren(processTypeElement, "state"))
        {
            processType.getStates().add(ingestState(stateElement, false));
        }

        return processType;
    }

    private static IngestedProcessor.IngestedEventType ingestEventType(final Element eventTypeElement)
    {
        final IngestedProcessor.IngestedEventType eventType = new IngestedProcessor.IngestedEventType();
        eventType.getEventType().setName(getAttribute(eventTypeElement, "name"));
        eventType.getEventType().setEnabled(true);
        eventType.getEventType().setTestXPath(getAttribute(eventTypeElement, "test"));
        eventType.getEventType().setKeyXPath(getAttribute(eventTypeElement, "key"));
        eventType.getEventType().setContextXPath(getAttribute(eventTypeElement, "context"));
        String starting = getAttribute(eventTypeElement, "starting");
        if (starting == null)
        {
            starting = EventType.EventTypeStarting.WillNotStartNewRun.toString();
        }
        eventType.getEventType().setStartingEnum(EventType.EventTypeStarting.valueOf(starting));
        eventType.getEventType().setBroadcast(getBooleanAttribute(eventTypeElement, "is-broadcast", false));
        eventType.getEventType().setWillKeepOnlyLastBroadcast(
                getBooleanAttribute(eventTypeElement, "will-keep-only-last-broadcast", true));
        eventType.getEventType().setWillIgnoreLateMessageToTerminatedRun(
                getBooleanAttribute(eventTypeElement, "will-ignore-late-message-to-terminated-run", true));
        eventType.getEventType().setErrorTransformerFilePath(
                getAttribute(eventTypeElement, "error-transformer-file-path"));
        eventType.getEventType().setParentKeyXPath(getAttribute(eventTypeElement, "parent-key"));
        eventType.setParentProcessTypeName(getAttribute(eventTypeElement, "parent-process-type"));

        return eventType;
    }

    private static IngestedProcessor.IngestedState ingestState(final Element stateElement, final boolean initial)
    {
        final IngestedProcessor.IngestedState state = new IngestedProcessor.IngestedState();
        state.setInitial(initial);
        state.getState().setName(getAttribute(stateElement, "name"));

        for (final Element deferredEventTypeElement : getChildren(stateElement, "deferred-event-type"))
        {
            state.getDeferredEventTypeNames().add(getAttribute(deferredEventTypeElement, "name"));
        }

        for (final Element transitionElement : getChildren(stateElement, "transition"))
        {
            state.getTransitions().add(ingestTransition(transitionElement));
        }
        return state;
    }

    private static IngestedProcessor.IngestedTransition ingestTransition(final Element transitionElement)
    {
        final IngestedProcessor.IngestedTransition transition = new IngestedProcessor.IngestedTransition();
        transition.getTransition().setName(getAttribute(transitionElement, "name"));
        transition.getTransition().setTestXPath(getAttribute(transitionElement, "test"));
        transition.getTransition().setTransformerFilePath(getAttribute(transitionElement, "transformer-file-path"));
        transition.setToStateName(getAttribute(transitionElement, "to-state"));

        if (getBooleanAttribute(transitionElement, "terminate", false) && transition.getToStateName() != null)
        {
            throw new RuntimeException("to-state defined and terminate is true on transition"
                    + ", name = " + transition.getTransition().getName()
                    + ", test = " + transition.getTransition().getTestXPath()
                    + ", to-state = " + transition.getToStateName());
        }

        return transition;
    }

    private static String getName(final Element element)
    {
        return element.getLocalName();
    }

    private static Element getFirstChild(final Element element, final String name)
    {
        return (Element)element.getElementsByTagName(name).item(0);
    }

    private static List<Element> getChildren(final Element element, final String name)
    {
        final List<Element> children = new ArrayList<Element>();
        final NodeList nodeList = element.getElementsByTagName(name);
        for (int i = 0; i < nodeList.getLength(); i++)
        {
            children.add((Element)nodeList.item(i));
        }

        return children;
    }

    private static String getAttribute(final Element element, final String name)
    {
        final String value = element.getAttribute(name);
        return value.length() > 0 ? value : null;
    }

    private static boolean getBooleanAttribute(final Element element, final String name, final boolean defaultValue)
    {
        final String value = getAttribute(element, name);
        return value == null ? defaultValue : value.equals("true");
    }

}
