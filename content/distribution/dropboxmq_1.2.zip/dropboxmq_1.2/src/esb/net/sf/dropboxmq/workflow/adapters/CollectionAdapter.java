/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.adapters;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import net.sf.dropboxmq.workflow.data.EventPackage;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Created: 08 Nov 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class CollectionAdapter implements EventAdapter
{
    private static final String EVENT_SUFFIX = "-event";

    public static final String CONTENT = "content";
    public static final String HEADER = "header";

    private final Map<String, EventAdapter> adapters = new HashMap<String, EventAdapter>();

    public void addAdapter(final String protocol, final EventAdapter adapter)
    {
        adapters.put(protocol, adapter);
    }

    @Override
    public Collection<EventPackage> processResults(final Node results)
    {
        final Collection<EventPackage> events = new ArrayList<EventPackage>();

        if (!results.getNodeName().equals("results"))
        {
            throw new RuntimeException("Root node name of results document must be 'results'");
        }

        final NodeList children = results.getChildNodes();
        for (int i = 0; i < children.getLength(); i++)
        {
            final Node child = children.item(i);

            final String name = child.getNodeName();
            if (!name.endsWith(EVENT_SUFFIX))
            {
                throw new RuntimeException("Unknown results node: " + name);
            }

            final String protocol = name.substring(0, name.length() - EVENT_SUFFIX.length());

            final Collection<EventPackage> childrenEvents = getChildAdapter(protocol).processResults(child);
            if (childrenEvents != null)
            {
                events.addAll(childrenEvents);
            }
        }

        return events;
    }

    private EventAdapter getChildAdapter(final String protocol)
    {
        final EventAdapter adapter = adapters.get(protocol);
        if (adapter == null)
        {
            throw new RuntimeException("Could not find event adapter for " + protocol);
        }

        return adapter;
    }

    @Override
    public void renderProperties(
            final Map<String, String> properties, final String protocol, final Element eventElement)
    {
        getChildAdapter(protocol).renderProperties(properties, protocol, eventElement);
    }

    public static void renderSimpleProperty(
            final String name, final String value, final String elementName, final Element eventElement)
    {
        final Element property = eventElement.getOwnerDocument().createElement(elementName);
        property.setAttribute("name", name);
        property.setAttribute("value", value);
        eventElement.appendChild(property);
    }

    public static Element findSingleChild(final String name, final Node results)
    {
        final NodeList list = ((Element)results).getElementsByTagName(name);
        if (list.getLength() != 1)
        {
            throw new RuntimeException("Did not find exactly one " + name + " element, found " + list.getLength());
        }
        return (Element)list.item(0);
    }

    @Override
    public void close()
    {
        for (final EventAdapter adapter : adapters.values())
        {
            adapter.close();
        }
    }

}
