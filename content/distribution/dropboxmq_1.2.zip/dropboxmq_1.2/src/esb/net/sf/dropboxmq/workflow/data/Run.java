/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.data;

import java.io.Serializable;
import java.util.Date;

/**
 * Created: 28 Jul 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class Run implements Serializable, Cloneable
{
    private static final long serialVersionUID = 7781291904732518709L;

    private Integer id = null;
    private String context = null;
    private Integer currentStateId = null;
    private Integer parentRunId = null;
    private Integer processId = null;
    private Date startedOn = null;
    private Date lastUpdate = null;

    // Join data -- not used at archive time
    private Integer processTypeId = null;
    private String processTypeName = null;
    private String processKey = null;
    private String currentStateName = null;
    private String parentProcessTypeName = null;
    private String parentProcessKey = null;
    private String parentContext = null;

    public Integer getId()
    {
        return id;
    }

    public void setId(final Integer id)
    {
        this.id = id;
    }

    public String getContext()
    {
        return context;
    }

    public void setContext(final String context)
    {
        this.context = context;
    }

    public Integer getCurrentStateId()
    {
        return currentStateId;
    }

    public void setCurrentStateId(final Integer currentStateId)
    {
        this.currentStateId = currentStateId;
    }

    public Integer getParentRunId()
    {
        return parentRunId;
    }

    public void setParentRunId(final Integer parentRunId)
    {
        this.parentRunId = parentRunId;
    }

    public Integer getProcessId()
    {
        return processId;
    }

    public void setProcessId(final Integer processId)
    {
        this.processId = processId;
    }

    public Date getStartedOn()
    {
        return startedOn;
    }

    public void setStartedOn(final Date startedOn)
    {
        this.startedOn = startedOn;
    }

    public Date getLastUpdate()
    {
        return lastUpdate;
    }

    public void setLastUpdate(final Date lastUpdate)
    {
        this.lastUpdate = lastUpdate;
    }

    public Integer getProcessTypeId()
    {
        return processTypeId;
    }

    public void setProcessTypeId(final Integer processTypeId)
    {
        this.processTypeId = processTypeId;
    }

    public String getProcessTypeName()
    {
        return processTypeName;
    }

    public void setProcessTypeName(final String processTypeName)
    {
        this.processTypeName = processTypeName;
    }

    public String getProcessKey()
    {
        return processKey;
    }

    public void setProcessKey(final String processKey)
    {
        this.processKey = processKey;
    }

    public String getCurrentStateName()
    {
        return currentStateName;
    }

    public void setCurrentStateName(final String currentStateName)
    {
        this.currentStateName = currentStateName;
    }

    public String getParentProcessTypeName()
    {
        return parentProcessTypeName;
    }

    public void setParentProcessTypeName(final String parentProcessTypeName)
    {
        this.parentProcessTypeName = parentProcessTypeName;
    }

    public String getParentProcessKey()
    {
        return parentProcessKey;
    }

    public void setParentProcessKey(final String parentProcessKey)
    {
        this.parentProcessKey = parentProcessKey;
    }

    public String getParentContext()
    {
        return parentContext;
    }

    public void setParentContext(final String parentContext)
    {
        this.parentContext = parentContext;
    }

    @Override
    public final Run clone()
    {
        try
        {
            return (Run)super.clone();
        }
        catch (CloneNotSupportedException e)
        {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean equals(final Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null || getClass() != obj.getClass())
        {
            return false;
        }

        final Run that = (Run)obj;

        if (context != null ? !context.equals(that.context) : that.context != null)
        {
            return false;
        }
        if (currentStateId != null ? !currentStateId.equals(that.currentStateId) : that.currentStateId != null)
        {
            return false;
        }
        if (currentStateName != null ? !currentStateName.equals(that.currentStateName) : that.currentStateName != null)
        {
            return false;
        }
        if (id != null ? !id.equals(that.id) : that.id != null)
        {
            return false;
        }
        if (lastUpdate != null ? !lastUpdate.equals(that.lastUpdate) : that.lastUpdate != null)
        {
            return false;
        }
        if (parentContext != null ? !parentContext.equals(that.parentContext) : that.parentContext != null)
        {
            return false;
        }
        if (parentProcessKey != null ? !parentProcessKey.equals(that.parentProcessKey) : that.parentProcessKey != null)
        {
            return false;
        }
        if (parentProcessTypeName != null ? !parentProcessTypeName.equals(that.parentProcessTypeName)
                : that.parentProcessTypeName != null)
        {
            return false;
        }
        if (parentRunId != null ? !parentRunId.equals(that.parentRunId) : that.parentRunId != null)
        {
            return false;
        }
        if (processId != null ? !processId.equals(that.processId) : that.processId != null)
        {
            return false;
        }
        if (processKey != null ? !processKey.equals(that.processKey) : that.processKey != null)
        {
            return false;
        }
        if (processTypeId != null ? !processTypeId.equals(that.processTypeId) : that.processTypeId != null)
        {
            return false;
        }
        if (processTypeName != null ? !processTypeName.equals(that.processTypeName) : that.processTypeName != null)
        {
            return false;
        }
        if (startedOn != null ? !startedOn.equals(that.startedOn) : that.startedOn != null)
        {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (context != null ? context.hashCode() : 0);
        result = 31 * result + (currentStateId != null ? currentStateId.hashCode() : 0);
        result = 31 * result + (parentRunId != null ? parentRunId.hashCode() : 0);
        result = 31 * result + (processId != null ? processId.hashCode() : 0);
        result = 31 * result + (startedOn != null ? startedOn.hashCode() : 0);
        result = 31 * result + (lastUpdate != null ? lastUpdate.hashCode() : 0);
        result = 31 * result + (processTypeId != null ? processTypeId.hashCode() : 0);
        result = 31 * result + (processTypeName != null ? processTypeName.hashCode() : 0);
        result = 31 * result + (processKey != null ? processKey.hashCode() : 0);
        result = 31 * result + (currentStateName != null ? currentStateName.hashCode() : 0);
        result = 31 * result + (parentProcessTypeName != null ? parentProcessTypeName.hashCode() : 0);
        result = 31 * result + (parentProcessKey != null ? parentProcessKey.hashCode() : 0);
        result = 31 * result + (parentContext != null ? parentContext.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "Run{"
                + "id=" + id
                + ", context='" + context + '\''
                + ", currentStateId=" + currentStateId
                + ", parentRunId=" + parentRunId
                + ", processId=" + processId
                + ", startedOn=" + startedOn
                + ", lastUpdate=" + lastUpdate
                + ", processTypeId=" + processTypeId
                + ", processTypeName='" + processTypeName + '\''
                + ", processKey='" + processKey + '\''
                + ", currentStateName='" + currentStateName + '\''
                + ", parentProcessTypeName='" + parentProcessTypeName + '\''
                + ", parentProcessKey='" + parentProcessKey + '\''
                + ", parentContext='" + parentContext + '\''
                + '}';
    }

}
