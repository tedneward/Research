create table if not exists EVENT_PROTOCOL
(
    ID    bigint not null auto_increment,
    NAME  varchar(256) unique not null,

    primary key (ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;

insert into EVENT_PROTOCOL (NAME) value ('jms');
