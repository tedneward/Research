create table if not exists TRANSITION
(
    ID                     bigint not null auto_increment,
    TRANSITION_NAME_ID     bigint,
    TEST_X_PATH            varchar(4000) not null,
    FROM_STATE_ID          bigint,
    TO_STATE_ID            bigint,
    TRANSFORMER_FILE_PATH  varchar(4000),
    PROCESS_TYPE_ID        bigint not null,

    primary key (ID),
    constraint TRANSITION_TRANSITION_NAME_ID_FK foreign key (TRANSITION_NAME_ID) references TRANSITION_NAME (ID),
    constraint TRANSITION_PROCESS_TYPE_ID_FK foreign key (PROCESS_TYPE_ID) references PROCESS_TYPE (ID),
    constraint TRANSITION_FROM_STATE_ID_FK foreign key (FROM_STATE_ID) references STATE (ID),
    constraint TRANSITION_TO_STATE_ID_FK foreign key (TO_STATE_ID) references STATE (ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;
