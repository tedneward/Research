/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import net.sf.dropboxmq.workflow.data.Process;
import net.sf.dropboxmq.workflow.persistence.ProcessPersistence;

/**
 * Created: 06 02 2011
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class ProcessPersistenceImpl implements ProcessPersistence
{
    private static final String INSERT = "insert into PROCESS (PROCESS_KEY, PROCESS_TYPE_ID) values (?, ?)";
    private static final String SELECT = "select ID, PROCESS_KEY, PROCESS_TYPE_ID from PROCESS"
            + " where PROCESS_KEY = ? and PROCESS_TYPE_ID = ?";

    private final PersistenceFactoryImpl persistenceFactory;

    public ProcessPersistenceImpl(final PersistenceFactoryImpl persistenceFactory)
    {
        this.persistenceFactory = persistenceFactory;
    }

    @Override
    public void storeProcess(final Process process)
    {
        final JDBCHelper helper = newJDBCHelper();
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(INSERT);
            statement.setString(1, process.getProcessKey());
            statement.setInt(2, process.getProcessTypeId());
            if (statement.executeUpdate() != 1)
            {
                throw new RuntimeException("PreparedStatement.executeUpdate() for insert statement did not return 1");
            }
            process.setId(helper.getLastInsertId(connection));
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            helper.safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    JDBCHelper newJDBCHelper()
    {
        return new JDBCHelper();
    }

    @Override
    public Process getProcessByKey(final String key, final int processTypeId)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(SELECT);
            statement.setString(1, key);
            statement.setInt(2, processTypeId);
            final ResultSet results = statement.executeQuery();
            Process process = null;
            if (results.next())
            {
                process = new Process();
                process.setId(results.getInt("ID"));
                process.setProcessKey(results.getString("PROCESS_KEY"));
                process.setProcessTypeId(results.getInt("PROCESS_TYPE_ID"));
            }

            if (results.next())
            {
                throw new RuntimeException("select by unique fields returned multiple rows");
            }

            return process;
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

}
