#!/bin/bash

DIRNAME=`dirname $0`
OPTIONS=$*

exec_sql()
{
    echo "Executing $1"
    cat $1 | $OPTIONS
}

exec_sql $DIRNAME/processor.sql
exec_sql $DIRNAME/namespace.sql
exec_sql $DIRNAME/process_type.sql
exec_sql $DIRNAME/state.sql
exec_sql $DIRNAME/transition_name.sql
exec_sql $DIRNAME/transition.sql
exec_sql $DIRNAME/event_type_starting.sql
exec_sql $DIRNAME/event_type.sql
exec_sql $DIRNAME/event_protocol.sql
exec_sql $DIRNAME/deferred_event_type.sql
exec_sql $DIRNAME/process.sql
exec_sql $DIRNAME/run.sql
exec_sql $DIRNAME/event.sql
exec_sql $DIRNAME/event_property.sql
