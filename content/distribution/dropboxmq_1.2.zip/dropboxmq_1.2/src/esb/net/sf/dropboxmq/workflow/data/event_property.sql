create table if not exists EVENT_PROPERTY
(
    ID        bigint not null auto_increment,
    NAME      varchar(256) not null,
    VALUE     varchar(256) not null,
    EVENT_ID  bigint not null,

    primary key (ID),
    constraint EVENT_PROPERTY_EVENT_ID_FK foreign key (EVENT_ID) references EVENT (ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;
