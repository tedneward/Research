/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.memory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.dropboxmq.workflow.data.State;
import net.sf.dropboxmq.workflow.data.Transition;
import net.sf.dropboxmq.workflow.persistence.TransitionPersistence;

/**
 * Created: 02 Sep 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class TransitionPersistenceImpl implements TransitionPersistence
{
    private final StatePersistenceImpl statePersistence;
    private final ProcessTypePersistenceImpl processTypePersistence;
    private final Map<Integer, Map<Integer, Collection<Transition>>> transitionsByProcessTypeFromStateId
            = new HashMap<Integer, Map<Integer, Collection<Transition>>>();
    private int nextTransitionId = 1000;

    public TransitionPersistenceImpl(
            final StatePersistenceImpl statePersistence, final ProcessTypePersistenceImpl processTypePersistence)
    {
        this.statePersistence = statePersistence;
        this.processTypePersistence = processTypePersistence;
    }

    @Override
    public void storeTransition(final Transition transition)
    {
        final Transition newTransition = transition.clone();

        // Primary key
        newTransition.setId(nextTransitionId);
        nextTransitionId++;

        // Verify all foreign keys exist
        if (newTransition.getFromStateId() != null)
        {
            final State fromState = statePersistence.getExistingStateById(newTransition.getFromStateId());
            newTransition.setFromStateName(fromState.getName());
        }
        if (newTransition.getToStateId() != null)
        {
            final State toState = statePersistence.getExistingStateById(newTransition.getToStateId());
            newTransition.setToStateName(toState.getName());
        }
        processTypePersistence.getExistingProcessTypeById(newTransition.getProcessTypeId());

        // Update indexes
        final Collection<Transition> transitions
                = getPrivateTransitionsFromState(newTransition.getFromStateId(), newTransition.getProcessTypeId());
        transitions.add(newTransition);

        // Return the primary key
        transition.setId(newTransition.getId());
    }

    private Collection<Transition> getPrivateTransitionsFromState(final Integer stateId, final int processTypeId)
    {
        final Map<Integer, Collection<Transition>> transitionsByFromState = getTransitionsByProcessType(processTypeId);

        Collection<Transition> transitions = transitionsByFromState.get(stateId);
        if (transitions == null)
        {
            transitions = new ArrayList<Transition>();
            transitionsByFromState.put(stateId, transitions);
        }

        return transitions;
    }

    private Map<Integer, Collection<Transition>> getTransitionsByProcessType(final int processTypeId)
    {
        Map<Integer, Collection<Transition>> transitionsByFromState
                = transitionsByProcessTypeFromStateId.get(processTypeId);
        if (transitionsByFromState == null)
        {
            transitionsByFromState = new HashMap<Integer, Collection<Transition>>();
            transitionsByProcessTypeFromStateId.put(processTypeId, transitionsByFromState);
        }
        return transitionsByFromState;
    }

    @Override
    public Collection<Transition> getTransitionsFromState(final Integer stateId, final int processTypeId)
    {
        final Collection<Transition> transitions = getPrivateTransitionsFromState(stateId, processTypeId);
        final List<Transition> transitionList = new ArrayList<Transition>();
        for (final Transition transition : transitions)
        {
            transitionList.add(transition.clone());
        }
        return transitionList;
    }

    @Override
    public void deleteTransitionsToState(final int stateId)
    {
        final State toState = statePersistence.getExistingStateById(stateId);
        final Map<Integer, Collection<Transition>> transitionsByFromState
                = getTransitionsByProcessType(toState.getProcessTypeId());

        for (final Collection<Transition> transitions : transitionsByFromState.values())
        {
            for (final Transition transition : transitions)
            {
                if (transition.getToStateId() == stateId)
                {
                    transitions.remove(transition);
                }
            }
        }
    }

    @Override
    public void deleteTransitionsFromState(final Integer stateId, final int processTypeId)
    {
        final Collection<Transition> transitions = getPrivateTransitionsFromState(stateId, processTypeId);
        transitions.clear();
    }

}
