/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.data;

import java.io.Serializable;

/**
 * Created: 28 Jul 2010
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class Transition implements Serializable, Cloneable
{
    private static final long serialVersionUID = -5705238134843486492L;

    private Integer id = null;
    private String name = null;
    private String testXPath = null;
    private Integer fromStateId = null;
    private Integer toStateId = null;
    private String transformerFilePath = null;
    private Integer processTypeId = null;

    // Join data -- not used at archive time
    private String fromStateName = null;
    private String toStateName = null;

    public Integer getId()
    {
        return id;
    }

    public void setId(final Integer id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(final String name)
    {
        this.name = name;
    }

    public String getTestXPath()
    {
        return testXPath;
    }

    public void setTestXPath(final String testXPath)
    {
        this.testXPath = testXPath;
    }

    public Integer getFromStateId()
    {
        return fromStateId;
    }

    public void setFromStateId(final Integer fromStateId)
    {
        this.fromStateId = fromStateId;
    }

    public Integer getToStateId()
    {
        return toStateId;
    }

    public void setToStateId(final Integer toStateId)
    {
        this.toStateId = toStateId;
    }

    public String getTransformerFilePath()
    {
        return transformerFilePath;
    }

    public void setTransformerFilePath(final String transformerFilePath)
    {
        this.transformerFilePath = transformerFilePath;
    }

    public Integer getProcessTypeId()
    {
        return processTypeId;
    }

    public void setProcessTypeId(final Integer processTypeId)
    {
        this.processTypeId = processTypeId;
    }

    public String getFromStateName()
    {
        return fromStateName;
    }

    public void setFromStateName(final String fromStateName)
    {
        this.fromStateName = fromStateName;
    }

    public String getToStateName()
    {
        return toStateName;
    }

    public void setToStateName(final String toStateName)
    {
        this.toStateName = toStateName;
    }

    @Override
    public final Transition clone()
    {
        try
        {
            return (Transition)super.clone();
        }
        catch (CloneNotSupportedException e)
        {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean equals(final Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null || getClass() != obj.getClass())
        {
            return false;
        }

        final Transition that = (Transition)obj;

        if (fromStateId != null ? !fromStateId.equals(that.fromStateId) : that.fromStateId != null)
        {
            return false;
        }
        if (fromStateName != null ? !fromStateName.equals(that.fromStateName) : that.fromStateName != null)
        {
            return false;
        }
        if (id != null ? !id.equals(that.id) : that.id != null)
        {
            return false;
        }
        if (name != null ? !name.equals(that.name) : that.name != null)
        {
            return false;
        }
        if (processTypeId != null ? !processTypeId.equals(that.processTypeId) : that.processTypeId != null)
        {
            return false;
        }
        if (testXPath != null ? !testXPath.equals(that.testXPath) : that.testXPath != null)
        {
            return false;
        }
        if (toStateId != null ? !toStateId.equals(that.toStateId) : that.toStateId != null)
        {
            return false;
        }
        if (toStateName != null ? !toStateName.equals(that.toStateName) : that.toStateName != null)
        {
            return false;
        }
        if (transformerFilePath != null ? !transformerFilePath.equals(that.transformerFilePath)
                : that.transformerFilePath != null)
        {
            return false;

        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (testXPath != null ? testXPath.hashCode() : 0);
        result = 31 * result + (fromStateId != null ? fromStateId.hashCode() : 0);
        result = 31 * result + (toStateId != null ? toStateId.hashCode() : 0);
        result = 31 * result + (transformerFilePath != null ? transformerFilePath.hashCode() : 0);
        result = 31 * result + (processTypeId != null ? processTypeId.hashCode() : 0);
        result = 31 * result + (fromStateName != null ? fromStateName.hashCode() : 0);
        result = 31 * result + (toStateName != null ? toStateName.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "Transition{"
                + "id=" + id
                + ", name='" + name + '\''
                + ", testXPath='" + testXPath + '\''
                + ", fromStateId=" + fromStateId
                + ", toStateId=" + toStateId
                + ", transformerFilePath='" + transformerFilePath + '\''
                + ", processTypeId=" + processTypeId
                + ", fromStateName='" + fromStateName + '\''
                + ", toStateName='" + toStateName + '\''
                + '}';
    }

}
