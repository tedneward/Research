create table if not exists RUN
(
    ID                bigint not null auto_increment,
    CONTEXT           varchar(256),
    CURRENT_STATE_ID  bigint,
    PARENT_RUN_ID     bigint,
    PROCESS_ID        bigint not null,
    STARTED_ON        timestamp not null default 0,
    LAST_UPDATE       timestamp not null default current_timestamp on update current_timestamp,

    primary key (ID),
    constraint RUN_CURRENT_STATE_ID_FK foreign key (CURRENT_STATE_ID) references STATE (ID),
    constraint RUN_PARENT_RUN_ID_FK foreign key (PARENT_RUN_ID) references RUN (ID),
    constraint RUN_PROCESS_ID_FK foreign key (PROCESS_ID) references PROCESS (ID)
) ENGINE = InnoDB, AUTO_INCREMENT = 1000;
