/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of DropboxMQ nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.workflow.persistence.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import net.sf.dropboxmq.workflow.data.Run;
import net.sf.dropboxmq.workflow.persistence.RunPersistence;

/**
 * Created: 06 Feb 2011
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class RunPersistenceImpl implements RunPersistence
{
    private static final String INSERT = "insert into RUN"
            + " (CONTEXT, CURRENT_STATE_ID, PARENT_RUN_ID, PROCESS_ID, STARTED_ON)"
            + " values (?, ?, ?, ?, current_timestamp)";
    private static final String SELECT = "select r.ID, r.CONTEXT, r.CURRENT_STATE_ID, r.PARENT_RUN_ID,"
            + " r.PROCESS_ID, r.STARTED_ON, r.LAST_UPDATE, pt.ID as PROCESS_TYPE_ID, pt.NAME as PROCESS_TYPE_NAME,"
            + " p.PROCESS_KEY, s.NAME as CURRENT_STATE_NAME, pt2.NAME as PARENT_PROCESS_TYPE_NAME,"
            + " p2.PROCESS_KEY as PARENT_PROCESS_KEY, r2.CONTEXT as PARENT_CONTEXT from RUN r"
            + " join PROCESS p on p.ID = r.PROCESS_ID"
            + " join PROCESS_TYPE pt on pt.ID = p.PROCESS_TYPE_ID"
            + " left outer join RUN r2 on r2.ID = r.PARENT_RUN_ID"
            + " left outer join PROCESS p2 on p2.ID = r2.PROCESS_ID"
            + " left outer join PROCESS_TYPE pt2 on pt2.ID = p2.PROCESS_TYPE_ID"
            + " left outer join STATE s on s.ID = r.CURRENT_STATE_ID";
    private static final String SELECT_LAST_UPDATED = SELECT
            + " where p.PROCESS_KEY = ? and p.PROCESS_TYPE_ID = ? order by r.LAST_UPDATE desc limit 1";
    private static final String SELECT_ACTIVE_BY_PROCESS_TYPE = SELECT
            + " where p.PROCESS_TYPE_ID = ? and r.CURRENT_STATE_ID is not null";
    private static final String UPDATE = "update RUN set CURRENT_STATE_ID = ? where ID = ?";

    private final PersistenceFactoryImpl persistenceFactory;

    public RunPersistenceImpl(final PersistenceFactoryImpl persistenceFactory)
    {
        this.persistenceFactory = persistenceFactory;
    }

    @Override
    public void storeRun(final Run run)
    {
        final JDBCHelper helper = newJDBCHelper();
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(INSERT);
            statement.setString(1, run.getContext());
            if (run.getCurrentStateId() == null)
            {
                statement.setNull(2, Types.BIGINT);
            }
            else
            {
                statement.setInt(2, run.getCurrentStateId());
            }
            if (run.getParentRunId() == null)
            {
                statement.setNull(3, Types.BIGINT);
            }
            else
            {
                statement.setInt(3, run.getParentRunId());
            }
            statement.setInt(4, run.getProcessId());
            if (statement.executeUpdate() != 1)
            {
                throw new RuntimeException("PreparedStatement.executeUpdate() for insert statement did not return 1");
            }
            run.setId(helper.getLastInsertId(connection));
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            helper.safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    JDBCHelper newJDBCHelper()
    {
        return new JDBCHelper();
    }

    @Override
    public Run getLastUpdatedRunByKeyAndProcessType(final String key, final int processTypeId)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(SELECT_LAST_UPDATED);
            statement.setString(1, key);
            statement.setInt(2, processTypeId);
            final ResultSet results = statement.executeQuery();
            Run run = null;
            if (results.next())
            {
                run = getResult(results);
            }

            if (results.next())
            {
                throw new RuntimeException("select returned multiple rows");
            }

            return run;
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    private static Run getResult(final ResultSet results) throws SQLException
    {
        final Run run = new Run();
        run.setId(results.getInt("ID"));
        run.setContext(results.getString("CONTEXT"));
        run.setCurrentStateId(results.getInt("CURRENT_STATE_ID"));
        if (results.wasNull())
        {
            run.setCurrentStateId(null);
        }
        run.setParentRunId(results.getInt("PARENT_RUN_ID"));
        if (results.wasNull())
        {
            run.setParentRunId(null);
        }
        run.setProcessId(results.getInt("PROCESS_ID"));
        run.setStartedOn(results.getDate("STARTED_ON"));
        run.setLastUpdate(results.getDate("LAST_UPDATE"));
        run.setProcessTypeId(results.getInt("PROCESS_TYPE_ID"));
        run.setProcessTypeName(results.getString("PROCESS_TYPE_NAME"));
        run.setProcessKey(results.getString("PROCESS_KEY"));
        run.setCurrentStateName(results.getString("CURRENT_STATE_NAME"));
        run.setParentProcessTypeName(results.getString("PARENT_PROCESS_TYPE_NAME"));
        run.setParentProcessKey(results.getString("PARENT_PROCESS_KEY"));
        run.setParentContext(results.getString("PARENT_CONTEXT"));
        return run;
    }

    @Override
    public List<Run> getActiveRunsByProcessType(final int processTypeId)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(SELECT_ACTIVE_BY_PROCESS_TYPE);
            statement.setInt(1, processTypeId);
            final ResultSet results = statement.executeQuery();

            final List<Run> runs = new ArrayList<Run>();
            while (results.next())
            {
                runs.add(getResult(results));
            }

            return runs;
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

    @Override
    public void updateState(final int runId, final Integer toStateId)
    {
        final Connection connection = persistenceFactory.getConnection();
        PreparedStatement statement = null;
        try
        {
            statement = connection.prepareStatement(UPDATE);
            if (toStateId == null)
            {
                statement.setNull(1, Types.BIGINT);
            }
            else
            {
                statement.setInt(1, toStateId);
            }
            statement.setInt(2, runId);
            if (statement.executeUpdate() != 1)
            {
                throw new RuntimeException(
                        "PreparedStatement.executeUpdate() for unique update statement did not return 1");
            }
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            newJDBCHelper().safeClose(statement);
            persistenceFactory.closeConnection(connection);
        }
    }

}
