/*
 Copyright (c) 2011, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package net.sf.dropboxmq.jndi;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import javax.management.ObjectName;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import net.sf.dropboxmq.destinations.QueueImpl;
import net.sf.dropboxmq.dropboxsupport.DirectoryStructure;
import org.jboss.system.ServiceMBeanSupport;
import org.jboss.util.naming.Util;

/**
 * Created: 26 Feb 2011
 *
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision$, $Date$
 */
public class JBossDestinationEnumerator extends ServiceMBeanSupport implements JBossDestinationEnumeratorMBean
{
    private static final String JNDI_SEPARATOR = "/";
    private String jndiPrefix = null;
    private String pattern = null;
    private ObjectName rarName = null;
    private String type = null;
    private String root = null;
    private boolean addUtilityDestinations = true;

    private final List<String> boundNames = new ArrayList<String>();

    @Override
    public String getJNDIPrefix()
    {
        return jndiPrefix;
    }

    @Override
    public void setJNDIPrefix(final String jndiPrefix)
    {
        this.jndiPrefix = jndiPrefix;
    }

    @Override
    public String getPattern()
    {
        return pattern;
    }

    @Override
    public void setPattern(final String pattern)
    {
        this.pattern = pattern;
    }

    @Override
    public ObjectName getRARName()
    {
        return rarName;
    }

    @Override
    public void setRARName(final ObjectName rarName)
    {
        this.rarName = rarName;
    }

    @Override
    public String getType()
    {
        return type;
    }

    @Override
    public void setType(final String type)
    {
        this.type = type;
    }

    @Override
    public String getRoot()
    {
        return root;
    }

    @Override
    public void setRoot(final String root)
    {
        this.root = root;
    }

    @Override
    public boolean isAddUtilityDestinations()
    {
        return addUtilityDestinations;
    }

    @Override
    public void setAddUtilityDestinations(final boolean addUtilityDestinations)
    {
        this.addUtilityDestinations = addUtilityDestinations;
    }

    @Override
    protected void startService() throws NamingException
    {
        if (type == null || !type.equals("javax.jms.Queue"))
        {
            throw new RuntimeException(
                    "JBossDestinationEnumerator can only enumerate queues, type must be javax.jms.Queue");
        }

        final File rootDir = new File(root);
        final Pattern regex = Pattern.compile(pattern);
        scanDirectory(rootDir, "", regex);
    }

    private void scanDirectory(final File dir, final String parentPath, final Pattern regex) throws NamingException
    {
        final String parentPrefix = parentPath + (parentPath.length() > 0 ? JNDI_SEPARATOR : "");
        for (final File childDir : dir.listFiles())
        {
            final String childName = childDir.getName();
            if (!childName.equals("dropboxmq") || parentPath.length() != 0)
            {
                if (childName.equals("incoming"))
                {
                    if (regex.matcher(parentPath).matches())
                    {
                        final String jndiName = bind(parentPath);
                        if (addUtilityDestinations)
                        {
                            bind(parentPath + DirectoryStructure.PROCESSING_DESTINATION_SUFFIX);
                            bind(parentPath + DirectoryStructure.EXPIRED_DESTINATION_SUFFIX);
                            bind(parentPath + DirectoryStructure.RECOVER_ERROR_DESTINATION_SUFFIX);
                            bind(parentPath + DirectoryStructure.REJECT_ERROR_DESTINATION_SUFFIX);
                        }
                        log.info("Bound admin object 'javax.jms.Queue' at '" + jndiName + "'"
                                + (addUtilityDestinations ? " and 4 utility destinations" : ""));
                    }
                }
                else if (childDir.isDirectory())
                {
                    scanDirectory(childDir, parentPrefix + childName, regex);
                }
            }
        }
    }

    private String bind(final String name) throws NamingException
    {
        final String jndiName = jndiPrefix + (jndiPrefix.endsWith(JNDI_SEPARATOR) ? "" : JNDI_SEPARATOR) + name;
        final InitialContext context = new InitialContext();
        try
        {
            Util.bind(context, jndiName, new QueueImpl(name));
            boundNames.add(jndiName);
        }
        finally
        {
            try
            {
                context.close();
            }
            catch (NamingException ignore)
            {
                // Ignored
            }
        }
        return jndiName;
    }

    @Override
    protected void stopService() throws NamingException
    {
        final InitialContext context = new InitialContext();
        try
        {
            for (final String boundName : boundNames)
            {
                Util.unbind(context, boundName);
                log.info("Unbound admin object at '" + boundName + "'");
            }
        }
        finally
        {
            try
            {
                context.close();
            }
            catch (NamingException ignore)
            {
                // Ignored
            }
            boundNames.clear();
        }
    }

}
