/*
 Copyright (c) 2008, DropboxMQ, http://dropboxmq.sf.net & Dwayne Schultz
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
 following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following
      disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
      following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of DropboxMQ nor the names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

import java.util.Properties;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 * Created: 24 Feb 2006
 * @author <a href="mailto:dwayne@schultz.net">Dwayne Schultz</a>
 * @version $Revision: 150 $, $Date: 2008-06-21 14:42:46 -0600 (Sat, 21 Jun 2008) $
 */
public class SimpleProduceConsume
{
    public static void main( final String[] args ) throws NamingException, JMSException
    {
        if ( args.length != 1 )
        {
            usage();
        }
        else if ( args[ 0 ] != null && args[ 0 ].equals( "produce" ) )
        {
            produce();
        }
        else if ( args[ 0 ] != null && args[ 0 ].equals( "consume" ) )
        {
            consume();
        }
    }

    private static InitialContext getInitialContext() throws NamingException
    {
        Properties properties = new Properties();
        // properties.load() would probably be more suitable
        properties.setProperty(
                Context.INITIAL_CONTEXT_FACTORY,
                "net.sf.dropboxmq.jndi.InitialContextFactoryImpl" );
        properties.setProperty( "net.sf.dropboxmq.root", "/dropboxmq" );
        InitialContext initialContext = new InitialContext( properties );

        return initialContext;
    }

    private static void produce() throws NamingException, JMSException
    {
        InitialContext initialContext = getInitialContext();

        ConnectionFactory connectionFactory
                = (ConnectionFactory)initialContext.lookup( "ConnectionFactory" );
        Destination destination = (Destination)initialContext.lookup( "TestQueue1" );

        Connection connection = connectionFactory.createConnection();
        Session session = connection.createSession(
                false, Session.AUTO_ACKNOWLEDGE );

        MessageProducer producer = session.createProducer( destination );
        TextMessage message = session.createTextMessage( "Hello World!" );

        producer.send( message );
    }

    private static void consume() throws NamingException, JMSException
    {
        InitialContext initialContext = getInitialContext();

        ConnectionFactory connectionFactory
                = (ConnectionFactory)initialContext.lookup( "ConnectionFactory" );
        Destination destination = (Destination)initialContext.lookup( "TestQueue1" );

        Connection connection = connectionFactory.createConnection();
        Session session = connection.createSession(
                false, Session.AUTO_ACKNOWLEDGE );

        connection.start();

        MessageConsumer consumer = session.createConsumer( destination );
        TextMessage message = (TextMessage)consumer.receiveNoWait();

        System.out.println(
                message == null ? "No message found" : message.getText() );
    }

    private static void usage()
    {
        System.out.println( "usage:" );
        System.out.println( "   java SimpleProduceConsume {produce|consume}" );
    }
}
